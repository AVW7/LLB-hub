# ADMISSION EXAMINATION / TOELATINGSEKSAMEN

# BOOKKEEPING / BOEKHOU

PART 4 / DEEL 4

19 AUGUST / 19 AUGUST 2015

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

QUESTION 1

[30]

Amount to be transferred from Trust Account to Business is R116 500 & Business to Trust is R7000 (8)

Balance after transfer

|   | TRUST | BUSINESS  |
| --- | --- | --- |
|  Xerox Machines |  | (40 000)  |
|  Black | 99 000 | -  |
|  White | 210 000 | -  |
|  Green | 9 500 | -  |
|  Blue | - | 2 000  |
|  Red | 140 000 | -  |
|  Lazarus | - | 37 000  |
|  Zulu | - | 34 000  |
|   |  | (8)  |

TRANSFER JOURNAL

|  Black | (T) | Dr | 35 000 |   |
| --- | --- | --- | --- | --- |
|  White | (T) | Dr | 30 000 |   |
|  Green | (T) | Dr | 6 500 |   |
|  Lazarus | (T) | Dr | 45 000 |   |
|  Black | (B) | Cr |  | 35 000  |
|  White | (B) | Cr |  | 30 000  |
|  Green | (B) | Cr |  | 6 500  |
|  Lazarus | (B) | Cr |  | 45 000  |
|  Zulu | (B) | Dr | 7 000 |   |
|  Zulu | (T) | Cr |  | 7 000  |
|   |  |  |  | (10)  |

1

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©