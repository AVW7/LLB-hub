VARIOUS CLIENTS TRUST LEDGER

|   | Cash | 700 000  |
| --- | --- | --- |

BANK C - TRUST INVEST S78 (2)(a)

|  Cash | 500 000 | Cash | 403 500  |
| --- | --- | --- | --- |
|  Cash | 3 500 |  |   |

WHITE - TRUST LEDGER

|  Cash | 60 000 | Cash | 100 000  |
| --- | --- | --- | --- |
|   |  | Cash | 66 000  |

(3)

LIST OF TRUST CREDITORS

|  Green | 170 000  |
| --- | --- |
|  Mrs Purchaser | 410 000  |
|  Various Clients | 700 000  |
|  White | 106 000  |

Total trust Liability 1 386 000 (5)

Trust Funds Available

|  Trust Cash Book Balance | 836 000  |
| --- | --- |
|  S78 (2)(A) Green | 150 000  |
|  S78(2)(A) Mrs Purchaser | 300 000  |
|  S78 (2)(a) | 100 000  |

1 386 000 (5)

[1 mark for each correct entry]

3

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©