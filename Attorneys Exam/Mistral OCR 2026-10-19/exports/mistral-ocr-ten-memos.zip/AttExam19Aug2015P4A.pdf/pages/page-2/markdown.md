|  Debt Business Cash Book | R116 500  |
| --- | --- |
|  Credit Trust Cash Book | R116 500  |
|  Debit Trust Cash Book | R7 000  |
|  Credit Business Book | R7000  |

(4)

[1 mark each entry]

QUESTION 2 [40]

|  TRUST CASH BOOK  |   |   |   |
| --- | --- | --- | --- |
|  Green | 200 000 | Bank A | 200 000  |
|  Bank A | 50 000 | Counsel | 30 000  |
|  Mrs Purchaser | 350 000 | Bank B | 300 000  |
|  Various clients | 700 000 | Bank C | 500 000  |
|  Mrs Purchaser | 100 000 | Receiver of Rev | 40 000  |
|  Bank C | 403 500 | Fidelity Fund | 3 500  |
|  White | 100 000 | Stock Broker | 60 000  |
|  Stock Broker | 66 000 | Balance | 836 000  |
|   | 1 969 500 |  | 1 969 500  |

(15)

|  GREEN TRUST LEDGER  |   |   |   |
| --- | --- | --- | --- |
|  Cash | 30 000 | Cash | 200 000  |

(2)

|  BANK A - TRUST INV S78 (2) (A) GREEN  |   |   |   |
| --- | --- | --- | --- |
|  Cash | 200 000 | Cash | 50 000  |

(2)

|  MRS PURCHASER - TRUST LEDGER  |   |   |   |
| --- | --- | --- | --- |
|  Cash | 40 000 | Cash | 350 000  |
|   |  | Cash | 100 000  |

(3)

|  BANK B - TRUST INV S78 (2) (A) MRS PURCHASER  |   |
| --- | --- |
|  Cash | 300 000  |

(1)

2

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©