|  TRUST CASH BOOK  |   |
| --- | --- |
|  T/F (Black) | 10 000  |

|  BUSINESS CASH BOOK  |   |
| --- | --- |
|  T/F (Black) | 10 000  |

(6)

TOTAL: [100]

![img-0.jpeg](img-0.jpeg)

# LAW SOCIETY

# OF SOUTH AFRICA

6

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©