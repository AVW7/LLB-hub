QUESTION 3

[30]

3.1 Debit Trust Cash Book and (Credit Correspondent in the Trust Ledger Account)

|  TRUST CASH BOOK  |   |   |
| --- | --- | --- |
|  Correspondent | 7 500 |   |
|   |  | (2)  |

3.2 Trust Journal

|  White | Dr | 1140 |   |
| --- | --- | --- | --- |
|  Correspondent | Cr |  | 1000  |
|  Vat | Cr |  | 140  |

Being Fees charged by Correspondent on collection matter (2)

3.3 Business Journal/Fee Journal

|  Correspondent | Dr | 228 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 200  |
|  Vat | Cr |  | 28  |

Being allowance on fees received from Correspondent (2)

3.4 Business Journal

|  XYZ (Pty) Ltd | Dr | 500 |   |
| --- | --- | --- | --- |
|  Revenue stamps | Cr |  | 500  |
|  Being stamps used for company registration |   |   | (2)  |

3.5 Business Journal

|  Revenue stamps | Dr | 100 |   |
| --- | --- | --- | --- |
|  XYZ (Pty) Ltd | Cr |  | 100  |
|  Being stamps returned – not used |   |   | (2)  |

3.6 Journal/Business Journal

|  XYZ (Pty) Ltd | Dr | 5 700 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 5000  |
|  Vat | Cr |  | 700  |
|  Being fees charged for registration of company |   |   | (2)  |

3.7 Debit Business Cash Book (Credit Ledger)

|  BUSINESS CASH BOOK  |   |   |
| --- | --- | --- |
|  XYZ (Pty) Ltd | 6 100 |   |
|   |  | (2)  |

4

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©