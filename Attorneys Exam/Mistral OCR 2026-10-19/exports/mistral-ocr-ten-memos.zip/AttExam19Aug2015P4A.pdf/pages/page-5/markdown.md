# 3.8 Credit Business Cash Book (Debit Ledger)

BUSINESS CASH BOOK

|  XYZ (Pty) Ltd (RD Cheque) | 6 100  |
| --- | --- |

# 3.9 Transfer Journal (Trust/Business Cash Books)

|  Green Trust Ledger | Dr | 5000  |
| --- | --- | --- |
|  Green Business Ledger | Cr | 5000  |
|  Being Transfer of funds from Trust to Business  |   |   |

TRUST CASH BOOK

|   | Transfer | 5000  |
| --- | --- | --- |
|  BUSINESS CASH BOOK  |   |   |
|  Transfer | 5000 |   |

# 3.10 Trust Journal

|  A | Dr | 10 000  |
| --- | --- | --- |
|  B | Cr | 10 000  |
|  Being incorrect credit |   | (2)  |

# 3.11 Business Journal

|  Counsel | Dr | 5 700  |
| --- | --- | --- |
|  Mrs Divorce | Cr | 5 700  |
|  Being counsel's fees |   | (2)  |

# 3.12 Credit Trust Cash Book for R7 500 (Debit Trust Ledger of Black)

TRUST CASH BOOK

|  Black | 7 500  |
| --- | --- |
|  R/D | 10 000  |

You credit Trust Cash Book for R10 000 (and debit Black's Trust Ledger). You transfer R10 000 from Business Cash Book to Trust Cash Book

5

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©