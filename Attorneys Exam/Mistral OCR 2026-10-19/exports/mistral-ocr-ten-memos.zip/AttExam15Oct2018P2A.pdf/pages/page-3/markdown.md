|  Distribution Account Balance for distribution Awarded to: Vanessa Naidoo, major surviving spouse of the deceased, as sole heir i.t.o section 1(1) (a) of the Intestate Succession Act 81 of 1987, as amended (1) | 2 800 000.00 (1) | 2 800 000.00 (1)  |
| --- | --- | --- |
|  Award Consists of: Immovable property R1 500 000.00 (1) Movable property R 363 050.00 (1) Cash R 936 950.00 (1) | 2 800 000.00 | 2 800 000.00  |
|  Income & Expenditure Account Income Interest received on VB bank account Dividend paid on EBS Ltd shares |  | 6 050.00 (1) 13 950.00 (1)  |
|  Expenditure Executor's remuneration @ 6% on R 20 000.00 (1) Balance awarded to Vanessa Naidoo as sole heir (1) | 1 200.00 (1) 18 800.00 (1) 20 000.00 | 20 000.00  |
|  Fiduciary Assets Account Nil |  | 0.00 (1)  |
|  Estate Duty Addendum Property of the deceased Assets as per liquidation account Less: Liberty Life Policy payable to estate |  | 3 300 000.00 (1) 200 000.00 (1)  |
|  Add: Difference in value of private shares |  | 3 100 000.00 5 000.00 (1) 3 105 000.00  |
|  ADD: Property Deemed to be Property Add: Liberty Life Insurance Policy Old Mutual Life Policy payable to Thillay Less: Premiums plus 6% interest | 200 000.00 (1) 780 000.00 (1) 80 000.00 (1) | 900 000.00  |
|  GROSS VALUE OF THE DUTIABLE ESTATE |  | 4 005 000.00 (1)  |
|  LESS: Deductions – Sect 4 Funeral Expenses – sec 4(a) Other liabilities and claims (Absa bank overdraft) - sec 4(b) Costs of Administration - sec 4(c) Accrual claim against deceased's estate – sec 4(IA) | 18 400.00 (½) 200 000.00 (½) 176 600.00 (½) 105 000.00 (½) |   |
|  Note: Instead of mentioning the above 4 items separately, the candidate may answer "total liabilities" for 2 marks |  |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3