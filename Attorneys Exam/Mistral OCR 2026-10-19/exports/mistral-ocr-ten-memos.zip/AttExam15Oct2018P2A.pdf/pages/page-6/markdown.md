QUESTION 4

[7]

# ON THE LETTERHEAD

The Master of the High Court (1)

Dear Sir

RE: ESTATE LATE JOEL STEYN NO.967/18 (1)

We refer to the above matter and request an extension of four months (1) within which to lodge the Liquidation and Distribution Account in the above estate, which account is due on the 30th November 2018. We advise as follows:

1. We are waiting on the Receiver of Revenue to provide us with an income tax assessment, which is needed as the deceased was employed at the time of death. (1)
2. All assets have been valued and all cash collected. (1)
3. At present we are holding R9 000.00 in the estate bank account and R55 000.00 in the estate's saving account. These funds will be needed to meet the tax liability. (1)
4. The estate is solvent. (1)

We look forward to hearing from you in due course.

Yours faithfully

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6