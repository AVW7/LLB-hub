# ADMISSION EXAMINATION / TOELATING SEKSAMEN
ESTATES / BOEDELS
PART 2 / DEEL 2

15 OCTOBER / OKTOBER 2018

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A
CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

THIS GUIDELINE RECORDS THE VIEWS OF THE DRAFTERS. THERE MAY BE
JUSTIFIABLE VARIATIONS IN PRACTICE WHICH ARE BROUGHT OUT IN THE
ANSWERS. WHEN THIS HAPPENS THE EXAMINER SHOULD APPLY HIS DISCRETION
IN MARKING THE ANSWER.

QUESTION 1

[63]

THE FIRST AND FINAL LIQUIDATION AND DISTRIBUTION ACCOUNT IN THE ESTATE OF THE
LATE ANTHONY NAIDOO 650425 0099 088, (1) WHO DIED ON 9 AUGUST 2018 (1) AND WHO
WAS MARRIED OUT OF COMMUNITY OF PROPERTY WITH THE ACCRUAL SYSTEM. (1)

MASTER'S REFERENCE NO. 1854/2018 (1)

|  Liquidation account Assets: Immovable property |  |  |   |
| --- | --- | --- | --- |
|  Farm 188 Avos Pretoria Registration Division JR, Province of Gauteng Measuring 1600h. Held by Deed of Transfer No. T1346/1999 (1) Valued at to be awarded to Vanessa Naidoo, major surviving spouse, as sole heir i.t.o. section 1(1) (a) of the Intestate Succession Act 81 of 1987, as amended (1) | 1 |  | 1 500 000.00 (1)  |
|  Movable property Furniture and household effects Valued at 9mm Parabellum - Browning Serial number 823422 Per Gunston Sport valuation Shares in EBS Ltd valued by a stockbroker at (items 2,3&4 to be awarded to Vanessa Naidoo, major surviving spouse, as sole heir i.t.o. section 1(1) (a) of the Intestate Succession Act 81 of 1987, as amended (1) | 2 |  | 213 000.00 (1)  |
|   | 3 |  | 4 050.00 (1)  |
|   | 4 |  | 146 000.00 (1)  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1