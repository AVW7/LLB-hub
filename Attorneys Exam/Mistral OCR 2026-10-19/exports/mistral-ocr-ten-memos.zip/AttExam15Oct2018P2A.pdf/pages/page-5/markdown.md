If the unborn child is not born alive, then Simon, Daniel and Dolly will each inherit R87 500.00 (1) and Rose will inherit R337 500.00 (1) as intestate heirs.

Moses and Joseph will not inherit anything because descendants inherit before ascendants. (1)

# QUESTION 3

[17]

3.1 We hereby mass our separate estates (2) upon the death of the first dying of us and direct that the so massed estates shall, upon the death of the first dying (1), devolve upon our son Joseph (1), subject to the lifelong usufruct of the survivor of us (1).

3.2

# ADIATION CERTIFICATE

I the undersigned

Judy Wilson

in my capacity as the surviving spouse of the late Allan Wilson do hereby declare as follows:

I am aware of the conditions contained in the joint last Will and Testament of the deceased and myself dated 3 April 2015 which constitutes a massing of our separate estates. (1)

I am aware that I have the right to either accept or reject the said Will (1) and that the consequences of both acceptance and repudiation have been explained to me (1). Under the circumstances I have decided to adiate the terms of the Will (1) which will have the effect that I will forfeit my own estate in favour of our son Joseph and I will receive the usufruct of both estates. (1)

Witnesses: (1)

1.
2.

Surviving spouse (1)

I the undersigned, Robert Davids, an attorney, hereby certify that I have explained to the said Judy Wilson the consequences of either accepting or repudiating the joint Will of herself and the deceased (1). That she intimated that she fully understands the consequences of either accepting or repudiating the Will (1), and that she had after due consideration elected to accept the Will (1).

Witnesses: (1)

1.
2.

Attorney (1)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5