|  Cash and Assets Reduced to Cash |  |  |   |
| --- | --- | --- | --- |
|  A Toyota Run X Registration GYW 805 GP |  |  |   |
|  Sold for | 5 |  | 120 000.00 (1)  |
|  Liberty Life Insurance Policy No.137345X8 |  |  |   |
|  Proceeds of Policy | 6 |  | 200 000.00 (1)  |
|  Shares in A.R.L (Pty) Ltd |  |  |   |
|  Sold for | 7 |  | 142 000.00 (1)  |
|  Ornaments and Jewellery |  |  |   |
|  Sold by JP Jewellers for | 8 |  | 165 000.00 (1)  |
|  Investment at VB-bank |  |  |   |
|  Capital amount | 9 |  | 800 000.00 (1)  |
|  Interest as @ date of death | 10 |  | 9 950.00 (1)  |
|  Total Assets |  |  | 3 300 000.00  |
|  Liabilities: |  |  |   |
|  Administration Costs |  |  |   |
|  Advertising for Debtors and Creditor |  |  |   |
|  Government Gazette | 11 | 37.82 (1) |   |
|  The Star | 12 | 312.18 |   |
|  Advertising Account for inspection |  |  |   |
|  Government Gazette |  | 37.82 (1) |   |
|  The Star |  | 312.18 |   |
|  Master's fees |  | 6 400.00 (1) |   |
|  Executor's fees at 3.5% on R3 300 000.00 |  | 115 500.00 (1) |   |
|  D Nel -Valuation costs: Farm | 13 | 7 600.00 (1) |   |
|  Randel Valuators for valuation of movable property | 14 | 9 500.00 (1) |   |
|  Fouche Attorneys- Conveyancer's Fees | 15 | 15 340.00 (1) |   |
|  JPS Stockbrokers for valuation fees | 16 | 7 300.00 (1) |   |
|  Bank charges to date |  | 8 000.00 (1) |   |
|  Provision for further Bank charges |  | 6 000.00 (1) |   |
|  Postages and Petties |  | 260.00 (1) |   |
|  Claims against the estate |  |  |   |
|  REST - funeral expenses | 17 | 18 400.00 (1) |   |
|  Absa bank overdraft | 18 | 200 000.00 (1) |   |
|  Accrual claim against deceased's estate |  | 105 000.00 (1) |   |
|  Total Liabilities |  | 500 000.00 |   |
|  Estate Duty |  | 0.00 |   |
|  Balance for distribution |  | 2 800 000.00 |   |
|   |  | 3 300 000.00 |   |
|  Recapitulation Statement |  |  |   |
|  Cash and assets reduced to cash |  |  | 1 436 950.00 (1)  |
|  Less: |  |  |   |
|  Liabilities |  | 500 000.00 (1) |   |
|  Cash Legacies |  | NIL |   |
|  Estate Duty |  | NIL |   |
|  Cash surplus (to be awarded to Vanessa Naidoo as sole heir) |  | 936 950.00 |   |
|   |  | 1 436 950.00 (1) | 1 436 950.00  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2