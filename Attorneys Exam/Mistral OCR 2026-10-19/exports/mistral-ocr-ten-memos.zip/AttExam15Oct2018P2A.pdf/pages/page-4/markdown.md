|  Inheritance by the surviving spouse - sec 4(q) NET VALUE OF THE DUTIABLE ESTATE Less: Primary Rebate – Sect 4A DUTIABLE AMOUNT Estate Duty at 20% on R0.00 |  | 2 800 000.00 (1) | 3 300 000.00 705 000.00 (1) 3 500 000.00 (1) 0.00 (1) 0.00  |
| --- | --- | --- | --- |

# EXECUTOR'S CERTIFICATE

I, the undersigned, Vanessa Naidoo, the duly appointed executrix in the estate of the late Anthony Naidoo Estate Number 1854/2018, declare as follows:

1. That the attached account is to the best of my knowledge and belief a true and proper account of the liquidation and distribution of the estate; (1) and
2. That this is a final account and to the best of my knowledge and belief all the assets and income collected subsequent to the death of the deceased to the date of the account have been disclosed herein. (1)

SIGNED AT Pretoria ON THIS 1st DAY OF October 2018 (1)

VANESSA NAIDOO (EXECUTRIX)

# QUESTION 2

[13]

Rose, the wife is entitled to half share of the joint estate by virtue of the marriage in community of property in the amount of R600 000.00. (1)

The deceased's half share of R600 000.00 devolves as follows:

If the unborn child is born alive, Rose, Judas, Daniel, Vivian, Dolly and the unborn child (nasciturus rule) are the intestate heirs. (1)

Rose inherits a child's share or R250 000.00 whichever is the greater. (1)

A child's share amounts to R600 000.00 ÷ 6 = R100 000.00. (1)

Rose will therefore inherit the amount of R250 000.00. (1)

Since Judas murdered Bruce, Judas does not inherit (de bloedige hand erf niet). (1)

In terms of section 1(7) of the Intestate Succession Act, Simon will inherit Judas's share in the amount of R70 000.00. (1)

As Vivian has renounced her inheritance, the surviving spouse Rose receives her (Vivian's) portion in terms of section 1(6) of the Intestate Succession Act in the amount of R70 000.00 (1) and will therefore inherit a total amount of R320 000.00. (1)

Dolly, Daniel and the unborn child will also each inherit the amount of R70 000.00. (1)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4