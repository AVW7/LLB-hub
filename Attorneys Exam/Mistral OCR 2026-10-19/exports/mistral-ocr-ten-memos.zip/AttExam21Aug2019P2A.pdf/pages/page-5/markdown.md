2. That this is a final account and to the best of my knowledge and belief all the assets and income collected subsequent to the death of the deceased to the date of the account have been disclosed herein. (1)

SIGNED AT Pretoria ON THIS 1st DAY OF February 2019

ERIC DUBE (EXECUTOR)

QUESTION 2

[26]

# JOINT WILL

We, the undersigned,

CEDRIC JONES

Identity Number: 530812 5638 08 3

and

MABEL JONES (born Nel)

Identity Number: 581019 0417 08 8

spouses married in community of property and presently residing in Midrand, Gauteng Province, hereby make our Will as follows: (1)

# 1. REVOCATION OF PREVIOUS WILLS

We revoke all our previous Wills, codicils and testamentary writings made either jointly or individually, and declare this to be our last Will. (1)

# 2. APPOINTMENT OF EXECUTOR

2.1. We appoint the survivor of us as the executor of our estate, with the power of assumption (1). If we die simultaneously or should the survivor for any reason be unable or refuse to accept the appointment, we appoint our daughter Julia Bam (born Jones) as the executrix. (1)
2.2. Any executor appointed in terms of our Joint Will shall be exempt from furnishing security to the Master of the High Court. (1)

# 3. MASSING OF ESTATES AND BENEFICIARIES

3.1 We direct that on the death of the first dying of us (1), our joint community estates shall be massed and consolidated into a single estate (1), which we

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5