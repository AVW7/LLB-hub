# ADMISSION EXAMINATION / TOELATING SEKSAMEN

# ESTATES / BOEDELS

# PART 2 / DEEL 2

21 AUGUST / AUGUSTUS 2019

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

# NOTE TO EXAMINER:

THIS GUIDELINE RECORDS THE VIEWS OF THE DRAFTERS. THERE MAY BE JUSTIFIABLE VARIATIONS IN PRACTICE WHICH ARE BROUGHT OUT IN THE ANSWERS. WHEN THIS HAPPENS THE EXAMINER SHOULD APPLY HIS DISCRETION IN MARKING THE ANSWER.

# QUESTION 1

[60]

The First and Final Liquidation and Distribution Account in the estate of the late Sam Dube (Identity Number 520915 5638 08 3) (1) who died on 30 June 2018 (1) and who was married according to customary law, out of community of property without accrual (1). Master's reference number: 1369/2018. (1)

# Liquidation account

# Assets:

# Immovable property

1. The farm NAMBO 755, Brits
Registration Division, JQ, North-West Province;
Measuring 360 hectares;
Held by Deed of Transfer T1306/1987. (1)

# At Valuation

(To be transferred to Sarah Dube, major surviving spouse, as sole heir i.t.o. the Will of the deceased) (1)

# Movable property

2. Farm implements and Livestock At valuation
3. House-hold furniture and effects At valuation

(Items 2 and 3 to be awarded to Sarah Dube, major surviving spouse, as sole heir i.t.o. the Will of the deceased) (1)

# Cash & Assets Reduced to Cash

4. \(100\%\) Shares in VIC (Pty) Ltd Sold for
5. Absa Bank - Savings account No. 4050635667

2 100 000.00 (1)

900 000.00 (1)

135 000.00 (1)

1 100 000.00 (1)

175 000.00 (1)

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1