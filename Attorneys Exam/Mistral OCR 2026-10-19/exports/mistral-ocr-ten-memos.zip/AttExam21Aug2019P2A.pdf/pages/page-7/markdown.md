QUESTION 3

[8]

David inherits R1 750 000.00 half of the estate in terms of Section 1 (1) (d) (ii) of Act No. 81 of 1987. (1)

Louisa inherits nothing as she is not Vukela's parent (1)

Agnes inherits nothing as she is not a blood relative (1)

Phindi inherits nothing as she is not a surviving spouse (1)

Ronald and Joseph's two sons Peter and Alex inherit the balance of R1 750 000.00 as follows in terms of Section 1 (1) (d)(ii) of Act No. 81 of 1987 (1)

Ronald- R875 000.00 (1)

Peter - R437 500.00 (1)

Alex - R437 500.00 (1)

QUESTION 4

[6]

Net dutiable estate =R19 000 000.00 (1)

Less: Primary Rebate =R 3 500 000.00 (1)

Less: Roll over of Primary Rebate from Betty's estate =R 3 500 000.00 (2)

Dutiable Amount =R12 000 000.00 (1)

Estate Duty Payable @ 20% on R12 000 000.00 =R 2 400 000.00 (1)

TOTAL: [100]

# LAW SOCIETY

# OF SOUTH AFRICA

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7