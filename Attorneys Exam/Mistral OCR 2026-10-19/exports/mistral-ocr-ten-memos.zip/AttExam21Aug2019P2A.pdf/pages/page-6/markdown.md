bequeath to our aforesaid daughter Julia Bam (born Jones) (1) subject to a usufruct for life in favour of the survivor of us (1).

**TESTATRIX (1)**
**Paul Kumar**

**Signature by C.O.O (1)**

____________________
on behalf of and by the direction
of the **TESTATOR (2)**

3.2 If the aforesaid bequest to our daughter should fail for any reason, our massed estate shall devolve upon her children per stirpes. (1)

**4. EXCLUSION OF COMMUNITY OF PROPERTY AND ACCRUAL**

No inheritance or benefit accruing to any beneficiary in terms of this Will shall form part of any existing or future community estate of such beneficiary. We further direct that the right of accrual as contemplated in the Matrimonial Property Act, 88 of 1984, as amended, shall be excluded from any such inheritance or benefits. (1)

SIGNED AT MIDRAND ON 18TH MAY 2017 by the Testatrix, Paul Kumar on behalf of and by the direction of the Testator and the attesting witnesses all being present and signing simultaneously in the presence of one another. (2)

**WITNESSES:** (1)

1.

2.

**TESTATRIX (1)**

**Paul Kumar**

____________________
on behalf of and by the direction
of the **TESTATOR (2)**

**Certificate in terms of Sec 2(1)(a)(v) (1)**

I, Joyce Pillay of 150 Church Street Midrand, in my capacity as Commissioner of Oaths (1), certify that I have satisfied myself as to the identity of the testator Cedric Jones (1), and that the accompanying joint Will is the Will of the testator (1).

J Pillay

____________________ (1)

**Commissioner of Oaths**

Capacity:

Midrand 18th May 2017

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6