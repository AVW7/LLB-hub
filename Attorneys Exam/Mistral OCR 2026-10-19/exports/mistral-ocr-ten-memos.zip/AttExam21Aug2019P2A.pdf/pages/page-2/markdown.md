|  6. A 2015 Toyota Corolla motor vehicle with Registration number BYP 805 GP Sold for |  |  | 100 000.00 (1)  |
| --- | --- | --- | --- |
|  7. Sanlam Insurance Policy No.175345X9 Proceeds of Policy |  |  | 950 000.00 (1)  |
|  8. JSE quoted Shares Sold by Stockbrokers |  |  | 76 000.00 (1)  |
|  Total Assets |  |  | 5 536 000.00  |

|  Liabilities:  |   |
| --- | --- |
|  Administration Costs  |   |
|  1. Advertising for Debtors and Creditors (1) Government Gazette Pretoria News | 37.82 312.18  |
|  2. Advertising Account for inspection (1) Government Gazette Pretoria News | 37.82 312.18  |
|  3. Master's fees (maximum) | 7 000.00 (1)  |
|  4. Executor's fees at 3.5% on R5 536 000.00 | 193 760.00 (1)  |
|  5. 15% VAT on R193 760.00 | 29 064.00 (1)  |
|  6. Bank charges to date (1) | 6 000.00  |
|  7. Provision for further Bank charges (1) | 4 500.00  |
|  8. Postages and petties | 260.00 (1)  |
|  9. JPS Brokers fees for selling JSE shares | 7 600.00 (1)  |
|  10. P Smith – Valuation costs: farm & movable property (1) | 6 500.00  |
|  11. D Chivers Attorneys– Conveyancer's Fees and bond cancellation costs (1) | 20 000.00  |
|  Claims against the estate  |   |
|  12. Deep-Slumber – funeral expenses (1) | 27 616.00  |
|  13. Sanlam Insurance Co for loan on Policy No.126395X8 | 25 000.00 (1)  |
|  14. Land bank – outstanding amount on farm | 208 000.00 (1)  |
|  Total Liabilities | 536 000.00  |

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2