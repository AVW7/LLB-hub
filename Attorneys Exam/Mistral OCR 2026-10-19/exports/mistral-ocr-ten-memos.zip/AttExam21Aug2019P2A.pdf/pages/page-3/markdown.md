|  Estate Duty | Nil  |
| --- | --- |
|  Balance for distribution | 5 000 000.00 5 536 000.00  |

|  Recapitulation Statement |  |  |   |
| --- | --- | --- | --- |
|  Cash and assets reduced to cash |  |  | 2 401 000.00 (1)  |
|  Less: |  |  |   |
|  Liabilities | 536 000.00 (1) |  |   |
|  Cash Legacies | NIL |  |   |
|  Estate Duty | NIL |  |   |
|  Cash surplus | 1 865 000.00 (1) |  |   |
|   | 2 401 000.00 |  | 2 401 000.00  |
|  Distribution Account |  |  |   |
|  Balance for distribution |  |  | 5 000 000.00 (1)  |
|  Awarded to: |  |  |   |
|  Sarah Dube, major surviving spouse, as sole heir i.t.o. the Will of the deceased | (1) |  |   |
|  Award Consists of : |  |  |   |
|  Immovable Property R2 100 000.00 | (1) |  |   |
|  Movable Property R1 035 000.00 | (1) |  |   |
|  Cash R1 865 000.00 | (1) | 5 000 000.00 |   |
|   |  | 5 000 000.00 | 5 000 000.00  |
|  Income & Expenditure Account |  |  |   |
|  Interest paid on Absa Bank – Savings account |  |  | 6 250.00 (1)  |
|  Rental for the farm NAMBO for the period 1 July 2018 to 31 December 2018 |  |  | 15 000.00 (1)  |
|  Executor's remuneration @ 6% on R 21 250.00 | 1 275.00 (1) |  |   |
|  15% VAT on R1 275.00 | 191.25 (1) |  |   |
|  Balance awarded to Sarah Dube as sole heir | 19 783.75 (1) |  |   |
|   | 21 250.00 |  | 21 250.00  |
|  Fiduciary Assets Account |  |  |   |
|  None |  |  | Nil (1)  |

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3