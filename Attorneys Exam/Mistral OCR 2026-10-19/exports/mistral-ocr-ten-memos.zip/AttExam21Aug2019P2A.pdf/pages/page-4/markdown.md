|  Estate Duty Addendum |  |   |
| --- | --- | --- |
|  Property of the deceased |  |   |
|  Assets as per liquidation account |  | 5 536 000.00 (1)  |
|  Less: Sanlam Insurance Policy payable to estate | 950 000.00 (1) | 4 586 000.00  |
|  Less: Difference in value of private shares | 100 000.00 (1) | 4 486 000.00  |
|  Less: 30% on Farming property | 630 000.00 (1) | 3 856 000.00  |
|  Property Deemed to be Property |  |   |
|  Add: Sanlam Insurance Policy payable to estate | 950 000.00 (1) |   |
|  Old Mutual Insurance Policy | 500 000.00 (1) |   |
|  Liberty Life Insurance Policy | 1 100 000.00 (1) |   |
|  Less: Premiums plus 6% p.a compounded interest thereon | 100 000.00 (1) | 2 450 000.00  |
|  Gross value of the estate |  | 6 306 000.00 (1)  |
|  Deductions – Sect 4 |  |   |
|  Costs of Administration and claims | 536 000.00 (1) |   |
|  Inheritance to Sarah Dube– Sect 4(q) | 5 000 000.00 (1) |   |
|  Old Mutual policy to Jane Dube – Sect 4(q) | 500 000.00 (1) | 6 036 000.00  |
|  Net value of the estate |  | 270 000.00 (1)  |
|  Less: Primary Rebate – Sect 4A |  | 3 500 000.00 (1)  |
|  Dutiable Amount |  | 0.00 (1)  |
|  Estate Duty at 20% on R0.00 |  | 0.00  |

# EXECUTOR'S CERTIFICATE

I, the undersigned, Eric Dube, the duly appointed executor in the estate of the late Sam Dube Estate Number 1369/2018, declare as follows:

1. That the attached account is to the best of my knowledge and belief a true and proper account of the liquidation and distribution of the estate; (1) and

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4