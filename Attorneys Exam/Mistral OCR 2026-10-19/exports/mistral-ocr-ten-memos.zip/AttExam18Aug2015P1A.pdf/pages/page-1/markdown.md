# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
COURT PROCEDURES /HOFPROSEDURES
PART 1 / DEEL 1

18 AUGUST / AUGUSTUS 2015

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

# NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

# QUESTION 1

[15]

1.1 On or before 14 April 2015. (1)
1.2 Within 3 years after Andile attains majority (turns 18 years old). (1)
1.3 Yes - as he incurred these expenses in his personal capacity he is entitled to recover same. (2)
1.4 No. A minor's claim must be lodged by the natural parent and guardian. Sam, in his capacity as stepfather of Andile, does not possess the necessary locus standi to act in a representative capacity on Andile's behalf. As both of Andile's natural parents are deceased, a curator-ad-litem will have to be appointed to act on Andile's behalf. (3)
1.5 No. The Road Accident Fund Act has been amended to specifically exclude compensation for emotional shock suffered by a person who merely witnessed and observed, or was informed of, the death or injury of another person (a secondary victim). (2)
1.6 Past Medical Expenses (1/2)

Future Medical Expenses (½)

Future loss of earnings (½)

General damages (½)

1.7 No. You are entitled to recover past medical expenses from the RAF whether or not these have been paid by a medical aid scheme as such payments are insurance payments and are considered collateral benefits that do not fall to be deducted by the RAF. (2)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

1