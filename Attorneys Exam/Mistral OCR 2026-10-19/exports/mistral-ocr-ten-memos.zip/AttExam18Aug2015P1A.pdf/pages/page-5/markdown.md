QUESTION 9

[4]

9.1

1. That the charge does not comply with the provisions of the Criminal Procedure Act relating to the essentials of a charge.
2. That the charge does not set out an essential element of the relevant offence.
3. That the charge does not disclose an offence.
4. That the charge does not contain sufficient particulars of any matter alleged in the charge.
5. That the accused is not correctly named or described in the charge. Any three will be accepted. (3)

9.2 Before pleading to the charge. (1)

QUESTION 10 [6]

IN THE MAGISTRATE'S COURT FOR THE DISTRICT OF PRETORIA
HELD AT PRETORIA

CASE NO: 1234/2014

In the matter between:

THE STATE

And

XOLANI MSUTU

STATEMENT IN TERMS OF SECTION 115 OF THE CRIMINAL PROCEDURE ACT

I, Xolani Msutu, do hereby declare that:

1. I am the accused in this matter and understand the nature of the charge against me.
2. I admit that on the \(3^{\text{rd}}\) of March 2014 I was the driver of motor vehicle XYZ157NC in Proes Street, Pretoria.
3. I admit whilst driving the said vehicle a collision occurred between the said vehicle and the deceased ABC, a child, who was injured and died as a consequence of injuries he sustained in the collision.
4. I deny that the said collision was occasioned by any negligence on my part as same resulted from a mechanical failure in the braking system of the motor vehicle.
5. I admit the contents of the post-mortem medico legal report of Dr Jacobs relating to the identity of the deceased the injuries which she sustained as well as the cause of death. I furthermore admit that the deceased did not suffer any further injuries from the time of the collision until such time as the post - mortem was carried out.
6. I further admit the contents of the following documents:

Plan and photo album of the scene compiled by Victor Mpofu;

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

5