I hereby certify that the deponent has acknowledged that he/she knows and understands the contents of this affidavit which was sworn to and signed before me at

on this day of 2014 the regulations contained in Government

Notice No. 1258 dated the 21 July 1972 as amended by Government Notice No. R773 of 1982, having been compiled with.

# COMMISSIONER OF OATHS

# QUESTION 13 [4]

13.1 Any time up to judgment (candidates may add in the following: including judgment on appeal). (1)
13.2 Give security for the claim and costs. (2)
13.3 No (but see Rule 23(4)). (1)

# QUESTION 14 [6]

14.1 Apply for security for costs. (1)
14.2 File a special plea pleading prescription. (1)
14.3 Send a notice to the Plaintiff advising that the Summons is vague and embarrassing and affording him an opportunity to remedy the defect. Should he fail to do so then an exception should be filed. (2)
14.4 Send the plaintiff a Notice in Terms of Rule 18(1) which is an offer of settlement on a without prejudice basis offering him R 35 000,00 plus costs to date. (2)

# QUESTION 15 [4]

Client should be advised to proceed by way of provisional sentence.

The court has to decide on the papers before it whether on a balance of probabilities the defendant would win the case. If not provisional sentence would be entered.

On the other hand if Summons is issued followed on an Appearance to Defend then an Application for Summary Judgment would be filed, the onus is far easier for the Defendant as he merely has to show that he has a bona fide defence to the action. (The answer may differ if the candidate refers to the Twee Jonge Gezellen (Pty) Ltd. versus Land and Agricultural Development Bank of South Africa 2011).

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

7