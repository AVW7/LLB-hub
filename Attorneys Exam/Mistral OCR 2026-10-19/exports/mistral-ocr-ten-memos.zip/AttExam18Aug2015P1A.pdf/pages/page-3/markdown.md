- If the parties agree in writing that the pleadings are closed and such agreement is filed with the registrar (1 mark).
- If the parties are unable to agree as to the close of pleadings and the court upon the application of either party declare them closed (1 mark). (4)

# QUESTION 4 [3]

4.1 True (1/2)
4.2 True (1/2)
4.3 False (1/2)
4.4 False (1/2)
4.5 True (1/2)
4.6 True (1/2)

# QUESTION 5 [5]

# PLAINTIFF'S NOTICE OF INTENTION TO AMEND IN TERMS OF RULE 28 (1 mark)

PLEASE TAKE NOTICE that plaintiff intends to amend his particulars of claim in the following respects (1 mark) and that unless written notice of objection (1 mark) is received within ten (10) days from date of delivery (1 mark) hereof the amendment will be effected accordingly:

1. By deleting the date/month where it appears in paragraph (?) of the particulars of claim and substituting therefor the date/month "10 May 2013" / "May". (1 mark)

(Note to examiner: some candidates may prefer to delete the date as a whole whilst others may prefer to amend only the month. Either is correct and 1 mark can be allocated.)

# QUESTION 6 [6]

6.1.

Liquid document (1 mark)
Liquidated amount (1 mark)
Delivery of specified movables (1 mark)
Ejectment (1 mark) (4)

6.2.1 Notice of intention to defend. (1)
6.2.2 Notice to oppose. (1)

# QUESTION 7 [5]

(a) At any stage but before sentence is passed.

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

3