1.8 Yes. The psychological sequelae of a physical bodily injury suffered by a primary victim (person actually involved and physically injured) are deemed to be bodily injuries that are NOT excluded by the Act. (2)

# QUESTION 2

[10]

2.1. - No.
In terms of the Road Accident Fund Amendment Act 19 of 2005 [Section 17 (4) (c) (i)] a claim for loss of income is capped such that a claimant is only entitled to claim annual loss of an amount not exceeding the amount as published in the Government Gazette quarterly. (2)
2.2. None In terms of the Road Accident Fund Amendment Act the common law claim against the wrongdoer has been expressly excluded. (2)
2.3 The RAF must object within 90 days from the date on which the RAF 4 was sent by registered post or hand delivered to the RAF (Regulation 3 (e)). (2)
2.4. No - In terms of the Regulations (Regulation 3 (f)) the dispute in respect of the RAF 4 must be adjudicated by an appeal tribunal constituted by the Registrar of the Health Professionals Council of South Africa. (2)
2.5 Your client is only entitled to costs once the matter is litigated (summons is issued) and where costs are ordered by the court. (2)

# QUESTION 3

[11]

3.1

- Simple summons (½ mark) - it can only be used for liquidated demands (½ mark)
Combined summons (½ mark) - it can be used in all cases where action procedure is appropriate (½ mark).
Provisional sentence summons (½ mark) - it can only be used in cases where the claim is based on a liquid document (½ mark). (3)

3.2

Appeals (½ mark)
Rule 43 applications (½ mark)
Interdicts (½ mark)
Consolidation of actions (½ mark)
Third party procedure (½ mark)
Joinder of parties (½ mark) (3)

3.3 It is an application brought without notice to anyone except the Registrar, either because no relief is sought against any person, or it is not necessary to give notice to the respondent. (1)

3.4

If any of the parties joined issue without alleging any new matter and without adding any further pleadings (1 mark).
- If the last day allowed for filing of a replication or subsequent pleading has lapsed and it has not been filed (1 mark).

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

2