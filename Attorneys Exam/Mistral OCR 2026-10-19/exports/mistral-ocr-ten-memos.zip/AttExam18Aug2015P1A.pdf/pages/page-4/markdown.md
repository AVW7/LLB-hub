(b) If the Court is in doubt whether the accused is in law guilty of the offence to which he has pleaded guilty.
(c) If it appears to the Court that the accused does not admit an allegation in the charge.
(d) That the accused has incorrectly admitted such an allegation.
(e) That the accused has a valid defence to the charge.
(f) If the court is of opinion for any reason that the accused's plea of guilty should not stand.

Any five will be marked correct.

# QUESTION 8

[10]

8.1 Assault with the intent to do grievous bodily harm. (1)
8.2 Common assault or just assault. (1)
8.3 Approach the Public Prosecutor in an attempt to persuade him/her to accept a plea of guilty to the alternative charge of common assault. Motivate your request by pointing out:
8.3.1 Your client was extremely provoked.
8.3.2 The complainant's conduct was despicable and embarrassed your client.
8.3.3 Your client did not use a weapon or object.
8.3.4 Your client did not realise the possibility of inflicting such a serious injury on the complainant. (3)
8.4

# STATEMENT IN TERMS OF SECTION 112(2)

1. I, the undersigned, Yaya Eto, plead guilty to the charge (or offence) of assault (or the candidate can state plead guilty to the charges against me).
2. I am of sober mind and plead guilty voluntarily and without duress or undue influence.
3. I admit that on the 11 July 2014 and in the cafeteria on the premises of the University of Western Cape, Bellville, I assaulted Conrad Coetzee by hitting him twice in his face, with a clenched fist thereby fracturing his jaw.
4. I aver that I was severely provoked by the complainant immediately prior to hitting him, by his stating that I was unlawfully in SA without authorisation, was an illegal immigrant and that I was depriving South Africans of the opportunity to study. This was stated loudly, repeatedly in the cafeteria before many fellow-students. Despite the aforegoing I admit I had no lawful reason to strike him.
5. I know and understand that my action was wrongful and unlawful and that I can be punished. I accordingly plead guilty to assaulting the complainant as set out in the charge sheet. (5)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

4