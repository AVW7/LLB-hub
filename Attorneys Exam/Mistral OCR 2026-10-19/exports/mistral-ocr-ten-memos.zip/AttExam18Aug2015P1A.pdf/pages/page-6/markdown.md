7. These admissions can be noted in terms of Section 220 of the criminal procedure act.

DATED AT PRETORIA ON THE 14TH DAY OF JULY 2014.

XOLANI MSUTU

# QUESTION 11

[7]

1. Defendant is Maria Mlaba, secretary, living at 18 West Street Durban.
2. Defendant duly signed the said loan agreement in Durban on \(30^{\text{th}}\) July 2013.
3. The cause of action did not arise wholly in the Johannesburg region in that the loan agreement was signed in Durban and thus in terms of Section 28 of the Magistrate's Court Act 32 of 1944, the Johannesburg court does not have jurisdiction.
4. Defendant avers she paid the debt on or about 28 December 2013.

Wherefore defendant prays that the action be dismissed with costs.

# QUESTION 12

[4]

I, the undersigned, JOHN SMITH do hereby make oath and say:

1.

I am the Financial Director of the Plaintiff company and am duly authorised to depose to this Affidavit, the facts contained herein within my own personal knowledge and belief.

2.

I have had access to the Plaintiff's records and documents in this matter and verify and confirm Plaintiff's cause of action and the amount as claimed in the summons.

3.

A copy of the Notice of Intention to Defend is annexed hereto marked "A".

4.

In my opinion I verily believe that the defendant does not have a bona fide defence to the action and that the Appearance has been entered solely for the purpose of delay.

DEPONENT

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

6