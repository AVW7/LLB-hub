2) Alex Dube, major son (1)

in terms of Section

1(1)(c)(ii) of the Intestate

Succession Act No. 81 of 1987 (1) 977 256,25

The above award consists of a ¼

share in

Immovable property awarded 412 500,00

Movable property awarded 93 500,00

Cash 471 256,25

3) Nomsa Dube, minor daughter

born on 20 June 1998 (1), identity

no. 980620 5135 08 3 (1)in terms

of Section 1(1)(c)(ii) of the Intestate

Succession Act No. 81 of 1987 977 256,25

The above award consists of a ¼

share in

Immovable property awarded 412 500,00

Movable property awarded 93 500,00

Cash to be deposited in

the Guardians Fund 471 256,25 (1)

4) Thando Dube, major son (1)

in terms of Section

1(1)(c)(ii) of the Intestate

Succession Act No. 81 of 1987 (1) 977 256,25

Legal Education and Development [L.E.A.D]™

4