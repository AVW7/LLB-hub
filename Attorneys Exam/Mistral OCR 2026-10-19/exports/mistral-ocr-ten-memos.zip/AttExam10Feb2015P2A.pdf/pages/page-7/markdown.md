QUESTION 2

[25]

# JOINT WILL

We, the undersigned,

HECTOR DAWOOD

Identity Number: 570812 5016 08 8

and

DORCAS DAWOOD

Identity Number: 601019 0017 08 8[1]

spouses married in community of property and presently residing in Boksburg, Gauteng Province, hereby make our Will as follows:

# 1. REVOCATION OF PREVIOUS WILLS

We revoke all our previous Wills, codicils and testamentary writings made either jointly or individually, and declare this to be our last Will. [2]

# 2. APPOINTMENT OF EXECUTOR

2.1 We appoint the survivor of us as the executor of our estate, with the power of assumption [1]. If we die simultaneously or should the survivor for any reason be unable or refuse to accept the appointment, we appoint Snow Fall, a director of the legal firm Snowing Incorporated of Boksburg as the executor of our estate, with the power of assumption. [1]
2.2 Any executor appointed in terms of our Will shall be exempt from furnishing security to the Master of the High Court. [1]

# TESTATRIX [1]

Johanna Kgopa

Jack Frost [1]

[1]

C of Oaths

on behalf of and by the direction of the testator Hector [1]

Legal Education and Development [L.E.A.D]™

7