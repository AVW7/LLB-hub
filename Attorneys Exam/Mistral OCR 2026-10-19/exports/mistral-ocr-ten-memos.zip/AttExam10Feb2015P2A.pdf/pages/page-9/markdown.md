# Commissioner of Oaths

Capacity:

Boksburg 15th June 2014

# QUESTION 3

[15]

Lucky's estate will devolve as follows:

Betty inherits either a child's share or R125 000.00, whichever is the greater (Section 1(1)(c) ) of the Intestate Succession Act, as amended. [1]

A child's share is R762 000.00 ÷ 6 = R127 000.00 [2]

Betty therefore inherits R127 000.00 [1]

Cindi inherits either a child's share or R125 000.00, whichever is the greater (Section 1(1)(c) ) of the Intestate Succession Act, as amended.

A child's share is R762 000.00 ÷ 6 = R127 000.00

Cindi therefore inherits R127 000.00 [1]

Danny cannot renounce his rights to inherit as he is a minor (Section 1(6)) [2]
He therefore inherits R127 000.00.

Since Jan has caused his father's death, Jan does not inherit (die bloedige hand erf niet) [2]

In terms of section 1(7) of the Intestate Succession Act, Karel will inherit Jan's share in the amount of R127 000.00 [2]

His major daughter Iris inherits R127 000.00 because she is the descendant in terms of Section 1(1)(c) of the Intestate Succession Act. [1]

As Susan has renounced her inheritance, the surviving spouses Betty and Cindi will receive her (Susan's) portion in terms of section 1(6) of the Intestate Succession Act in the amount of R63 500.00 each [2]

Therefore Betty and Cindi inherit a total amount of R190 500.00 each. [1]

Legal Education and Development [L.E.A.D]™

9