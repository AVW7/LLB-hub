# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
ESTATES / BOEDELS
PART 2 / DEEL 2

10 FEBRUARY / FEBRUARIE 2015

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A
CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be
justifiable variations in practice which are brought out in the answers.
When this happens the examiner should apply his discretion in marking
the answer.

QUESTION 1

[48]

LIQUIDATION ACCOUNT:

ASSETS

IMMOVABLE PROPERTY AWARDED:

ERF 332 GREYTOWN, REGISTRATION

DIVISION FT, PROVINCE OF KWAZULU

NATAL (1), IN EXTENT 1025 SQUARE METRES (1)

Held in terms of Deed of Transfer No. T4317/2004 (1) (1)

Per municipal valuation

1.650 000,00

DIVESTMENT NOTE:

The above asset will be transferred to the

intestate heirs (1)

MOVABLE PROPERTY AWARDED:

Household contents at valuation

(½) (2)

325 000,00

3000 Sanlam shares

(½) (3)

41 000,00

4 Head of cattle at valuation

(½) (4)

8 000,00

Legal Education and Development [L.E.A.D]™

1