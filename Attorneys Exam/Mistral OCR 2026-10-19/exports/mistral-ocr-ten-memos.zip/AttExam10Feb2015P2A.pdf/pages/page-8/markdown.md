# 3. MASSING OF ESTATES AND BENEFICIARIES

3.1 We direct that on the death of the first dying of us, our separate estates shall be massed and consolidated into a single estate [1], which we bequeath to our aforesaid son Steve [1] subject to a usufruct for life in favour of the survivor of us [1].
3.2 If the aforesaid bequest to our son should fail for any reason, our massed estate shall devolve upon his children per stirpes. [1]

# 4. EXCLUSION OF COMMUNITY OF PROPERTY AND ACCRUAL

No inheritance or benefit accruing to any beneficiary in terms of this Will shall form part of any existing or future community estate of such beneficiary [1]. We further direct that the right of accrual as contemplated in the Matrimonial Property Act, 88 of 1984 shall be excluded from any such inheritance or benefits. [1]

SIGNED AT BOKSBURG ON 15TH JUNE 2014 by Snow Fall on behalf of and by the direction of the Testator, the Testatrix and the attesting witnesses all being present and signing simultaneously in the presence of one another. [1]

# WITNESSES:

1. H Muller [1]

TESTATRIX [½]

2. R Symes [1]

Jack Frost

on behalf of and by the direction
of the testator Hector [½]

Certificate in terms of Sec 2(1)(a)(v) [1]

I, Johanna Kgopa of 190 Pretorius Street Boksburg, in my capacity as Commissioner of Oaths [1], certify that I have satisfied myself as to the identity of the testator Hector Dawood [1], and that the accompanying Will is the Will of the testator [1].

J Kgopa

[1]

Legal Education and Development [L.E.A.D]™

8