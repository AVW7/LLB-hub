# **DIVESTMENT NOTE:**

The above assets will be awarded to the

intestate heirs

# **ASSETS REDUCED TO CASH**

40% shareholding in Nordic (Pty) Ltd realised (1) (5) 1 250 000,00

2000 Sasol shares realised (½) (6) 100 000,00

Absa Bank: Fixed Deposit Account

No. 0231478 240 000.00 (½)

Interest as at date of death 1 000.00 (1) (7) 241 000,00

Old Mutual Policy No. OLM621943 (½) (8) 950 000,00

Metropolitan Policy No. X07311624 (½) (9) 300 000,00

TOTAL ASSETS R4 865 000,00

# **LIABILITIES:**

1. Masters fees (maximum) (1) 600,00
2. Executors fees (3.5% of R4 865 000.00) (1) 170 275,00
3. Other Administration Expenses 2700,00
4. Funeral Expenses: Siza Funerals (½) 12000,00
5. ADT Attorneys: Provision for transfer fees (½) 27500,00

Provision for bond cancellation costs (½) 2 500,00

6. Dr Good: Medical Expenses (½) 11700,00
7. J Adams: valuation costs in respect of movables (½) 2400,00
8. Absa Bank, settlement of bond over

Erf 332 Greytown (½) 670 000,00

9. Final income tax assessment from SARS (½) 16300,00
10. Loan against Old Mutual Policy (1) 40000,00

Legal Education and Development [L.E.A.D]™

2