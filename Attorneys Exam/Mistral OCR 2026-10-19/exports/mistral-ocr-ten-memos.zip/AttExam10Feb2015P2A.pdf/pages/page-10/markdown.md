QUESTION 4

[12]

B, as a witness, is disqualified from receiving any benefit under the will – section 4A(1) of the Wills Act. (1)

However, in terms of section 4A(2) –

(a) A court may declare B to be competent to receive his benefit if the court is satisfied that B did not defraud or unduly influence A in the execution of the will. (2)
(b) If B would have inherited if A had died intestate, B may inherit under the will as much as what he would have inherited as an intestate heir (but no more). (3)

To the extent that B does not receive his benefit in whole or in part, his divorced wife D will inherit as his substitute. Only if D had been married to B at the time of execution of the will would she have been disqualified. (2)

E is disqualified because he murdered A. "De bloedige hand erf niet". (1)

Section 2C(2) of the Wills Act provides that if a descendant of the testator is disqualified from inheriting, the descendants of that descendant shall be entitled to the benefit. E's daughter F therefore inherits what E would have inherited, had he not murdered his Father A. (2)

F inherits whatever has been left directly to her in A's will. (1)

TOTAL: [100]

Legal Education and Development [L.E.A.D]™

10