Gross Value of estate

7 065 000,00

LESS : Allowable deductions in

terms of Section 4

Liabilities

(1)

955 975,00

Bequest to surviving spouse

Section 4(q)

[R977256.25+R2000000.00]

(2)

2 977 256,25

3 933 231,25

Net Value

(1)

3 131 768,75

LESS primary rebate in terms

of Section 4 (A)

(1)

3 500 000,00

Dutiable amount

(1)

NIL

Therefore no estate duty payable. (1)

# LAW SOCIETY

# OF SOUTH AFRICA

Legal Education and Development [L.E.A.D]™

6