The above award consists of a ¼

share in

Immovable property awarded 412 500,00

Movable property awarded 93 500,00

Cash 471 256,25

3 909 025,00 3 909 025,00

# ESTATE DUTY ADDENDUM:

Property of the deceased

in terms of Section 3(2)

Assets as per Liquidation

and Distribution Account 4 865 000,00 (1)

LESS: Old Mutual policy paid to Estate (½) 950 000,00

Metropolitan policy paid to estate (½) 300 000,00 1 250 000,00

LESS: Adjustment on shares in Nordic

(Pty) Ltd 400 000,00 (2)

3 215 000,00

PLUS : Property deemed to be property in

terms of Section 3(3)

Sanlam policy (1) 2 000 000,00

Old Mutual policy (½) 950 000,00

Momentum policy (1) 600 000,00

Metropolitan policy (½) 300 000,00 3 850 000,00

Legal Education and Development [L.E.A.D]™

5