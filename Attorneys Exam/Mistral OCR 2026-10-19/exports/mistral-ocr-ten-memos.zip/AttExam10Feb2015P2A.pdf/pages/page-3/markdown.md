Total Liabilities 955 975,00

Estate Duty NIL

Balance available for Distribution 3 909 025,00

4 865 000,00

# RECAPITULATION STATEMENT:-

Assets reduced to cash 2 841 000,00(2)

Liabilities 955 975,00 (1)

Estate Duty NIL

Cash surplus available for distribution 1 885 025,00 (2)

2 841 000,00 2 841 000,00

# DISTRIBUTION ACCOUNT

Balance available for distribution (1) 3 909 025,00

Awarded to:-

1) Thule Dube, surviving spouse (1)

in terms of Section

1(1)(c)(i) of the Intestate

Succession Act No. 81 of 1987 (1) 977 256,25

The above award consists of a ¼

share in

Immovable property awarded 412 500,00 (1)

Movable property awarded 93 500,00 (1)

Cash 471 256,25 (1)

Legal Education and Development [L.E.A.D]™

3