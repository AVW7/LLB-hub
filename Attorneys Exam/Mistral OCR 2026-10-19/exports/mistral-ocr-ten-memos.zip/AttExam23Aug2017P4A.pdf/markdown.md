# ADMISSION EXAMINATION / TOELATINGSEKSAMEN

# BOOKKEEPING / BOEKHOU

# PART 4 / DEEL 4

23 AUGUST / 23 AUGUSTUS 2017

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

QUESTION 1

[15]

1.1

SUPPLEMENTARY BUSINESS CASHBOOK FOR 28 FEB 2016 (1)

|  Deposit | 3 000 (1) | Balance | 10 000 (1)  |
| --- | --- | --- | --- |
|  Deposit error | 7 000 (1) | R.D Cheque | 26 000 (1)  |
|  Balance | 40 000 (1) | Interest paid | 3 000 (1)  |
|   |  | Bank charges | 4 000 (1)  |
|   |  | Stop order | 7 000 (1)  |
|   | 50 000 |  | 50 000  |

(9)

1.2

BUSINESS BANK RECONCILIATION STATEMENT AT 28 FEB 2016 (1)

Balance as per Cash book (1) (40 000)

Less Bank error (1) 10 000

(1) (30 000)

12 000

Less Bank error (1) (18 000)

Add outstanding cheques (1) 10 545

Balance as per Bank Statement (28 455)

(6)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1

Or Format Based on Bank Statement Layout:

|  BUSINESS BANK RECONCILIATION STATEMENT AT 28 FEB 2016 |   |   | (1)  |
| --- | --- | --- | --- |
|   |  | Debit | Credit  |
|  Balance as per Cash Book | (1) |  | 40 000  |
|  Add bank error | (1) | 10 000 |   |
|  Add bank error | (1) | 12 000 |   |
|  Less Outstanding deposit | (1) |  | 10 545  |
|  Balance as per bank statement | (1) | 28 455 |   |
|   |  | 50 545 | 50 545  |

QUESTION 2 [30]

TRUST CASH BOOK

|  Correspondent (1) | 13 352 | Black | 11 528 (1)  |
| --- | --- | --- | --- |
|   |  | Transfer to business | 1 824 (1)  |
|   | 13 352 |  | 13 352  |

BUSINESS CASH BOOK

Transfer from trust (1) 1 824

CORRESPONDENT – TRUST ACCOUNT

|  Black | 18 000 | Cash | 13 352 (1)  |
| --- | --- | --- | --- |
|  Transfer to business (1) | 1 824 | Black | 6 472 (1)  |
|   | 19 820 |  | 19 820  |

BLACK – TRUST ACCOUNT

|  Correspondent (1) | 6 472 | Correspondent | 18 000 (1)  |
| --- | --- | --- | --- |
|  Cash – self (1) | 11 528 |  |   |
|   | 18 000 |  | 18 000  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2

# CORRESPONDENT – BUSINESS ACCOUNT

|  ½ Allowance (1) | 1 824 | Transfer from Trust | 1 824 (1)  |
| --- | --- | --- | --- |
|  FEES  |   |   |   |
|   |  | Correspondent - ½ Allowance | 1 600 (1)  |

# VAT OUTPUT

|   | Correspondent - ½ Allowance | 224 (1)  |
| --- | --- | --- |
|  TRUST JOURNAL (1)  |   |   |
|  Black – Trust Account | 6 472 (1) |   |
|  Correspondent – Trust Account |  | 6 472 (1)  |
|  Correspondent fees and disbursements (1) |  |   |
|  Correspondent – Trust Account | 18 000 (1) |   |
|  Black – Trust Account |  | 18 000 (1)  |
|  Transfer collection ex White (1) |  |   |

# FEES JOURNAL (1)

|  Correspondent – Business Account | 1 824 (1)  |
| --- | --- |
|  Fees | 1 600 (1)  |
|  VAT Output | 224 (1)  |
|  ½ Allowance Black vs. White (1) |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3

# **TRANSFER JOURNAL (1)**

Correspondent – Trust Account

1 824 (1)

Correspondent – Business Account

1 824 (1)

Transfer ½ Allowance (1)

# **QUESTION 3**

**[25]**

TRUST CASH BOOK

|  David ½ | (1) | 50 000 | Transfer to business | 36 000 | (1)  |
| --- | --- | --- | --- | --- | --- |
|   |  |  | David | 14 000 | (1)  |
|   |  | DAVID (T) |  |  |   |
|  Transfer to business | (1) | 36 000 | Deposit | 50 000 | (1)  |
|  Bank self | (1) | 14 000 |  |  |   |

BUSINESS CASH BOOK

|  Transfer ex trust | (1) | 36 000  |
| --- | --- | --- |

DAVID (B)

|  Revenue stamps | (1) | 1800 | Transfer ex trust | 36 000 | (1)  |
| --- | --- | --- | --- | --- | --- |
|  Fees | (1) | 34 200 |  |  |   |
|   |  | 36 000 |  | 36 000 |   |

FEES

|   | David | 30 000 (1)  |
| --- | --- | --- |
|  REVENUE STAMPS  |   |   |
|   | David | 1 800 (1)  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4

# VAT OUTPUT

|   | David | 4 200 (1)  |
| --- | --- | --- |

# FEES JOURNAL

David (B) 34 200 (1)

Fees 30 000 (1)

Vat Output 4 200 (1)

Fees in respect of registration of trust and preparation of estate plan

# REVENUE/STAMP BUSINESS JOURNAL

David (B) 1 800 (1)

Revenue Stamps 1 800 (1)

Stamps issued for registration of trust

# TRANSFER JOURNAL

David (T) 36 000 (1)

David (B) 36 000 (1)

Transfer fees and disbursements

# ACCOUNTING STATEMENT

David

Re: Registration of trust and preparation of estate plan

Deposit 50 000 (1)

Revenue stamps (1) 1 800

Our fees (1) 30 000

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5

Vat at 14%

(1) 4 200

Cheque herewith

(1) 14 000

50 000 50 000

# QUESTION 4

[30]

4.1

TRUST CASH BOOK

|  Reddy | 400 000 | Bank | 400 000  |
| --- | --- | --- | --- |
|  Van Der Merwe | 1 000 000 | Nedbank | 1 500 000  |
|  Ngubane | 685 000 | Seller | 500 000  |
|  Adams | 300 000 | Att Fidelity Fund | 15 000  |
|  Khoza | 500 000 | Reddy | 22 000  |
|  Nedbank | 1 515 000 | Balance | 2 385 000  |
|  Bank | 422 000 |  |   |
|   | 4 822 000 |  | 4 822 000  |

(½) S78(2)(a) NEDBANK

|  Cash | 1 500 000 | Cash | 1 515 000  |
| --- | --- | --- | --- |
|  Cash – Law Society | 15 000 |  |   |
|   | 1 515 000 |  | 1 515 000  |

# TRUST LEDGER

REDDY

|   | Cash | 400 000  |
| --- | --- | --- |

VAN DER MERWE

|   | Cash | 1 000 000  |
| --- | --- | --- |

(½) BANK S78(2)(A) (REDDY)

|  Cash | 400 000 | Cash | 422 000  |
| --- | --- | --- | --- |
|  Reddy | 22 000 |  |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6

NGUBANE

|   | Cash | 685 000  |
| --- | --- | --- |

ADAMS

|   | Cash | 300 000  |
| --- | --- | --- |

KHOZA

|  Seller | 500 000 | Cash | 500 000  |
| --- | --- | --- | --- |

(25)

### 4.2 TRUST LIABILITIES

Reddy 400 000

Van Der Merwe 1 000 000

Ngubane 685 000

Adams 300 000

2 385 000

(5)

TRUST FUNDS AVAILABLE

Trust cash book 2 385 000

Note to marker: one mark for each ledger and cash book entry and ½ mark for the bank investment headings.

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7