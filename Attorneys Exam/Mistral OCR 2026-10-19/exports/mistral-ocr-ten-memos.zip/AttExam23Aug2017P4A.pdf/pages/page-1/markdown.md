# ADMISSION EXAMINATION / TOELATINGSEKSAMEN

# BOOKKEEPING / BOEKHOU

# PART 4 / DEEL 4

23 AUGUST / 23 AUGUSTUS 2017

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

QUESTION 1

[15]

1.1

SUPPLEMENTARY BUSINESS CASHBOOK FOR 28 FEB 2016 (1)

|  Deposit | 3 000 (1) | Balance | 10 000 (1)  |
| --- | --- | --- | --- |
|  Deposit error | 7 000 (1) | R.D Cheque | 26 000 (1)  |
|  Balance | 40 000 (1) | Interest paid | 3 000 (1)  |
|   |  | Bank charges | 4 000 (1)  |
|   |  | Stop order | 7 000 (1)  |
|   | 50 000 |  | 50 000  |

(9)

1.2

BUSINESS BANK RECONCILIATION STATEMENT AT 28 FEB 2016 (1)

Balance as per Cash book (1) (40 000)

Less Bank error (1) 10 000

(1) (30 000)

12 000

Less Bank error (1) (18 000)

Add outstanding cheques (1) 10 545

Balance as per Bank Statement (28 455)

(6)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1