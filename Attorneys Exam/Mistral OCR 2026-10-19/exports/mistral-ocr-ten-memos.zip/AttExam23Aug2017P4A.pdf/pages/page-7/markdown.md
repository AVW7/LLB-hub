NGUBANE

|   | Cash | 685 000  |
| --- | --- | --- |

ADAMS

|   | Cash | 300 000  |
| --- | --- | --- |

KHOZA

|  Seller | 500 000 | Cash | 500 000  |
| --- | --- | --- | --- |

(25)

### 4.2 TRUST LIABILITIES

Reddy 400 000

Van Der Merwe 1 000 000

Ngubane 685 000

Adams 300 000

2 385 000

(5)

TRUST FUNDS AVAILABLE

Trust cash book 2 385 000

Note to marker: one mark for each ledger and cash book entry and ½ mark for the bank investment headings.

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7