# **TRANSFER JOURNAL (1)**

Correspondent – Trust Account

1 824 (1)

Correspondent – Business Account

1 824 (1)

Transfer ½ Allowance (1)

# **QUESTION 3**

**[25]**

TRUST CASH BOOK

|  David ½ | (1) | 50 000 | Transfer to business | 36 000 | (1)  |
| --- | --- | --- | --- | --- | --- |
|   |  |  | David | 14 000 | (1)  |
|   |  | DAVID (T) |  |  |   |
|  Transfer to business | (1) | 36 000 | Deposit | 50 000 | (1)  |
|  Bank self | (1) | 14 000 |  |  |   |

BUSINESS CASH BOOK

|  Transfer ex trust | (1) | 36 000  |
| --- | --- | --- |

DAVID (B)

|  Revenue stamps | (1) | 1800 | Transfer ex trust | 36 000 | (1)  |
| --- | --- | --- | --- | --- | --- |
|  Fees | (1) | 34 200 |  |  |   |
|   |  | 36 000 |  | 36 000 |   |

FEES

|   | David | 30 000 (1)  |
| --- | --- | --- |
|  REVENUE STAMPS  |   |   |
|   | David | 1 800 (1)  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4