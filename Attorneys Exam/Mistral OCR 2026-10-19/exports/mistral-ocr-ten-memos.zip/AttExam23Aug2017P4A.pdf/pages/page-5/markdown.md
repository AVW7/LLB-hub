# VAT OUTPUT

|   | David | 4 200 (1)  |
| --- | --- | --- |

# FEES JOURNAL

David (B) 34 200 (1)

Fees 30 000 (1)

Vat Output 4 200 (1)

Fees in respect of registration of trust and preparation of estate plan

# REVENUE/STAMP BUSINESS JOURNAL

David (B) 1 800 (1)

Revenue Stamps 1 800 (1)

Stamps issued for registration of trust

# TRANSFER JOURNAL

David (T) 36 000 (1)

David (B) 36 000 (1)

Transfer fees and disbursements

# ACCOUNTING STATEMENT

David

Re: Registration of trust and preparation of estate plan

Deposit 50 000 (1)

Revenue stamps (1) 1 800

Our fees (1) 30 000

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5