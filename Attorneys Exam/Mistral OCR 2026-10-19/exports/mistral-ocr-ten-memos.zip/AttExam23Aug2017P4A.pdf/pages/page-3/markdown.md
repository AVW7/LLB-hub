# CORRESPONDENT – BUSINESS ACCOUNT

|  ½ Allowance (1) | 1 824 | Transfer from Trust | 1 824 (1)  |
| --- | --- | --- | --- |
|  FEES  |   |   |   |
|   |  | Correspondent - ½ Allowance | 1 600 (1)  |

# VAT OUTPUT

|   | Correspondent - ½ Allowance | 224 (1)  |
| --- | --- | --- |
|  TRUST JOURNAL (1)  |   |   |
|  Black – Trust Account | 6 472 (1) |   |
|  Correspondent – Trust Account |  | 6 472 (1)  |
|  Correspondent fees and disbursements (1) |  |   |
|  Correspondent – Trust Account | 18 000 (1) |   |
|  Black – Trust Account |  | 18 000 (1)  |
|  Transfer collection ex White (1) |  |   |

# FEES JOURNAL (1)

|  Correspondent – Business Account | 1 824 (1)  |
| --- | --- |
|  Fees | 1 600 (1)  |
|  VAT Output | 224 (1)  |
|  ½ Allowance Black vs. White (1) |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3