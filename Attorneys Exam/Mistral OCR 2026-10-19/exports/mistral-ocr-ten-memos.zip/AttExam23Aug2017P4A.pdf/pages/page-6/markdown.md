Vat at 14%

(1) 4 200

Cheque herewith

(1) 14 000

50 000 50 000

# QUESTION 4

[30]

4.1

TRUST CASH BOOK

|  Reddy | 400 000 | Bank | 400 000  |
| --- | --- | --- | --- |
|  Van Der Merwe | 1 000 000 | Nedbank | 1 500 000  |
|  Ngubane | 685 000 | Seller | 500 000  |
|  Adams | 300 000 | Att Fidelity Fund | 15 000  |
|  Khoza | 500 000 | Reddy | 22 000  |
|  Nedbank | 1 515 000 | Balance | 2 385 000  |
|  Bank | 422 000 |  |   |
|   | 4 822 000 |  | 4 822 000  |

(½) S78(2)(a) NEDBANK

|  Cash | 1 500 000 | Cash | 1 515 000  |
| --- | --- | --- | --- |
|  Cash – Law Society | 15 000 |  |   |
|   | 1 515 000 |  | 1 515 000  |

# TRUST LEDGER

REDDY

|   | Cash | 400 000  |
| --- | --- | --- |

VAN DER MERWE

|   | Cash | 1 000 000  |
| --- | --- | --- |

(½) BANK S78(2)(A) (REDDY)

|  Cash | 400 000 | Cash | 422 000  |
| --- | --- | --- | --- |
|  Reddy | 22 000 |  |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6