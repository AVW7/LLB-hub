Or Format Based on Bank Statement Layout:

|  BUSINESS BANK RECONCILIATION STATEMENT AT 28 FEB 2016 |   |   | (1)  |
| --- | --- | --- | --- |
|   |  | Debit | Credit  |
|  Balance as per Cash Book | (1) |  | 40 000  |
|  Add bank error | (1) | 10 000 |   |
|  Add bank error | (1) | 12 000 |   |
|  Less Outstanding deposit | (1) |  | 10 545  |
|  Balance as per bank statement | (1) | 28 455 |   |
|   |  | 50 545 | 50 545  |

QUESTION 2 [30]

TRUST CASH BOOK

|  Correspondent (1) | 13 352 | Black | 11 528 (1)  |
| --- | --- | --- | --- |
|   |  | Transfer to business | 1 824 (1)  |
|   | 13 352 |  | 13 352  |

BUSINESS CASH BOOK

Transfer from trust (1) 1 824

CORRESPONDENT – TRUST ACCOUNT

|  Black | 18 000 | Cash | 13 352 (1)  |
| --- | --- | --- | --- |
|  Transfer to business (1) | 1 824 | Black | 6 472 (1)  |
|   | 19 820 |  | 19 820  |

BLACK – TRUST ACCOUNT

|  Correspondent (1) | 6 472 | Correspondent | 18 000 (1)  |
| --- | --- | --- | --- |
|  Cash – self (1) | 11 528 |  |   |
|   | 18 000 |  | 18 000  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2