I hereby revoke all wills previously made by me. [2]

2

I leave my entire estate to my son GEORGE AMIS, born on 28 February 2010. [1] If he is still a minor at the date of distribution of my estate. I direct my executor to reduce my entire estate to cash [1] and to pay my son's inheritance to his mother as his natural guardian [2] who shall not be required to furnish security. [1] She shall invest the funds as she in her discretion thinks fit, [1] and shall apply the interest (and, if necessary, the capital) for the reasonable maintenance of my son. [1] She shall pay the balance of his inheritance plus interest to him on his attaining the age of 18 years. [2]

3

I nominate my brother KEVIN AMIS to be the executor of this my will. [1] I grant unto him all such powers as are allowed by law, including the power of assumption, [1] and I direct that it shall not be required of him to furnish security for the due performance of his functions. [1]

J de Wet
[1]
[1]
COMMISSIONER OF OATHS
TESTATOR
X

4

The inheritance of my heir, as also the fruits derived therefrom, shall be excluded from the joint estate which may exist between my heir and any spouse of his. [1] The inheritance and fruits shall also be excluded from the accrual of any marriage of my heir which may be subject to the accrual system. [1]

Thus done and signed at Bloemfontein on 15 January 2017 by the testator and the undersigned witnesses, all being present at the same time. [1]

AS WITNESSES:

P Venter
1
[1]
TESTATOR
K Jones
2
[1]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6