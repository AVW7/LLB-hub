Net Value of the estate

127 258,00[1]

LESS Rebate in terms of Section 4A

3 500 000,00[1]

Dutiable Amount

0,00 [1]

There is no Estate Duty Payable.

# EXECUTOR'S CERTIFICATE

I, the undersigned, Tom Daniel, declare to the best of my knowledge and belief that this account is a true and proper account of the liquidation and distribution of the estate[1] and all assets[1] and income collected subsequent to the death of deceased[1] to the date of the account have been disclosed herein. [1]

DATED AT

ON THIS

DAY OF

2016

EXECUTOR[1]

QUESTION 2

[27]

LAST WILL AND TESTAMENT

I, the undersigned,

HENRY AMIS

Identity number 481208 0038 084

Married out of community of property, with exclusion of the accrual system, to JANE AMIS, [1]

Declare this document to be and contain my last will and testament.

1

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5