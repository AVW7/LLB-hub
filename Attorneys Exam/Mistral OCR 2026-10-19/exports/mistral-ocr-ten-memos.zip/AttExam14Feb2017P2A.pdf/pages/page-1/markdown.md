# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
ESTATES / BOEDELS
PART 2 / DEEL 2

14 FEBRUARY / FEBRUARIE 2017

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE
A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF
READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be
justifiable variations in practice which are brought out in the
answers. When this happens the examiner should apply his
discretion in marking the answer.

QUESTION 1

[59]

First and Final Liquidation and Distribution Account in the massed [1] estate of the
Late Joyce Daniel (Identity no. 640213 5089 08 9) [1] and surviving spouse Tom
Daniel (Identity No. 601217 5135 08 7) to whom the deceased was married in
community of property [1]

Date of death: 12 April 2016 [1]

Masters Reference No: 2130/2016PMB [1]

LIQUIDATION ACCOUNT

ASSETS

IMMOVABLE PROPERTY

Erf 271 Richards Bay, Registration Division FT

Province of Kwazulu Natal, in extent One

Thousand Two Hundred (1200), square metres

Held under Deed of Transfer No. T3742/2000[1]

At Valuation

(1)

1 500 000,00[1]

Awarded in terms of the will to the 3 children

of the deceased subject to the usufruct of the

surviving spouse [1]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1