# Certificate in terms of sections 2(1)(a)(v) of Act 7 of 1953

I, James de Wet, of 96 Charles Street, Bloemfontein, in my capacity as commissioner of oaths, certify that I have satisfied myself as to the identity of the testator [2] HENRY AMIS and that the accompanying will is the will of the testator. [2]

Signed at Bloemfontein on 15 January 2017.

"J de Wet"

# COMMISSIONER OF OATHS

JAMES DE WET

PRACTISING ATTORNEY

96 CHARLES STREET

BLOEMFONTEIN [1]

# QUESTION 3

[8]

1) B is entitled to R900 000,00 by virtue of her marriage in Community of Property [1]
2) From the remaining R900 000,00, B is entitled to R250 000,00 or a child's share whichever is the greater [1]. A child's share is R900 000,00 ÷ 4 i.e. R225 000,00, which is less than R250 000,00 [1]. Therefore B inherits a further R250 000,00 making a total of R1 150 000,00 [1]
3) P, Q and R share the balance of R650 000,00 equally  
P inherits R216 666,67 [1] (a minor cannot renounce)  
Q inherits R216 666,67 [1]  
R inherits R216 666,66 [1]
4) S inherits nothing [1]

# QUESTION 4

[6]

In the estate of B's predeceased husband the net value was R0.00 because of the section 4(q) deduction. [1]

In B's estate the net value is R9 000 000.00. From this is deducted R7 000 000.00 in terms of section 4A.(2) of the Estate Duty Act. [2] Because no amount was deducted from the net value in the predeceased spouse's estate, the deduction of R7 000 000.00 is not reduced. [1]

The dutiable amount in B's estate is thus R2 000 000.00. [1] Estate duty is payable on R 2 000 000.00 at 20% = R400 000.00. [1]

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7