3) Awarded to Raymond Daniel, major son 293 172,00[2]

in terms of and subject to the will

This award is the same as in 2 above

4) Awarded to Iris Daniel major unmarried

daughter in terms of and subject to the will 293 172,00[2]

This award is the same as in 2 above

|  879 516,00 | 879 516,00  |
| --- | --- |

# **ESTATE DUTY ADDENDUM:**

Assets as per Liquidation Account 2 231 000,00[1]

LESS Difference in Value of Shares in Bella Coola (Pty) Ltd 25 000,00[2]

LESS surviving spouse's half share 1 103 000,00[2]

Add deemed property: Sanlam Policy 950 000,00[1]

Gross value of the Estate 2 053 000,00

LESS deceased's half share of liabilities 675 742,00[2]

LESS section 4 (q) deduction for policy 950 000,00[1]

LESS section 4 (q) for usufruct 300 000.00[1]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4