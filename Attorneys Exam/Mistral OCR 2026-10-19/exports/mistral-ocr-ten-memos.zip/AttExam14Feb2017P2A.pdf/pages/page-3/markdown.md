Bond ifo Absa 1 200 000,00[1]

Master's fees 600,00[1]

Executors Remuneration

(3.5% of R2 231 000,00) 78 085,00[2]

Estate Duty NIL

Balance available for Distribution 879 516,00[1]

# RECAPITULATION STATEMENT:

Total Assets Reduced to cash 365 000,00[1]

Total Liabilities 1 351 484,00[1]

Deficit 986 484,00[1]

1 351 484,00 1 351 484,00

The deficiency will be made good by the heirs in equal shares. [1]

# DISTRIBUTION ACCOUNT:

1) Balance available for Distribution 879 516,00[1]
2) Awarded to David Daniel, major son

in terms of and subject to the will 293 172,00[2]

The award consists of

1/3 share immovable property 500 000.00 [1]

1/3 share movable property 122 000.00 [1]

622 000.00

Less 1/3 share cash deficit 328 828.00 [1]

293 172.00

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3