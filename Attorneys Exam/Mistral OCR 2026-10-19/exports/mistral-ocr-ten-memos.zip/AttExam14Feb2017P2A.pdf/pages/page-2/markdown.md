# MOVABLE PROPERTY

2009 Toyota Corolla NRB33742

At Valuation (2) 60 000,00[1]

Furniture and household effects

At Valuation (3) 210 000,00[1]

Stamp Collection: at Valuation (4) 96 000,00[1]

Items 2, 3 and 4 awarded in terms of the will to the 3 children
of the Deceased [1]

# ASSETS REDUCED TO CASH

Proceeds of 1000 shares in Bella Coola (Pty) Ltd

(5) 85 000,00[2]

Proceeds of 600 shares in Cargo Limited

(6) 45 000,00[2]

Proceeds of Absa Fixed Deposit

Account No. 2127573

(7) 60 000,00[2]

Proceeds of Old Mutual

Policy No. 627614X

(8) 175 000,00[2]

365 000.00

TOTAL ASSETS

2 231 000,00

# LIABILITIES:

Administration Expenses and other Liabilities 36 000,00[1]

SARS final Assessment 36 799,00[1]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2