# **ADMISSION EXAMINATION / TOELATING SEKSAMEN  
ATTORNEYS' PRACTICE / PROKUREURSPRAKTYK  
PART 3 / DEEL 3**

**7 MARCH / MAART 2019**

**ANSWERS / ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY  
NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE  
MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

# **QUESTION 1**

**[10]**

1. This agreement shall be of no force or effect unless, within 30 days reckoned from the effective date or any extension of such date by mutual agreement in writing:

1.1 the Seller's rights and obligations in terms of the existing lease agreement concluded between (A) as landlord and the Seller as tenant in respect of the premises are ceded and assigned from the Seller to the Purchaser with effect from the effective date with the consent of the landlord; or (5)

1.2 the existing lease agreement between the landlord and the Seller is cancelled and a new lease agreement is concluded between the Purchaser and the landlord on terms and conditions which are substantially the same or mutually acceptable to both. (5)

# **QUESTION 2**

**[20]**

2.1 Application to Reserve a Name COR 9.1 (Section 11 and 12 of the Companies Act)
Notice of Incorporation COR 14.1 (Section 13 of the Companies Act)
Memorandum of Incorporation (Section 13 of the Companies Act)
Power of Attorney (optional) (3)

2.2 State-owned company
Private company
Personal liability company / incorporated company
Public company (4)

2.3 Within 3(three) months after the date on which the company was incorporated, the board of directors of the company must ratify the pre-incorporation contract.

**LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™**

1