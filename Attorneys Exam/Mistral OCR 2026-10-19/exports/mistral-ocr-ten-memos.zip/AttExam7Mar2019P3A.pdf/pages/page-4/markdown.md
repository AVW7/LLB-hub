management of the joint estate. Any one of them may perform any juristic act with regard to the joint estate without the consent of the other subject to many exceptions – see Sections 14 and 15(1) of the Act. (4)

5.2 A number of acts can only be done by one spouse with the written consent of the other, namely:

(1) Alienation, burdening of or giving a real right in immovable property of the joint estate;
(2) Alienation, cession or pledge of shares, insurance policies, mortgage bonds, fixed deposits or any similar assets or any investment by the other spouse in a financial institution, forming part of the joint estate.
(3) Alienation or pledge of any jewellery, coins, stamps, paintings or any other asset of the joint estate held mainly as investments;
(4) Withdrawal of money held in the name of the other spouse in any bank or Post Office savings bank;
(5) As a credit receiver entering into a credit agreement as defined in the Credit Agreements Act no 75. Of 1980;
(6) As a purchaser enter into contract as defined in the Alienation of Land Act (i.e. where the purchase price is paid by instalments).
(7) Binding himself/herself as surety.

A number of other acts may only be done with the verbal consent of the other spouse, namely

(8) alienation of furniture or other effects of the common household forming part of the joint estate,
(9) receiving money due to the other spouse by way of earnings, pension etc. by virtue of the profession or business of other spouse, or
(10) damages for loss of income,
(11) donating to another person an asset of value forming part of the joint estate.

(ANY SIX OF THE ABOVE) (6)

QUESTION 6 [17]

6.1 This sale is subject to the following suspensive conditions namely:
6.1.1 The purchaser purchasing all of the properties listed below (or in the block of properties in which this property is situated) within months of the signature of this deed of sale.

If either of the said suspensive conditions is not fulfilled, this sale shall be null and void and neither party shall have any claim against the other arising from this agreement and any deposit paid shall be refunded to the purchaser.

6.1.2 The successful rezoning of all the properties purchased from residential to business within months of the conclusion of this sale. (12)

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4