If the board of directors has neither ratified nor rejected the agreement within (3) three months from date of incorporation, the company will be regarded as having ratified the agreement. (3)

# 2.4 SPECIAL POWER OF ATTORNEY

I, the undersigned, JOE SOAP IDENTITY NUMBER 600122 0019 001 MARRIED OUT OF COMMUNITY OF PROPERTY

do hereby appoint

PETER BARRISTER

IDENTITY NUMBER 750615 5035 012

MARRIED OUT OF COMMUNITY OF PROPERTY

(hereinafter called the AGENT)

with power of substitution to be my lawful agent with full power and authority for and in my name to sign a Deed of Sale and any documents as may be necessary to effect the sale of the hereinafter mentioned property, registered in my name, into the name of the Company (B) once the said company has been incorporated at a price of R1 000 000,00 (one million rand).

ERF 20104 Pofadder, also known as 13 Church Street, Pofadder.

AS HELD under Deed of Transfer T1000/2001.

1. I hereby agree to indemnify the AGENT against all costs, charges, expenses and losses which the agent may incur in the lawful execution of the powers hereby conferred upon him/her.

SIGNED AT BLOEMFONTEIN on 1st January 2016.

In the presence of the undersigned witnesses:

WITNESSES:

1.
2.

JOE SOAP

(10)

# QUESTION 3

[4]

Claim A is

60% thereof is

Claim B is

40% thereof is

A is thus awarded a nett

Contingency fee 20% (one fifth)

R150 000

R160 000

R90 000

R64 000

R26 000

R5 200

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2