6.2 By their signature of this lease _______ and _______ being directors of the lessee company hereby bind themselves jointly and severally to the lessor as sureties and co-principal debtors in solidum with the lessee for the latter's timeous performance of all of its obligations in terms of this lease. (5)

Note, the sureties can also waive the benefits of excussion and division.

# QUESTION 7 [11]

7.1 Firstly consult the relevant authorities, then consult with a senior colleague and finally ask your Regional Council. (2)
7.2 You will not be allowed to receive trust money because you will not qualify for a Fidelity Fund certificate [section 84(2) and (3)]. (2)
7.3 The fund was established to reimburse members of the public who suffer financial loss due to the theft by an attorney, his employee or candidate of money or property entrusted to that attorney. (2)
7.4 It will ensure that the wishes of the deceased are known that the administration of the estate takes place speedily and that disputes are avoided. (2)
7.5 A practitioner:
7.5.1 May not share fees with candidate attorney. (1)
7.5.2 May pay candidate attorney commission on fees generated. (1)
7.5.3 May not share fees with Counsel. (1)

- THE END -

TOTAL: [100]

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5