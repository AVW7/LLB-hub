QUESTION 13

[7]

Whereas the Plaintiff instituted action against the Defendant for payment of the sum of R240 000,00 plus interest and costs.

And whereas the parties have settled the matter.

Therefore it is agreed:

1.

The Defendant will pay to the Plaintiff the sum of R160 000,00 plus interest at the rate of 10,5% per annum calculated from the 1st of October 2016 to date of payment plus costs on the party and party scale to be taxed or agreed.

2.

The Defendant will pay the said sum in instalments of R20 000,00 per month, the first payment to be made on the 1st November 2016 and further payments monthly thereafter on the first day of every successive month.

3.

The Defendant will take collection commission of 10% on each payment subject to a maximum of R350,00 plus VAT.

4.

The Defendant will pay each amount into the trust account of the Plaintiff's attorneys, the banking details being as follows:

Account xxxxxxxxxxxxxxx

Account number xxxxxxxxxxxxxxx

Bank xxxxxxxxxxxxxxx

Branch code xxxxxxxxxxxxxxx

5.

In the event of the Defendant failing to make one payment on due date the full amount will become due and payable without further recourse to the Defendant.

6.

The parties consent to this agreement being made an order of the court.

DATED ... this ...day ... 2016.

As witnesses

1.

Plaintiff

2.

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7