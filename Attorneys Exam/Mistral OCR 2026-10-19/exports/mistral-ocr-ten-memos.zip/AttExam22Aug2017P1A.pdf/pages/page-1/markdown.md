# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
COURT PROCEDURES /HOFPROSEDURES
PART 1 / DEEL 1

22 AUGUST / 22 AUGUSTUS 2017

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

# QUESTION 1

[8]

1.1 A RAF5 form (notification of dispute) must be completed. The grounds upon which the rejection is disputed must be set out in the form and must include such submissions, medical reports and opinions as the disputant wishes to rely upon. The Registrar of the Health Professions Council of South Africa must be notified (by way of the RAF5 and annexures thereto) within 90 days of being informed of the rejection. (6)
1.2 Yes, she will be able to claim these damages if they can be proven. The Road Accident Fund Act only qualifies non-pecuniary damages. (2)

# QUESTION 2

[4]

Yes, claims can be lodged against the RAF under the circumstances for the two minor children. Section 20(1) provides that under such circumstances it shall be deemed that the vehicle was driven by the person in control of the vehicle (Mrs van der Merwe). Furthermore, Section 20(2) provides that a person who has placed or left a motor vehicle at any place shall be deemed driving that vehicle while it moves from the place as a result of gravity, or while it is stationary at that place or at a place to which it moves from the first mentioned place as a result of gravity.

# QUESTION 3

[13]

3.1 No.

(1)

The legal effect of the offer and acceptance was to create a binding contract between Mary Govender and the RAF (1). Her death does not release the RAF from its obligation to pay the agreed amount (1). The fact that summons has not been served has no bearing on their obligation to pay (1). (3)

3.2 No. Mary's Power of Attorney in your favour lapsed upon her death.

(1)

3.3 21 February 2019.

(1)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1