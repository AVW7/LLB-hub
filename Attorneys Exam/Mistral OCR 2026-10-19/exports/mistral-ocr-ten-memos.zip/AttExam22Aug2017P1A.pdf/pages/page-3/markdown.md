6.

Plaintiff orally accepted the said mandate. (½)

7.

On (date) plaintiff introduced Sam Sibiya to defendant and to the said property. (1)

8.

As a direct result of this introduction Sam Sibiya purchased the said property from the defendant at a purchase price of R10 million Rand. (A copy of the deed of sale is annexed – note: this is optional). (1)

9.

Plaintiff was the effective cause of the sale and in the premises plaintiff duly performed his obligations in terms of the mandate given to him. (1)

10.

It was an express term of the mandate that should plaintiff duly perform thereunder, he would be paid a commission equal to 5% of the purchase price plus VAT there-on. (1)

11.

In the premises, defendant is liable to pay to plaintiff commission in the sum of R500 000 plus VAT thereon at 14%, together with interest at the prescribed/legal rate per annum a tempora morae. (½)

12.

Despite lawful demand, defendant fails or neglects to pay the amount claimed. (½)

4.2 In the High Court Gauteng Division, Johannesburg \((\frac{1}{2})\) or Gauteng Division Pretoria \((\frac{1}{2})\), or In the High Court Kwa-Zulu Natal, Division Pietermaritzburg \((\frac{1}{2})\) or Kwa-Zulu Natal Division, Durban \((\frac{1}{2})\) (2)
4.3 Not less than one month in the case of the courts of the Gauteng Divisions and not less than 10 days in the case of the courts in the Kwa-Zulu Natal Divisions. (1)

# QUESTION 5

[6]

5.1 6 months (1)
5.2 Application for condonation. (1)
5.3 The facts giving rise to the debt and such particulars of such debt as are within the knowledge of creditors (1), e.g. the cause of action and the amount claimed. (2)
5.4 30 days (1)
5.5 Yes (1)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3