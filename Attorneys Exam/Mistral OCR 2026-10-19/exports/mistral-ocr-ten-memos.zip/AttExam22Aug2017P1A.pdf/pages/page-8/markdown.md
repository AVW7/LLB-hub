DATED ... this ... Day ...2016.

As witnesses

1.

Defendant

# QUESTION 14 [4]

14.1 No. (1)
14.2 The defendant may not consent to a specific area jurisdiction in a loan agreement. Such consent is null and void. (The following answer is also acceptable: Such consent is prohibited in terms of section 45 of the Magistrates' Court Act.) (1)
14.3 The Pretoria Magistrate's Court. (1)
14.4 Because the Defendant resides in Pretoria. (In terms of S28 the Court will have jurisdiction in respect of the person.) (1)

# QUESTION 15 [3]

15.1 The Plaintiff abandons the sum of R20 000,00. (2)
15.2 Judgment would be given for R390 000,00 (the reduction is applied firstly to the abandoned amount and thus an answer of R370 000,00 is incorrect). (1)

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

8