MR SPEEDY

ACCUSED

# REQUEST FOR FURTHER PARTICULARS

(1)

The Accused hereby requests the State to furnish the following Further Particulars:

1. The specific date and time when the collision occurred. (1)
2. The precise location of the collision. (1)
3. The registration letters and number of the vehicle which the accused allegedly drove. (1)
4. The grounds of negligence on which the State shall rely. (1)
5. It is alleged that the deceased was injured in the collision and that such injuries caused his death? If so, full details of such injuries are required. (1)
6. When is it alleged that X died? (1)
7. Where is it alleged that X died? (1)

DATED AT CAPE TOWN on this first day of FEBRUARY 2017.

CANDIDATE AND ASSOCIATES INC.

PER: CANDIDATE BOYES (1)

(Attorney for Applicant/accused)

227 Main Street

CAPE TOWN

TO: THE CLERK OF THE CIVIL COURT

MAGISTRATE'S COURT

CAPE TOWN

AND TO: THE SENIOR PROSECUTOR

MAGISTRATE'S COURT

CAPE TOWN

(.5)

# QUESTION 8

[7]

In terms of Section 217 the statement:

1. Must be shown to have been made freely and voluntarily.
2. The accused must have been at the time in his/her sober senses.
3. There must have been no undue influence exercised on him to induce him to make such statement.
4. The accused must have been informed of his constitutional right to remain silent.
5. The accused must have been informed of his constitutional right to require that his legal representative be present when the statement is taken
6. The statement must have been made before a Magistrate or Peace Officer.
7. The accused must have been informed that the statement will be used in evidence against him.

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5