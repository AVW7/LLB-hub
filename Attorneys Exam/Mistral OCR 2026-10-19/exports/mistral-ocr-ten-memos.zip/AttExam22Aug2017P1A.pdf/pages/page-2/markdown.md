As we have a contract (offer of acceptance) the Prescription Act applies and summons must be served within 3 (three) years of the date the debt was due (22 February 2016). (2)

3.4 The duly appointed executor or representative of Mary's estate. (1)
3.5 The RAF would be justified in refusing to pay. As Mary's claim was for general damages (non-pecuniary loss) only, and she passed away before the offer was accepted, and before the close of pleadings, the claim falls away as a result of her death. (4)

# QUESTION 4

[15½]

4.1

# PARTICULARS OF CLAIM

1.

The plaintiff is John Brown, an adult/major male estate agent, trading/carrying on business as Magic Estate Agents at 150 Newman Street, Johannesburg, Gauteng. (1)

2.

The defendant is Jenifer Jones, an adult/major female pensioner, residing at 10 Beach Road, Durban, KwaZulu-Natal. (1)

3.

The above honourable court has jurisdiction to hear the matter since the cause of action arose / the defendant resides within its area of jurisdiction. (1)

Note to examiner: the answer depends on the division of the court the plaintiff has chosen to issue summons.

4.

Plaintiff is an estate agent who, at all relevant times, was the holder of a valid fidelity fund certificate issued to him in terms of section 26(a) of Act 112 of 1976 and who had fidelity insurance in terms of section 26(b) of Act 112 of 1976. (1)

Note to examiner: candidates who do not set out details of the section number and description of the Act, should not be penalised.

5.

On (date) (½) at (Johannesburg) (½) defendant, acting personally, orally (½) gave plaintiff, acting personally, a mandate (½) to find a purchaser for defendant's fixed property, situated at 12 Rivonia Road, Johannesburg, Gauteng (½) at a selling price of at least R10 million Rand (½). (3)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2