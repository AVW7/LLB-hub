QUESTION 6

[3½]

Note to marker: any seven steps – maximum marks 3½.

1) A writ of execution against immovable property must contain the full description of the nature and situation of the property including the address to enable the sheriff to trace. (½)
2) The sheriff shall make an attachment to be served in terms of the rules on the owner, registrar of deeds and occupier of the property if the occupier is not the owner. (½)
3) The attorney to advise the sheriff in writing whether he should proceed with the sale in execution. (½)
4) The sheriff ascertains and records bonds or other encumbrances registered against the property together with the name of the relevant persons and notifies the attorney accordingly. (½)
5) If the property is subject to the claim of any preferent creditor, the property may not be sold unless the attorney for the judgment creditor notifies such preferent creditor by registered post of the intended sale and obtain a reserve price or agree on the sale without a reserve price. (½)
6) If the property is rateable the attorney of the judgment creditor must also by registered post notify the local authority. (½)
7) The sheriff appoints a day and place for the sale of the property not less than one month after service of the notice of attachment. (½)
8) The attorney, in consultation with the sheriff, shall prepare a notice of sale and conditions of sale and hands same to the sheriff not less than 20 days prior to the sale. (½)
9) The notice of sale shall be published in the Government Gazette and a local newspaper. (½)
10) Not less than 10 days prior to the date of sale, the sheriff shall forward by registered post the notice of sale to all bondholders. (½)
11) The sheriff shall, not later than 10 days prior to the sale, affix the notice of sale on the notice-board of the Magistrate's Court. (½)

QUESTION 7

[10]

IN THE MAGISTRATE'S COURT FOR THE DISTRICT OF CAPE TOWN,
HELD AT CAPE TOWN

CASE NO:235/03

In the matter between

THE STATE

And

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4