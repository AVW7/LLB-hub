QUESTION 9

[4]

1. Before the accused's first appearance in court;
2. The accused must be charged with an offence, other than 1, referred to in Part II and Part III of Schedule 2, to the Criminal Procedure Act;
3. Only a Police Official above the rank of non-commissioned officer can grant bail;
4. Consultation with the investigating officer;
5. Depositing a sum of money at the police station.

# QUESTION 10

[4]

10.1 The conduct of the Prosecutor is indeed an irregularity as nobody is entitled to discuss evidence with a witness once he/she is under oath. At that point the witness belongs to the Court (2)
10.2 In the event of the witness confirming the discussion it could very well affect his credibility as a witness and the value that the court will attach to his evidence. It could in due course found a ground for appeal/review (2)

# QUESTION 11

[6]

11.1

# LETTER OF DEMAND

[Letter should be addressed to Mr X]

We act on behalf and on instructions of Ms Y.

It is our instruction that you are indebted to our client in the amount of R100 000,00.

for goods sold and delivered to you at your special interest and request.

In terms of the Magistrate's Court Act and rules, you are liable for the costs of this letter of demand amounting to ...

Accordingly, our client demands that you pay the capital and costs within 14 days (candidate may insert reasonable period) of this letter of demand, failing we will issue summons. (4)

11.2 The letter should at least contain a notice or paragraph proposing that the debtor refers the matter to an alternate dispute resolution agent, an ombud with jurisdiction or a debt counsellor... (2)

# QUESTION 12

[5]

12.1 No. (1)
12.2 R1 000,00. (1)
12.3 Yes. (1)
12.4 Copies of the record and Power of Attorney. (2)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6