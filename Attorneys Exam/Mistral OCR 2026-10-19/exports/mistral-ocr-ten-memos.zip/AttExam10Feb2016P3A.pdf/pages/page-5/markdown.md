6.6 Party and party costs are costs according to tariff which a successful litigant may recover from the losing party if the court makes a costs award in favour of the winner. If the costs cannot be recovered from the losing party, the successful party's attorney may recover only the party and party costs from his own client unless there is an agreement that he may charge more. If an attorney fails to discuss fees with the client he may not charge him more than the party and party fees. (3)

# QUESTION 7

[11]

7.1 Firstly consult the relevant authorities, then consult with a senior colleague and finally ask your Law Society. (2)
7.2 You will not be allowed to practise or to charge fees. (2)
7.3 The fund was established to reimburse members of the public who suffer financial loss due to the theft by an attorney, his employee or candidate of money or property entrusted to that attorney. (2)
7.4 It will ensure that the wishes of the deceased are known that the administration of the estate takes place speedily and that disputes are avoided. (2)
7.5 A practitioner:
7.5.1 May not share fees with CA. (1)
7.5.2 May pay C.A commission on fees generated. (1)
7.5.3 May not share fees with counsel. (1)

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 5