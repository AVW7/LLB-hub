(a) Marriages are ipso iure in community of property if no ante nuptial contract is concluded before date of marriage. There is only one joint estate. Either spouse can in principle act o.b.o the joint estate but there are many exceptions i.t.o the Marital Property Control Act. (3)
(b) To achieve a marriage out of community of property, the parties must enter into an ante nuptial contract before a notary public. The marriage will be subject to accrual unless it is excluded. While in either case the parties retain their separate estates throughout the marriage the accrual means that at the end of the marriage the growth/accrual in the two estates is shared equally. You would recommend out of c.o.p without accrual. (6)
4.2 If the parties marry in community of property the whole joint estate will normally be subjected to any sequestration. If out of community of property the sequestration of A would vest the assets of B in the Master and later A's trustee. The solvent spouse will have to apply, usually on affidavit, to have her assets released by providing evidence of ownership. The Insolvency Act refers to assets which the solvent spouse acquired: before the marriage, under a marriage settlement, by title valid against creditors or with the proceeds of the above. The trustee cannot retain assets because he has a claim under some other provision. Mrs B must therefore keep sound records of her assets and transactions. (10)
4.3 The trust will be registered with the Master of the High Court in the area where Mrs B resides. She must lodge:

(a) Two copies of the deed of trust;
(b) Letter from an auditor to act;
(c) Acceptance of trust by the trustees.

She must further provide:

(a) The name of the bank where the trust will operate its account;
(b) The name and address of the person who will keep and maintain the records of the trust;
(c) Occupation of trustees.
(d) Whether or not the trustees have any previous experience as trustees

The Master also has a number of further requirements should he be requested to waive his right to insist on security by the trustees. (8)

# QUESTION 5

[10]

5.1 Both spouses have equal powers with regard to the disposal of assets of the joint estate, the contracting of debts which lie against the joint estate and the management of the joint estate. Any one of them may perform any juristic act with regard to the joint estate without the consent of the other subject to many exceptions - see Sections 14 and 15 (1) of the Act. (4)
5.2 A number of acts can only be done by one spouse with the written consent of the other, namely:

(1) Alienation, burdening of or giving a real right in immovable property of the joint estate;

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 3