(2) Alienation, cession or pledge of shares, insurance policies, mortgage bonds, fixed deposits or any similar assets or any investment by the other spouse in a financial institution, forming part of the joint estate.
(3) Alienation or pledge of any jewellery, coins, stamps, paintings or any other asset of the joint estate held mainly as investments;
(4) Withdrawal of money held in the name of the other spouse in any bank or Post Office savings bank;
(5) As a credit receiver entering into a credit agreement as defined in the Credit Agreements Act no 75 of 1980;
(6) As a purchaser enter into contract as defined in the Alienation of Land Act (i.e. where the purchase price is paid by instalments);
(7) Binding himself/herself as surety

(Any four of the above)

A number of other acts may only be done with the consent (also verbally) of the other spouse, namely alienation of furniture or other effects of the common household forming part of the joint estate; receiving money due to the other spouse by way of earnings, pension etc. by virtue of the profession or business of other spouse, or damages for loss of income, or inheritance, etc. donating to another person an asset of value forming part of the joint estate.

(Any two of the above)

(6)

# QUESTION 6

[17]

6.1 Pro Amico is free representation by an attorney of a client who is in a particular relationship to the attorney (typically a relative or colleague). No fees may be charged but disbursements may be recovered. (2)
6.2 Acting pro bono means representing indigent persons but also some services to poor communities without charging fees. (2)
6.3 Contingency fees constitute a percentage (up to \(25\%\)) of a client's successful claim if the claim sounds in money or are fees that are chargeable at a rate higher than normal (not more than double) if the work is successfully concluded. This type of fee was legalised by legislation if certain formalities are complied with. The so-called common law contingency agreement has been found invalid. (5)
6.4 Costs de Bonis Propriis. These are costs which a Court may order the attorney (or other person in fiduciary relationship to the litigant) to pay personally, either on a party and party or attorney and client basis as a mark of displeasure with the conduct of the attorney or other person (trustee, executor, etc.). (3)
6.5 This is an interim order made by a court relating to costs incurred in a matter that is not finalised and means that these costs will follow the final costs order in the matter. (2)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 4