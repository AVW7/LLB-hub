# 2.4 SPECIAL POWER OF ATTORNEY

I, the undersigned, JOE SOAP IDENTITY NUMBER 600122 0019 001 MARRIED OUT OF COMMUNITY OF PROPERTY

do hereby appoint

PETER BARRISTER

IDENTITY NUMBER 750615 5035 012

MARRIED OUT OF COMMUNITY OF PROPERTY

(herein called the AGENT)

with power of substitution to be my lawful agent with full power and authority for and in my name to sign a Deed of Sale and any documents as may be necessary to effect the sale of the hereinafter mentioned property, registered in my name, into the name of the Company (B) once the said company has been incorporated at a price of R1 000 000,00 (one million rand).

ERF 20104 Pofadder, also known as 13 Church Street, Pofadder

AS HELD under Deed of Transfer T1000/2001.

1. I hereby agree to indemnify the AGENT against all costs, charges, expenses and losses which the agent may incur in the lawful execution of the powers hereby conferred upon him/her.

Signed at Bloemfontein ON 1ST January 2016

In the presence of the undersigned witnesses:

WITNESSES

1.
2.

JOE SOAP

(10)

# QUESTION 3

[4]

|  Claim A is | R150 000 |   |
| --- | --- | --- |
|  60% thereof is |  | R90 000  |
|  Claim B is | R160 000 |   |
|  40% thereof is |  | R64 000  |
|  A is thus awarded a nett |  | R26 000  |
|  Contingency fee 20% (one fifth) |  | R5 200  |

# QUESTION 4

[28]

4.1 In principle the main division of marital regimes is between those in and those out of community of property. (1)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 2