continuing to exist on a solvent basis; or, if it is not possible for the business to continue in existence, to implement a plan whereby better results are achieved for the company's creditors or shareholders than would result from liquidation.

The purpose of business rescue is to facilitate the rehabilitation of a financially distressed company. In terms of section 128(1)(f), a company is regarded as financially distressed if it appears reasonably unlikely that the company will be able to pay all of its debts as they fall due and payable within the immediately ensuing six months or if it appears to be reasonably likely that the company will become insolvent within the immediately ensuing six months. (8)

5.2 Business rescue proceedings are initiated in one of two ways – can be commenced either:
• Voluntarily, by way of a resolution of the board of directors of the company's board; or
• By applying for a court order to place the company under supervision and commence business rescue proceedings. (2)

5.3 Affected persons are shareholders, creditors; a registered trade union representing the company's employees, as well as any employees not represented by a registered trade union or the representatives of such employees.

An affected person may object to a business rescue resolution, or the appointment of a business rescue practitioner, at any time after the resolution, but before the adoption of a business rescue plan, on any of the grounds set out in section 130(1) of the Companies Act. (4)

5.4 There is no reasonable basis for believing the company is financial distressed;
There is no prospect of rescuing the company;
The company has failed to satisfy the procedural requirements set out in S 29 (3)

5.5 The commencement of Business Rescue (after valid board resolution or Court order) places a moratorium on most legal proceedings against the company. During business rescue proceedings, no legal proceedings, including enforcement action, against the company or in relation to any property belonging to the company or lawfully in its possession, may be commenced or proceeded with in any forum, except:
- With written consent of the practitioner;
- With the leave of the court and in accordance with any terms the court considers suitable;
- As a set-off against any claim made by the company in any legal proceedings, irrespective whether those proceedings commenced before or after the business rescue proceedings began;
- Criminal proceedings against the company or any of its directors or officers; or
- Proceedings concerning any property or right over which the company exercises the powers of a trustee. (5)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

3