# **QUESTION 7**

**[20]**

7.1 You may act unless some conflict is apparent. It is wiser to appoint an independent attorney. (3)
7.2 You may, but not desirable. (2)
7.3 You may act unless negotiations become tricky, bargaining power is clearly unequal or if assets are vastly different. (2)
7.4 You may, but professional courtesy requires you to personally inform the colleague beforehand. (3)
7.5 You should not start before speaking to the colleague regarding release of the file, payment of his/her costs, unless delay would cause irreparable harm. (2)
7.6 Yes
Yes
Usually not.
In the first two cases it would normally be in the interests of the client;
In the third it may well be detrimental. (3)
7.7 Yes;
There should not be a dispute about assets, custody does not arise. If unforeseen conflict does arise, you would withdraw from both parties. In principle you may act. (5)

# **QUESTION 8**

**[5]**

In terms of Rule 33(3) you may not.

Unless the court for good cause shown order otherwise, costs of interim orders shall not be taxed until the conclusion of the matter;

A party may present only one bill up to and including the judgment or other conclusion of action.

# **QUESTION 9**

**[4]**

**Note to examiners:** candidates were informed of error under fees column – the amount on the exam paper reflected R10 0000.00 – the correct amount is R10 000.00 as per below.

|   | FEES | DISBURSEMENTS  |
| --- | --- | --- |
|   | R 10 000.00 | R 4 500.00  |
|  Less taxed off | R 4 500.00 | R 2 000.00  |
|  Sub-total | R 5 500.00 | R 1 500.00  |
|  TOTAL | R 7 000.00 | (1)  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

5