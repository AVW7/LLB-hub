QUESTION 6

[15]

# *Domicilium Citandi et Executandi* / Notices

6.1 The parties choose as their *domicil citandi et executandi* for all purposes under this agreement, whether in respect of court process (1), notices or other documents or communications of whatsoever nature (including the exercise of any option (1), the following addresses:

# 6.1.1. Physical

Postal

Fax

E-mail

# 6.1.2 Physical

Postal

Fax

E-mail

(1)

6.2 A notice or communication given in terms of this agreement shall be valid and effective only if in writing. (1)

6.3 Any / either party may by notice to the other party change the physical address chosen as its *domicillia citandi et executandi vis-à-vis* that party to another physical address where postal delivery occurs in or or its postal address or fax number or e-mail address, provided that the change shall become effective *vis-à-vis* that addressee on the 1$^{st}$ (first) business day after the deemed receipt of the notice by the addressee. (1)

6.4 Any notice to a party:

6.4.1 sent by prepaid registered post (by airmail if appropriate) in a correctly addressed envelope to the party at an address chosen as its *domicillia citandi et executandi* to which post is delivered shall be deemed to have been received on the ... business day after posting (unless contrary is proved. (2)

6.4.2 delivered by hand to a responsible person during ordinary business hours at the physical address chosen as the party's *domicillia citandi et executandi* shall be deemed to have been received on the day of delivery. (2)

6.4.3 sent by fax to the party's chosen fax number, shall be deemed to have been received on the date of dispatch (unless the contrary is proved); (2)

6.4.4 sent by e-mail to the party's chosen e-mail address, shall be deemed to have been received on the date of dispatch (unless the contrary is proved). (2)

6.5 Notwithstanding anything to the contrary herein contained a written notice or communication actually received by a party shall be adequate written notice or communication to it notwithstanding that it was not sent to or delivered at its chosen *domicillium citandi et executandi*. (2)

LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

4