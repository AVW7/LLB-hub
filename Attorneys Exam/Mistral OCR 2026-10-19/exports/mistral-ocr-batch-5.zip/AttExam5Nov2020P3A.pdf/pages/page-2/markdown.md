## **QUESTION 4**

**[18]**

4.1 The seller warrants and represents that:

4.1.1 he is the beneficial owner of the shares which are fully paid; (1)

4.1.2 the Seller is able to deliver to the Purchaser good title in and to the shares;(1)

4.1.3 neither the members of the company nor its directors have passed, or agreed to pass, any resolution for the increase of the capital of the company, or for the issue of any other shares in the company, and that no such resolution will be passed prior to the transfer of the shares; (2)

4.1.4 any rights of pre-emption in respect of the said shares or any portion thereof, whether granted by the articles of association of the company or otherwise, will be waived; (1)

4.1.5 the books and records of the company accurately reflect, in accordance with accepted accounting principles, its financial affairs and all the transactions to which it has been a party; (2)

4.1.6 the Company is not engaged in any income tax appeals, arbitration or criminal proceedings, labour disputes, competition or consumer commission enquiries or any other tribunal enquiries or litigation other than proceedings for the collection of debts from debtors in the ordinary course of business; (2)

4.1.7 the Seller is not aware of any matter in respect of the shares or the Company or the Property which would have any bearing on the acquisition by a Purchaser of the Shares/Equity. (1)

4.2 Delivery of documents of title.

The Seller shall on the Effective Date/signature date deliver to the Purchaser the following documents; the share certificates (1) in respect of the Subject Shares accompanied by share transfers forms (1) currently dated and executed in blank by the registered holder thereof, so as to enable such shares to be registered in the name of the Purchaser or its nominees (1); a written cession (1) ceding the claims to the Purchaser or its nominee; a resolution duly passed by the board of directors of the Company approving the transaction set out in this agreement; (2) and

The written resignations of those of the directors, public officers, secretaries and other officers of the Company (1) whose resignations have been required by the Purchaser, and the resignation of the Company's auditors, if so required by the Purchaser (1). (8)

## **QUESTION 5**

**[22]**

5.1 The objective of business rescue is to develop and implement a plan to rescue the company by restructuring its affairs, business, property, debt and other liabilities and equity in a manner that maximises the likelihood of the company

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

2