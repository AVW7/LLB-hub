Thus taxed and allowed (1/2) in the amount of R7 000.00 (seven thousand rand). (1/2)

Signed at _______________ this day of _______________ 2020

Taxing Master

In terms of the Magistrates Court Rule 33 (17)(a) (1/2) where more than one-fourth of the bill (1/2) (excluding expenses) is taxed off (1/2), the party presenting the bill shall not be allowed any costs of taxation. (1/2)

TOTAL: [100]

![img-0.jpeg](img-0.jpeg)

LAW SOCIETY
OF SOUTH AFRICA

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

6