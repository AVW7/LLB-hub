# ADMISSION EXAMINATION
ATTORNEYS' PRACTICE
PART 3

5 NOVEMBER 2020

MEMORANDUM

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER: This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

# QUESTION 1 [8]

1.1 The Act defines operational requirements as based on:

- Economic
- Technological
- Structural, or
- Similar; needs of the employer (4)

1.2 The employer should seek to minimize termination of employment by e.g.:

- Stop hiring new employees
- Eliminate overtime
- Voluntary retrenchment
- Early retirement
- Reduction in working hours (4)

# QUESTION 2 [4]

The purpose must be to conduct business (1), in order to earn profits (1); each partner must contribute to the partnership (1) and share in the profits (1).

# QUESTION 3 [4]

The following may not be concluded electronically:

- Agreement for the sale of immovable property;
- Leases of land exceeding 20 years;
- Wills;
- Bills of exchange.

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

1