QUESTION 4

[10]

# CODICIL (1)

I, the undersigned,

GIBSON REDDY,

of Durban, make the following codicil to my last will and testament dated 5 October 2017.(1)

1.

I revoke paragraph 4 of my said Will and substitute for it the following: (2)

I bequeath R700 000. 00 (seven hundred thousand rand) in cash to my sister Joyce.(1)

2.

My said Will remains unaltered in all other respects. (2)

Thus done and signed at Durban on 31 August 2018 by the testator and the undersigned witnesses, all being present at the same time. (1)

AS WITNESSES: (1)

1.
2.

TESTATOR (1)

QUESTION 5

[9]

1) The document does not comply with Section 2(1) (a) (ii) of the Wills Act [1] in that the second page must be signed by two witnesses in the presence of the testator and present at the same time (1).
2) Where a Will does not comply with the formal requirements of the Wills Act any person who has an interest may in terms of Section 2(3) of the Wills Act apply to the High Court for an order directing the Master to accept the document signed by the deceased, as his Will (1) if the Court is satisfied that the document was intended to be his Will. (1) I would advise the family to make such an application to the High Court (1).
3) In terms of Section 4A (1) of the Wills Act, a person who writes out the Will shall be disqualified from receiving any benefit from the Will (2).
4) The appointment of the surviving spouse as Executor is regarded as a benefit (1).

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6