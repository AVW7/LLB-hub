# **DIVESTMENT NOTE:-**

Asset items 1,2 & 3 are awarded to the

Intestate heirs in terms of Act No. 81 of 1987 as will more fully appear in the distribution account (2)

# **LIABILITIES :-**

Administration Expenses;

Masters Fees (maximum) 9 7 000,00 (2)

Executor's fees @ 3.5% of R5 934 000,00) 10 207 690,00 (2)

Other administration expenses 11 204 010,00 (1)

Claim's against the Estate :

SARS final assessment 12 72 000,00 (1)

Standard Bank Credit Card Account No. 400127163 13 16 700,00 (1)

Absa Mortgage Bond 14 825 000,00 (1)

Total liabilities 1 332 400,00

Estate Duty NIL

Balance available for Distribution 4 601 600,00(1)

5 934 000,00

# **RECAPITULATION STATEMENT:-**

Cash and assets reduced to cash

(Items 4,5,6,7 and 8 of the Liquidation Account) 1 594 000,00(2)

Liabilities 1 332 400,00 (1)

Surplus 261 600,00 (1)

1 594 000,00 1 594 000,00

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2