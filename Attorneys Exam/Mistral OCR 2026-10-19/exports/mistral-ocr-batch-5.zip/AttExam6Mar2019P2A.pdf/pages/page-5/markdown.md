# **EXECUTOR'S CERTIFICATE**

I, the undersigned hereby certify that to the best of my knowledge and belief this account is a true and proper account of the liquidation and distribution of the estate (1) and that all assets and income collected subsequent to the death of the deceased to the date of this account (1) have been disclosed herein (1)

DATED AT RANDBURG ON

DAY OF

2018

EXECUTOR

# **QUESTION 2**

[11]

2.1 In view thereof that Jason died within 3 months after he was divorced (1), Section 2(B) of the Wills Act will be applicable (1). Sarah is considered to have died before Jason (1) and Sarah will therefore not benefit in terms of the Will (1). As Jason has died without leaving issue, his new wife Emily will be the sole beneficiary in terms of the Intestate Succession Act 81 of 1987, as amended (1).
2.1 Yes (1). Because the Will was not altered after the divorce (1), and because more than 3 months has lapsed since divorce (1), Sarah regains her status as a beneficiary (1). Sarah will therefore inherit in terms of Jason's Will (1). His new wife will only have a claim against the estate for maintenance (1) in terms of the Maintenance of Surviving Spouses Act No. 27 of 1990, as amended.

# **QUESTION 3**

[10]

The Will is invalid because it was not witnessed. His estate therefore devolves in accordance with the law of intestate succession. (2)

His estate devolves as follows:

i. His ex wife, Nel - nil; (1)
ii. His brother, Kurt - R 250 000.00; (1)
iii. Kurt's wife Mona - nil; (1)
iv. His sister Eileen's estate - R 250 000.00; (1)
v. Eileen's daughter Clarice - nil; (1)
vi. His sister, Tanya - R 250 000.00; (1)
vii. His companion, Prudence, with whom he spends every day - nil because she is not married according to the Marriage Act or Civil Unions Act. (2)

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5