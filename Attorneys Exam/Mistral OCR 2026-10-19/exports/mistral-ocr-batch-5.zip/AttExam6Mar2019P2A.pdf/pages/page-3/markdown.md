# **DISTRIBUTION ACCOUNT:-**

Balance available for distribution

4 601 600,00 (1)

1. Awarded to Leah Zama, surviving spouse, unmarried

1.1 one half of the estate by virtue of her
marriage in Community of Property 2 300 800,00 (1)

1.2 in terms of Section 1(1)(c)(i) of the

Intestate Succession Act No. 81 of
1987

575 200,00 (1) 2 876 000,00

NOTE: The surviving spouse receives ½ (50%) plus ⅛ (12.5%) of the net estate. Each
child inherits ⅛ (12.5%) of the net estate.

The above award consists of:-

Immovable property : R 2 375 000,00 (1)

Movables : R 337 500,00 (1)

Cash : R 163 500,00 (1)

2. Awarded to Ray Zama, major son in terms of

Section 1(1) (c)(ii) of the Intestate Succession
Act No. 81 of 1987

575 200,00 (1)

The above award consists of:-

Immovable property: R 475 000,00 (1)

Movables : R 67 500,00 (1)

Cash : R 32 700,00 (1)

3. Awarded to Rita Zama, minor daughter
born on 17 December 2002,

Identity No. 021217 5135 08 7,(1)

in terms of Section 1 (c) (ii) of the Intestate

Succession Act No. 81 of 1987

575 200,00 (1)

The above award consists of:-

Immovable property : R 475 000,00 (½)

Movables : R 67 500,00 (½)

Cash : R 32 700,00 (½)

4. Awarded to Roy Zama, major son

in terms of Section 1 (c) (ii) of the Intestate

Succession Act No. 81 of 1987

575 200,00 (1)

The above award consists of:-

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3