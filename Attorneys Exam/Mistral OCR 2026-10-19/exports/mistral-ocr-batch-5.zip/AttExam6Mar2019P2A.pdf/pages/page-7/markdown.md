5) However the Court may in terms of Section 4A.(2)(a) declare the spouse who hand wrote the Will competent to benefit from the Will (1), if the Court is satisfied that the spouse did not defraud or unduly influence the deceased in the execution of the Will (1).

- THE END -

TOTAL: [100]

![img-0.jpeg](img-0.jpeg)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7