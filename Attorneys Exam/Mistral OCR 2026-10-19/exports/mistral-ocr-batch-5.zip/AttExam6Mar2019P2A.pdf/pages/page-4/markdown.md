Immovable property: R 475 000,00 (½)

Movables : R 67 500,00 (½)

Cash : R 32 700,00 (½)

4 601 600,00

# INCOME AND EXPENDITURE ACCOUNT :-

|  Interest on fixed deposit with Absa Bank | 1 |  | 12 000,00 (1)  |
| --- | --- | --- | --- |
|  Executors fees 6% | 2 | 720,00 (1) |   |
|  Standard Bank Credit Card : Interest | 3 | 1 170,00 (1) |   |

Balance available for distribution to the intestate heirs in the same proportions as in the distribution account

10 110,00 (1)

12 000,00 12 000,00

# ESTATE DUTY ADDENDUM:-

Assets of the Deceased as per the Liquidation Account 5 934 000,00 (1)
LESS adjustment in valuation of shares 5 000,00 (1)
In Bold Investments (Pty) Ltd

LESS proceeds of Liberty Life Policy 5 929 000,00
800 000,00 (1)

LESS surviving spouse's half share 5 129 000,00
2 564 500,00 (1)

2 564 500,00

ADD Deemed Property
Liberty Life Policy R800 000,00 (1)
Sanlam Policy R1 500 000,00(1) 2 300 000,00
Gross Value of Estate 4 864 500,00 (1)

LESS liabilities ½ share R666 200,00 (1)

LESS Section 4(q):
Inheritance R575 200,0 (1)
Sanlam Policy R1 500 000,00(1) 2 741 400,00
Net Value of Estate 2 123 100,00 (1)
LESS Section 4A Rebate 3 500 000,00 (1)
NIL

Therefore no Estate Duty payable(1)

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4