guilty or for having incorrectly admitted any facts resulting in his conviction or convince the court that he has a valid defence to the charge.

The accused may have to give evidence under oath and explain the reasons for pleading guilty and failing to put forward his defense or admitting certain facts. The prosecutor and magistrate may cross-examine the accused and if the magistrate is satisfied that the accused's explanation is acceptable a plea of not guilty will be recorded.

# QUESTION 9

[5]

A fresh bail application can be brought on behalf of client. This will invariably be brought before the Magistrate who refused bail in the first instant. You will aver that new facts have emerged since the last application. You will specifically present evidence to the Court on the fact that the State's case has been considerably weakened or there is no longer a possibility of a conviction due to the unavailability of the two state witnesses.

# QUESTION 10

[12]

10.1

IN THE REGIONAL COURT FOR THE DISTRICT OF PORT ELIZABETH
HELD AT PORT ELIZABETH

CASE NO:

In the matter between:

MR

APPELLANT

and

THE STATE

# NOTICE OF APPEAL

BE PLEASED TO TAKE NOTICE THAT the Appellant notes an Appeal to the Eastern Cape Division of the High Court of South Africa against the sentence imposed upon him by the Regional Magistrate on the 3rd July 2018.

The grounds of Appeal are as follows:

1. The sentence imposed upon the appellant induces a sense of shock.
2. The learned Magistrate failed to take into consideration the personal circumstances of the Appellant and in particular that he is a first offender, is married and supports a wife

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4