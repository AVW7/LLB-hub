Dated at Pretoria this __________ day of __________ 2018.

Plaintiff Attorneys
Van Rooyen & Company
12 Schoeman Street
Pretoria

# **QUESTION 13** [5]

- File Notice of intention to call an expert witness.
- File a notice providing a summary of the experts evidence which should contain the following:
  (a) Evidence as to the expertise of the appraiser
  (b) The fact that the appraiser has inspected the assets of the estate
  (c) The expert opinion of the appraiser as to the total value of the assets
  (d) How such total was calculated

# **QUESTION 14** [5]

14.1 Mr Y, as the owner has locus standi. (1)
14.2 Mr Z, due to his negligence and ABS Company is vicariously liable as Mr Z was acting in the course and scope of his employment. (3)
14.3 Mr Y will remain the Plaintiff. (1)

# **QUESTION 15** [5]

15.1 No defence; prescription on a dishonoured cheque is six years. (1)
15.2 He has a valid defence as the Magistrate's court has no jurisdiction to adjudicate the unfair labour practice (section 157 of the Labour Relations Act). (1)
15.3 He has a valid defence of res judicata in that there was a prior judgement in an action between the parties where the same point was in issue. [Reference to the Once and for All Rule is also correct.] (2)
15.4 He has a valid defence in that he has no liability under a contract (which is probably voidable anyway) entered into by his son, with or without his assistance as his guardian. (1)

- THE END -

TOTAL: [100]

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7