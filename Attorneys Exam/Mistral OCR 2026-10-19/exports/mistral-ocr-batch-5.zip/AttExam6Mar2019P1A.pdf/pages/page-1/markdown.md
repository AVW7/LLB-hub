# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
COURT PROCEDURES / HOFPROSEDURES
PART 1 / DEEL 1

6 MARCH / MAART 2019

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

# QUESTION 1

[8]

1.1 Section 24(2)(b) provides that where a person is killed outright in a motor vehicle accident, the completion of the medical report shall not be a requirement. (1) In such a case, the claim form shall be accompanied by documentary proof such as a copy of the relevant post-mortem report / inquest record (1) or a copy of the case docket (1) in the case of a prosecution of the person, copy of the death certificate [any 3 of the above]. (3)
1.2 Marriage certificate of Mr. and Mrs. Khumalo. (1) Unabridged birth certificates of the three (3) children. (1) (2)
1.3 Any 3 of the following: Mr Khumalo's tax returns. Bank Statements Income and expenditure statements Invoice and Receipt books. (3)

# QUESTION 2

[5]

If the claimant intends disputing the rejection of the serious injury assessment report then the claimant must within 90 days (1) of being informed of such rejection of the assessment notify the Registrar of the Health Professions Council of South Africa (1) that the rejection is disputed by lodging a dispute resolution form, a RAF 5 (1). The Road Accident Fund will bear the reasonable costs of the dispute resolution, (1) however the claimant will have to bear his or her own cost when represented by an attorney and/or advocate. (1)

# QUESTION 3

[6]

As the merits of my client's claim has been adjudicated (1) I would apply for an interim payment (1) in terms of Rule 34A of the Uniform Rules of Court (1) in respect of the following heads of damages:

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1