3.1 Past hospital and medical expenses; (1/2)
3.2 Past loss of income. (1/2)

You cannot claim for future hospital and medical expenses or future loss of income and general damages as these have not been incurred. (2)

# QUESTION 4 [6]

4.1 Minor. Suspended until the attainment of age 18. (2)
4.2 Persons detained as patients in terms of the Mental Health Care Act. Suspended for the duration of their detention as patients. (2)
4.3 Persons under curatorship. Suspended for the duration of curatorship. (2)

# QUESTION 5 [10]

# 5.1

5.1.1 A curator ad litem is usually appointed to assist a person who is of unsound mind (1/2) or is a minor (1/2) to be assisted in legal proceedings.
5.1.2 A curator bonis is appointed for a person in respect of whom the court has made an order that the person is of unsound mind and as such incapable of managing his/her affairs. (2)

NOTE TO EXAMINER: Any eight essential averments must be listed with one mark each.

5.2 The grounds upon which the applicant claims locus standi. (½)

The grounds upon which the Court is alleged to have jurisdiction. (1)

The patients age and sex. (½)

Full particulars of his means (1)

Information as to his general state of physical health (1)

The relationship (if any) between the patient and the applicant (1)

The facts and circumstances relied on to show that the patient is of unsound mind and incapable of managing his affairs (1)

The name, occupation and address of the respective persons suggested for appointment by the Court as curator at litem and subsequently as curator bonis. (1)

An affidavit by at least one person to whom the patient is well known and containing such facts as are within deponent's own knowledge concerning the patient's mental condition. (1)

Affidavits by at least two medical practitioners, one of whom shall be an alienist who have conducted recent examinations of the patient. (1)

# QUESTION 6 [6]

6.1 An Ex Parte application is an application that does not directly affect the rights of others (½). Usually the short form is used. (½). (1)

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2