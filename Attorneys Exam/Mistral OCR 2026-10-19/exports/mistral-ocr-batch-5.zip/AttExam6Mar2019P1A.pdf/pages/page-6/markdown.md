QUESTION 12

[10]

1. The Plaintiff is Jabu Ndlovu, an adult female, teacher who lives at 24 Centurion Lane, Pretoria.
2. The Defendant is Clean Pools CC, a Close Corporation incorporated in terms of the Close Corporation Act and whose principal place of business is situated at 16 Marais Road, Pretoria.
3. On or about the \(12^{\text{th}}\) May 2018 at Pretoria the Plaintiff and the Defendant entered into a written agreement for the construction of a swimming pool at the Plaintiff's home. The material terms of which were: -
a) The Defendant would construct a swimming pool for the plaintiff at her place of residence.
b) The contract price was R80 000 to be paid as follows: -

i. R40 000.00 on signature
ii. R20 000.00 on commencement of the contract
iii. R20 000.00 on completion

A copy of the contract is annex hereto marked A.

4. The Plaintiff paid to the Defendant R40 000.00 on signature and R20 000.00 on commencement.
5. The Defendant absconded without completing the contract.
6. As a result, the Plaintiff cancelled the contract and a copy of the notice of cancellation is annexed hereto marked B.
7. The Plaintiff employed the services of Sparkling Pools to complete the contract at a contract price of R45 000.00 which amount is fair and reasonable. A copy of the contract is annexed hereto marked C.
8. As a result, the Plaintiff has suffered damages in the sum of R25 000.00, being R45 000.00 less the R20 000.00 unpaid in terms of the contract with the Defendant.
9. Despite written demand the Defendant has failed to pay the said amount. A copy of the demand is annexed hereto marked D.

Wherefore the Plaintiff prays for judgment against the Defendant for: -

1. Payment of the sum R25 000.00
2. Interest thereon at a rate of \(10\%\) per annum from the date of the expiry of the letter of demand to date of payment. [The interest rate might change by the time the exam is written].
3. Costs of suit.

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6