6.2

- Where an order is sought that does not affect another person and the applicant is the only interested party to the proceedings. (1)
- Where notice of the application to the other party will frustrate the requested relief. (1)
- Where a nulla bona return is relied upon in the case of an application for sequestration and no notice of the application is given to the respondent. (1)
- Where preliminary relief is essential and there is no time to give notice and where the Respondent will be given notice once the urgent relief is granted before any final relief is granted. (1)
- In certain very specific circumstances where it is not possible to give notice to the other side and /or for a preliminary step in proceedings, for example leave to sue by way of edictal citation. (1)

# QUESTION 7

[9]

Plaintiff's Declaration.

1. The Plaintiff is , an adult male Accountant residing at (1)
2. The Defendant is , an adult businessman, residing at Bloemfontein. (1)
3. On the day of 20 and in Bloemfontein Plaintiff and Defendant, (½ mark) both acting personally, (½) concluded a verbal agreement (½) of sale in terms whereof:

1.1 Plaintiff would sell his Toyota Fortuner 4x4 (hereinafter for the sake of convenience referred to as "the vehicle") to Defendant at a purchase price of R500 000.00. (2)
1.2 The purchase price was payable by Defendant to Plaintiff against delivery of the vehicle (1) in cash and free of exchange or bank charges at Bloemfontein by electronic transfer \((\frac{1}{2})\) to Plaintiff's designated bank account number 1234567 at United Bank of Africa.
1.3 The vehicle was sold as is ("voetstoots") without any warranty whatsoever. (½)
2. Plaintiff duly delivered the said vehicle to Defendant. (½)
3. Defendant has to date failed to pay the purchase price of R500 000.00 or any part thereof and persists in such failure notwithstanding due and proper demand by Plaintiff, which amount is now due and payable. (1)

# QUESTION 8

[5]

In terms of Section 113 an accused who has pleaded guilty and who has been found guilty can bring an application before sentence is imposed to have the plea of guilty corrected to one of not guilty. The accused will have to put forward good reasons for having pleaded

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3