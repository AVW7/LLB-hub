and four minor children, is the sole breadwinner of the family and is a solid citizen performing social work.

3. The Magistrate erred in not taking into consideration the circumstances under which the offence was committed and in particular that the accident happened early in the morning when the traffic was light and the degree of negligence was fairly slight. (To the examiner: any other suitable grounds are acceptable)
4. The Court erred in not considering the imposition of one of the following sentences:
4.1 A fine which the Appellant was well capable of paying;
4.2 A period of imprisonment wholly suspended subject to conditions;
4.3 The imposition of a fine coupled with a period of suspension, both suspended in their entirety;
4.4 The imposition of periodical imprisonment;
4.5 The imposition of correctional supervision in terms of Section 276 (1) (h).

DATED AT PORT ELIZABETH ON THIS THE _______ DAY OF _______________ 2018.

APPELLANT'S ATTORNEYS

TO: THE CLERK OF THE COURT
PORT ELIZABETH

AND TO: THE HONOURABLE MAGISTRATE
MR JACOBS
c/o CLERK OF THE COURT
PORT ELIZABETH

(8)

10.2 Power of Attorney. (1)
10.3 Within fourteen (14) days of date of conviction and to be lodged with the Clerk of the Court. (1)
10.4 An application for condonation will have to be brought and an Affidavit filed by the Appellant and possibly by any other person who can assist (possibly an attorney acting on behalf of the Appellant). (2)

QUESTION 11 [3]

11.1 In terms of Section 60 (11B) an accused is obliged to inform the Court whether:

He has previously been convicted of any offence; and

There are any charges pending against him or her and whether he or she has been released on bail in respect of these charges. (2)

11.2 Willful failure by an accused to comply with the disclosure requirement is an offence punishable by a fine (a maximum of R40 000,00) or to imprisonment not exceeding 2 years. Furthermore, a Court may withdraw bail if an accused has not correctly disclosed all his previous convictions or has failed to make a full disclosure. (1)

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5