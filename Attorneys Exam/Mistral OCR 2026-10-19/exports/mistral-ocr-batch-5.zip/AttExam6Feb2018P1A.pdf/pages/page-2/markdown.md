The employer must be asked to furnish a certificate (½) confirming your client's employment with the company (1) advising of the length of his employment with them (½), the salary that your client earned over twelve months preceding the accident (½), details of any "employment perks" he may have received, and his annual leave and sick leave entitlement (1½) and the period he was absent form work (½).

The employer must be specifically asked what payments your client received.

Whilst he was away from work from his injuries recovering from his injuries (½). The employer must be asked to state whether these payments arose out of his condition of employment (basically whether he was entitled to sick leave pay) (½) or whether the payment was ex gratia (1). Full details must be furnished by the employer.

[7]

2.2 He can claim the full amount he received over and above his sick leave entitlement because this was paid to him ex- gratia by his employer. (1)

# QUESTION 3

[2]

The minor child will not have a claim against the Road Accident Fund (1) as a ride-on lawnmower is not considered a motor vehicle. (1) One of the prerequisite elements in succeeding with a third party claim is that the injury and /or death has to be attributable to the negligent driving of a motor vehicle. A ride-on lawnmower is not a motor vehicle for the purpose of Road Accident Fund Act.

# QUESTION 4

[13]

4.1 The Defendant is in default of entering an appearance to defend and the Plaintiff is entitled to apply for Default Judgment (the procedure is outlined in Rule 31). The Plaintiff must file with the Registrar of the Court a written application for Default Judgment in duplicate and this must be accompanied by a draft Order to be granted by the Registrar when granting judgment. (2)
4.2 No. The Defendant is in default (see also Rule 31(4)). (1)
4.3 The application addressed to the Registrar would be along these lines:

The Plaintiff hereby applies that:

a) Summons having been properly served on the Defendant on (date);
b) The time for entering appearance to defend having expired on (date);
c) The Defendant not having entered an appearance to defend, judgment by default be given in favour of the Plaintiff against the Defendant as claimed in the Summons for:

(i) Payment of the sum of R ...
(ii) Interest thereon at the rate of \(10.5\%\) per annum a tempora morae;
(iii) Costs of suit;

Take notice that the Plaintiff's original Summons and Sheriff's original Return of Service is attached in support of this application. (6)

4.4 Yes. Oral evidence would then be required in order to prove the quantum of the Plaintiff's damages. Procedurally the matter would have to be set down for hearing on

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2