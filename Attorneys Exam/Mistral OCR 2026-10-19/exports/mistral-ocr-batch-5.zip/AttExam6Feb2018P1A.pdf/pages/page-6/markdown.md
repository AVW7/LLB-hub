# QUESTION 9

[13]

9.1 Absolution from the instance with plaintiff to pay the costs. (2)
9.2 Start a new action (2)
9.3 Yes (1)
9.4 I, Mechanic Fixer, do hereby state

1. I have been a motor mechanic for 10 years and are familiar with the cost of repairs for motor vehicles.
2. I have examined the motor vehicle ND 123 GP when it came to my shop for repairs.
3. I determined the cost of repairs at R30 000,00 which are fair and reasonable and are made up as follows:

Parts – R15 000,00

Labour – R15 000,00

DATED at DURBAN on 20 JANUARY 2018.

MECHANIC FIXER (4)

9.5 Give notice as contemplated by (section 129 and 130 of) the National Credit Act. (2)
9.6 File an Exception to the Defendant's Plea. (2)

# QUESTION 10

[6]

10.1 I would grant provisional sentence as the magistrate does not know from the documents whose evidence to accept. Accordingly the defendant has failed to show a defence which is more likely to succeed than the plaintiff's claim and as defendant admitted signing the cheque, provisional sentence must be granted. (3)
10.2 Within two months of provisional sentence being granted, the defendant must pay to the plaintiff the claim plus interest plus costs and give notice of intention to enter the principal case (and file a plea). (3)

# QUESTION 11

[3]

11.1 (Rule 24(10)). He must give notice at least 10 days before the hearing that he intends to do so. (1)
11.2 a) The plaintiff must notify the defendant within 5 days of receipt of such notice that he objects to the admission of these documents in evidence. b) The defendant will need to call the photographer to lead evidence. (2)

# QUESTION 12

[3]

1. Warrant of execution
2. Notice of sale in execution
3. Conditions of sale

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6