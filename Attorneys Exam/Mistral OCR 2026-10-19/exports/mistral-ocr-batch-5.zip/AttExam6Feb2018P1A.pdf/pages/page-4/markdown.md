determining the amount of the compensation or the liability of the convicted person therefor, the court may refer to the evidence and the proceedings at the trial or hear further evidence either upon affidavit or orally. (1 mark) You shall accordingly advise your client to advise the court personally (that is at the time of his giving evidence) or request the prosecutor to make such application on his behalf. The court will require documentary proof of damages in the form of expert evidence (1 mark), as in the case of a civil action. (4)

6.2 An award made under the Section shall have the effect of a civil judgement and the relevant steps to recover same are as in a civil action, i.e a warrant of execution can be issued or Sec 65 proceedings instituted. (1)

# QUESTION 7 [12]

7.1 The court will have to be convinced that there are substantial and compelling circumstances to impose a sentence less than the compulsory sentence. (2)
7.2 Section 276 stipulates the relevant sentences which may be imposed namely
7.2.1 Imprisonment
7.2.2 Periodical imprisonment
7.2.3 A fine
7.2.4 Correctional supervision (Section 276 (i))
7.2.5 Correctional supervision, that is imprisonment from which such a person may be placed under correctional supervision in the discretion of the Commissioner (Section 276 (h)

# IMPRISONMENT

Not a suitable sentence as the accused will be removed from society and family – the effect of the accused being criminalised in prison. Bring to the attention the general rule that the first offenders are if at all possible kept out of prison. The effect on his children should be mentioned. A period of imprisonment, wholly suspended and coupled with a fine can be suggested. (2)

# PERIODICAL IMPRISONMENT

If the court finds it necessary and unavoidable to imprison the Accused this can be considered. The accused will be able to continue his income-generating activities during the week and will be imprisoned over week-ends. (The benefits of this kind of sentence can be dealt with shortly by the candidate and considered by the examiner.) (2)

# FINE

A substantial fine can be considered, with a request that a portion thereof be suspended with a possible further request that the accused be permitted to pay same by way of monthly instalments. (2)

# IMPRISONMENT IN TERMS OF SECTION 276 (i)

House arrest coupled with civic programmes. (2)

# IMPRISONMENT IN TERMS OF SECTION 276 (h)

This form of imprisonment should be considered if it is apparent that the court will impose imprisonment. (2)

Note to examiner: The candidate may use any facts in argument, - (2 marks each)

(10)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4