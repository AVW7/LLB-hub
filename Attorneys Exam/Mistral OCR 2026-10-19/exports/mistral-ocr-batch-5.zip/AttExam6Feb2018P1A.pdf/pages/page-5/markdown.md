QUESTION 8

[8]

IN THE MAGISTRATE'S COURT FOR THE DISTRICT OF CAPE TOWN HELD
AT CAPE TOWN

CASE NO: 336/2016

In the matter between:

MR X

and

THE STATE

# STATEMENT IN TERMS OF SECTION 112 (2)

I, Mr X, do hereby admit that I am the accused in this matter and understand the nature of the
charges against me.

I intend pleading guilty to both charges.

# Charge 1.

I admit that on the 10th of December 2016 and on Whale Road, Cape Town, I
drove my motor vehicle with registration letters and number CA12345.

2. I admit that at the said time of driving I entered an intersection against a red
robot, colliding with another vehicle. I admit that I drove the said vehicle in a
reckless manner in that I failed to stop the vehicle in accordance with a red
robot which was against me at the time and entered the intersection at the
time when it was unsafe to do so, thus causing the collision.

# Charge 2.

I admit that:

2.1 At the time of the driving of my vehicle the alcohol contents of my blood, expressed in grams per 100ml of blood, exceeded ,05g being in fact ,07g.
2.2 I admit that at all reasonable times I was aware of the fact that one may not drive the motor vehicle while the alcohol contents of one's blood exceeds ,05gram per 100ml blood.
2.3 I admit that the blood sample was taken from my body within two hours of the collision, correctly and accurately analysed by the relative laboratory and found to be, 07gram per 100ml blood.

I accordingly plead guilty to both charges as set out above.

DATED AT CAPE TOWN ON THIS DAY OF 2017.

MR X (8)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5