# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
COURT PROCEDURES /HOFPROSEDURES
PART 1 / DEEL 1

06 FEBRUARY / 06 FEBRUARIE 2018

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT
BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF
READING.

NOTE TO EXAMINER: This guideline records the views of the drafters. There may be
justifiable variations in practice which are brought out in the
answers. When this happens the examiner should apply his
discretion in marking the answer.

# QUESTION 1

[15]

1.1 Yes. (1)

The damages are in respect of bodily injuries and are caused by / arise out of the
negligent driving of a motor vehicle.(1) Section 17(1) The Road Accident Fund Act 56
of 1996.

1.2 Yes.(1)

Although David was driving, the negligence of the other driver was the cause of the
collision. (1)

1.3 David cannot act on his own behalf as he is in a coma. (1) A curator-ad-litem (1) will
have to be appointed to lodge the claim on his behalf.

1.4 Oliver is a minor (1) and lacks legal capacity. Either Mr or Mrs Michaels may lodge a
claim on his behalf as both parents are his legal guardians. (1)

1.5 Yes. (1)

The payment by the medical aid scheme is a collateral benefit (1) and as such, does not
preclude recovery from the RAF. (1)

1.6 Yes.(1) Mr Michaels incurred these expenses and is entitled to recover them in his
personal capacity.(1)

1.7 David's claim would be apportioned by 50%. (1)

Oliver's claim would not be affected. (1)

# QUESTION 2

[8]

The letter must contain the following:

2.1 The employer must be advised that you are acting on behalf of their employee in regard
to his claim for damages arising from the injuries he sustained in the motor collision.
Details and time of the accident should be furnished. (½)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1