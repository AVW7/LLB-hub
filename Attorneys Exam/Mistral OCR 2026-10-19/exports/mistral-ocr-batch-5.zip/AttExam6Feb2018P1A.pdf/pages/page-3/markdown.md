the Unopposed Motion Roll. A Notice of Set Down would therefore, be required. The Plaintiff's witness(es) would have the give viva voce evidence. (2)

(Note: this procedure may differ in some division where damages affidavits are permitted).

4.5 Yes, the Rule (see Rule 31 (5)(a)) obliges the Plaintiff to give the Defendant not less than (5) days' notice of his/her intention to apply for Default Judgment when the Defendant is in default of delivery of a Plea after service of a Notice of Bar (in terms of Rule 26). (1)

# QUESTION 5

[12]

5.1 A Rule Nisi is a form of relief granted in Motion Court proceedings, especially urgent applications brought ex parte where the Applicant requires interim relief without or with limited notice) but where the Respondent must be given an opportunity of opposing the granting of a final order. Interdicts are a common example. (3)

5.2

5.2.1 The First Respondent is X, an adult (male) businessmen in his capacity as trustee of the XYZ Property Trust with principal place of business at (physical address);
5.2.2 The Second Respondent is Y, an adult (female) businesswoman in her capacity as trustee of the XYZ Property Trust with principal place of business at (physical address);
5.2.3 The Third Respondent is the Standard Bank of South Africa Limited, a bank duly registered in terms of the laws of the Republic of South Africa with principal place of business at M Branch (physical address); (4)

5.3 ... For an Order in the following terms:

5.3.1 That a Rule Nisi do issue calling upon the Respondents to show cause, if any , to this Honourable Court sitting at (seat of Court) on the (date) at (... am) or so soon thereafter as the matter may be heard, as to why:

a) Pending the determination of an action to be instituted by the Applicant as set out in paragraph 2.3.3 hereunder, The Second Respondent should not be interdicted and restrained from paying out any monies standing to the credit of account no. 1234567 in the name of the First Respondent.
b) The First Respondent should not be ordered to pay the costs of this application;

5.3.2 The said subparagraph 1(a) operate as an interim order pending the final determination of this application.
5.3.3 That any action which the Applicant intends bringing against the First Respondent for the recovery of the sum of R500 000.00 and any other relief be instituted within 15 (fifteen) days of the granting of this Order;
5.3.4 Alternative relief. (5)

# QUESTION 6

[5]

6.1 In terms of Section 300 where a person is convicted by a Court (1 mark) of an offence which has caused damage to or loss of property belonging to some other person (in this case the Complainant, your client) (1 mark), the Court may upon the application of the injured person or the prosecutor acting on the instructions of the injured person, forthwith award the injured compensation for such damage or loss. For the purposes of

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3