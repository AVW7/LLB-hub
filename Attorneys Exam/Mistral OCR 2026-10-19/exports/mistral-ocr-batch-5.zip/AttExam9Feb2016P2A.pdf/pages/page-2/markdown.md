Surrender Value

|  XYZ Bank – Savings Account No. 224317 | 9 | 200 000.00 [1]  |
| --- | --- | --- |
|  Proceeds of First Life Insurance Policy | 10 | 600 000.0 [1]  |
|  Awarded to the Intestate Heirs in terms of Act No.81 of 1987 [1] |  |   |

|  TOTAL ASSETS | 3 680 000.00  |
| --- | --- |

LIABILITIES

|  Administration Expenses | 11 | 12 000.00 [1]  |
| --- | --- | --- |
|  Masters fees (maximum) | 12 | 600.00 [1]  |
|  Executors Renumeration (3.5% of R3 680 00.00) | 13 | 128 800.00 [2]  |
|  KZN Funerals: Funeral costs | 14 | 28 000.00 [1]  |
|  SARS final tax assessment | 15 | 36 000.00 [1]  |
|  Dr Fine: Medical Expenses | 16 | 7 500.00 [1]  |
|  Absa Bond Account No. 3721740 | 17 | 700 000.00 [1]  |
|  Fair & Square Attorneys: | 18 | 2 500.00 [1]  |
|  Bond Cancellation Costs |  |   |
|  Transfer fees | 19 | 24 000.00 [1]  |
|  Ryan Valuers : Valuation Costs | 20 | 2 500.00 [1]  |
|  Total Liabilities |  | 941 900.00  |
|  Estate duty |  | Nil [1]  |
|  Balance available for Distribution |  | 2 738 100.00  |
|   |  | 3 680 000.00  |

RECAPITULATION STATEMENT

|  Total assets reduced to cash | 1 410 000.00 [2]  |
| --- | --- |
|  Liabilities | 941 900.00 [1]  |
|  Estate Duty | NIL  |
|  Cash Surplus | 468 100.00 [1]  |
|   | 1 410 000.00  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 2