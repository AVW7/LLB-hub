QUESTION 2

[13]

# REDISTRIBUTION AGREEMENT

ESTATE LATE NORAH BAM

MASTER'S REFERENCE NO. : 2345/2015 [1]

WHEREAS in terms of Clauses 6, 7 and 8 of the Last Will and Testament dated 17 August 2012 of the late Norah Bam, the deceased bequeathed: [1]

1. Her immovable property to her major daughter, ELIZABETH BAM, which property is valued at R700 000.00; [1]
2. Her JSE Share Portfolio to her major son, ERIC BAM, which portfolio is valued at R700 000.00; [1]
3. Cash in the amount of R1 400 000.00 to her surviving spouse, DAVID BAM, to whom she was married out of community of property; [1]

AND WHEREAS the heirs ELIZABETH BAM and ERIC BAM would prefer to receive cash in place of the specific items bequeathed to them and the surviving spouse, DAVID BAM, would prefer to receive the aforesaid specific assets; [1]

AND WHEREAS the heirs, all majors, have agreed to redistribute the assets. [1]

NOW THEREFORE the heirs agree as follows :

1. In place of the immovable property (Item 1 in the Liquidation Account), ELIZABETH BAM shall receive the equivalent value thereof of CASH in the amount of R700 000.00. [1]
2. In place of the Share Portfolio (Item 2 in the Liquidation Account), ERIC BAM shall receive the equivalent value thereof of CASH in the amount of R700 000.00. [1]
3. In place of the cash in the sum of R1 400 000.00, DAVID BAM shall receive the said immovable property valued at R700 000.00 and the share portfolio valued at R700 000.00. [1]
4. The parties acknowledge that this Redistribution Agreement is subject to confirmation by the Master of the High Court. [1]

DATED AT

THIS

DAY OF

2015. [1]

AS WITNESSES :

1.
2.

DAVID BAM

ELIZABETH BAM

ERIC BAM

[1]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 5