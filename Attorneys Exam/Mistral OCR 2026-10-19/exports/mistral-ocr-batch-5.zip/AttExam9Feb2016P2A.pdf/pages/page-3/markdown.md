# DISTRIBUTION ACCOUNT

|  Balance available for distribution | 2 738 100.00 [1]  |
| --- | --- |
|  Add Funeral Expenses | 28 000.00 [2]  |
|   | 2 766 100.00  |
|  Awarded to surviving spouse ½ share by virtue of her marriage in Community of Property | 1 383 050.00 [2]  |
|   | 1 383 050.00  |
|  Less Funeral Expenses | 28 000.00 [1]  |
|  Balance for distribution to intestate heirs | 1 383 050.00 [1]  |
|  Awarded to B surviving spouse in terms of Section 1(1)(c)(i) [1] | 451 683.33 [1]  |
|  Awarded to C major, in terms of Section 1(1)(c)(ii) [1] | 451 683.33 [1]  |
|  Awarded to D major in terms of Section 1(1)(c)(ii)[1] | 451 683.34 [1]  |
|  The above awards consist of an undivided share in the immovable property item 1 and movable assets items 2 and 3 [2] |   |
|   | 1 355 050.00  |
|   | 1 355 050.00  |

# INCOME AND EXPENDITURE ACCOUNT

|  Interest on Fixed Deposit | 10 000.00 [1]  |
| --- | --- |
|  Executors Fees (6%) | 600.00 [1]  |
|  Interest on mortgage bond | 9 400.00 [1]  |
|  Balance for distribution | Nil  |
|   | 10 000.00  |
|   | 10 000.00  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 3