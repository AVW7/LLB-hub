# **ESTATE DUTY ADDENDUM**

|  Assets as per Liquidation Account | 3 680 000.00 [1]  |
| --- | --- |
|  Less Deemed property included in Estate Account (First Life Policy) | 600 000.00 [2]  |
|   | 3 080 000.00  |
|  Less Difference in Value of Shares in Going Down (Pty) Ltd | 14 000.00 [2]  |
|   | 3 066 000.00  |
|  Less Liabilities (excluding Funeral expenses) R941 900 – R28 000 | 913 900.00 [2]  |
|   | 2 152 100.00  |
|  Less ½ share of surviving spouse | 1 076 050.00 [2]  |
|   | 1 076 050.00  |
|  Less Funeral Expenses | 28 000.00 [1]  |
|   | 1 048 050.00  |
|  Add Deemed Property |   |
|  First Life Policy | 600 000.00 [1]  |
|  Old Mutual Policy | 1 000 000.00 [1]  |
|   | 1 600 000.00  |
|  Gross Value of Estate | 2 648 050.00 [1]  |
|  Less Deductions |   |
|  Section 4Q: Inheritance | 451 683.33 [1]  |
|  Deemed property | 1 000 000.00 [1]  |
|   | 1 451 683.33  |
|   | 1 196 366.67 [2]  |
|  Less Rebate in terms of Section 4A | 3 500 000.00 [1]  |
|   | NIL [1]  |

Therefore no Estate Duty Payable

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 4