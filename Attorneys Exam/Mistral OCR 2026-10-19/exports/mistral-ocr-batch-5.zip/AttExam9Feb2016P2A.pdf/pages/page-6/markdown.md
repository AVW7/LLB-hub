# QUESTION 3

[5]

1. The testators signatures at the end of the will and in the middle of the first page is in compliance with the Wills Act No. 7 of 1953: Section 2(1)(a)(iv) [2]
2. If the Will consists more than one page, the witnesses are only required to sign the second page [2]
3. The fact that the will is not dated does not affect its validity [1]

I would advise that the Will is valid.

# QUESTION 4

[5]

a. Deposit assessed amount into the specified banking account of the Department of Justice and Constitutional Development [1]; and
b. Submit proof of payment to the Master [1]
1. 3 Marks
a. Prepare payment on e-filing [1];
b. Deposit assessed amount, by EFT, into the specified banking account of SARS [1]; and
c. Submit proof of payment to the Master [1]

NOTE: 1 mark may be given for paying cheque directly to SARS office instead paying by EFT if payment is R500 000.00 or below.

# QUESTION 5

[10]

1. W = R250000 accrual [2] and R375 000 (surviving spouse's share) [1] and R375000 (C's share); [1]

A = nil because W's adopted daughter; [1]

B = R375000 because H's illegitimate child; [1]

C = nothing because she renounced [1] – devolves on W: [1]

E and F = R187500 each as represent D (illegitimate and adopted); [1]

G = nothing as excluded [1]

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 6