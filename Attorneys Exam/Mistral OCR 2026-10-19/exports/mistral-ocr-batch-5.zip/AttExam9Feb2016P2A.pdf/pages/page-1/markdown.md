# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
ESTATES / BOEDELS
PART 2 / DEEL 2

09 FEBRUARY / FEBRUARIE 2016

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

QUESTION 1

[67]

LIQUIDATION ACCOUNT

ASSETS

IMMOVABLE PROPERTY

Erf 56 Mooi River, Registration

Division FT, Province of Kwazulu Natal

In extent 1012 square metres

Held under Deed of Transfer No. T672/2002

[1]

Valued at

Awarded to the Intestate Heirs in terms of Act

No.81 of 1987 [1]

MOVABLE PROPERTY

|  BMW car NR 21578 | 2 | 95 000.00 [1]  |
| --- | --- | --- |
|  Norinco Firearm (SFG 27416A) valued at | 3 | 15 000.00 [1]  |
|  2000 Shares in Going Down (Pty) Ltd: | 4 | 80 000.00 [1]  |
|  Realised |  |   |
|  Absa Fixed Deposit Account No. 542874 | 5 | 150 000.00 [1]  |
|  Interest accrued to date of death |  | 20 000.00 [1]  |
|  Household furniture valued at | 6 | 160 000.00 [1]  |
|  400 Shares in Fertile Farms Limited Realised | 7 | 60 000.00 [1]  |
|  Proceeds of Sanlam Policy No. X117428: | 8 | 300 000.00 [1]  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]

Page 1