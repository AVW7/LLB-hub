# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
BOOKKEEPING / BOEKHOU
PART 4 / DEEL 4

07 FEBRUARY / 07 FEBRUARIE 2018

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE
A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF
READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be
justifiable variations in practice which are brought out in the answers.
When this happens the examiner should apply his discretion in
marking the answer.

QUESTION 1

[45]

TRUST CASH BOOK

|  Correspondent | 128 500 | T/F | 24000  |
| --- | --- | --- | --- |
|   |  | Correspondent | 104 500  |
|   | 128 500 |  | 128 000  |
|  TRUST LEDGER  |   |   |   |
|  Correspondent (T)  |   |   |   |
|  Cash – Bus a/c | 24 000 | Cash | 128 500  |
|  Cash | 104 500 |  |   |
|   | 128 500 |  | 128 500  |

BUSINESS CASH BOOK

|  Correspondent | 114 500 | Disbursement | 500  |
| --- | --- | --- | --- |
|  T/F ex Trust | 24 000 | Counsel | 4500  |
|   |  | Sheriff | 500  |
|   |  | Counsel | 3000  |
|   |  | Counsel | 33 000  |
|   |  | Counsel | 22 000  |
|   |  | Expert | 35 000  |
|   |  | Balance | 40 000  |
|   | 138 500 |  | 138 500  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1