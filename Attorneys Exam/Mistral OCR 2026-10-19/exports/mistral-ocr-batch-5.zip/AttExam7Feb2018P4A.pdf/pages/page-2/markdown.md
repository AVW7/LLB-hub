# BUSINESS LEDGER
CORRESPONDENT (B)

|  Cash – Disbursements | 500 | Fees 1/3 allowance | 8000  |
| --- | --- | --- | --- |
|  Cash – Paid Counsel drafting | 4500 | Cash | 114500  |
|  Cash – Paid Sheriff | 500 | Fees 1/3 allowance | 12000  |
|  Cash – Paid Counsel pre-trial | 3000 | T/F | 24000  |
|  Cash – Paid Counsel 1^{st} day | 33000 |  |   |
|  Cash – Paid Counsel 2^{nd} day | 22000 |  |   |
|  Cash – Paid Expert witness | 35000 |  |   |
|  Interim fees | 24000 |  |   |
|  Attorney and client fee | 36000 |  |   |
|   | 158 500 |  | 158 500  |

|  FEES  |   |   |   |
| --- | --- | --- | --- |
|  Correspondent | 8 000 | Correspondent | 24 000  |
|  Correspondent | 12 000 | Correspondent | 36 000  |
|   | 20 000 |  | 60 000  |
|   |  | (one mark each entry)  |   |
|   |  |  | (32)  |

# STATEMENT OF ACCOUNT

|  Paid Disbursement | 500 |   |
| --- | --- | --- |
|  Paid Counsel | 4500 |   |
|  Paid Sheriff | 500 |   |
|  Paid Counsel | 3000 |   |
|  Paid Counsel | 33000 |   |
|  Paid Counsel | 22000 |   |
|  Paid Expert | 35000 |   |
|  Our Fees | 24000 | 8000  |
|  Cash you |  | 114500  |
|  Fees | 36000 | 12000  |
|  Received costs |  | 128 500  |
|  Cheque herewith | 104 500 |   |
|   | 263 000 | 263 000  |

(5)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2