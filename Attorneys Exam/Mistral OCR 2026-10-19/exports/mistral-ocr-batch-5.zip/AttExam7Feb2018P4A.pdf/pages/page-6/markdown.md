# STATEMENT TO BEN

|  Cash for received - deposit |  | 500 000  |
| --- | --- | --- |
|  Paid transfer duty | 50 000 |   |
|  Cash you - costs |  | 50 000  |
|  Fees | 34 200 |   |
|  Cash you - costs |  | 34 200  |
|  Cash you - guarantee |  | 1 007 800  |
|  Cash from Guarantee | 1 500 000 |   |
|  Paid Stevens (Seller) |  |   |
|  Cheque herewith | 7 800 |   |
|   | 1 592 000 | 1 592 000  |

(5)

# QUESTION 3

[15]

# Supplementary Business Cash Book March 2017(1)

|  Balance (1) | 1 482 | Adj Deposit (1) | 500  |
| --- | --- | --- | --- |
|  Electronic transfer (1) | 4 000 | Interest on OD (1) | 911  |
|   |  | Stop Order (1) | 1 000  |
|   |  | RD Cheque (1) | 1 360  |
|   |  | Balance (1) | 1 711  |
|   | 5 482 |  | 5 482  |
|  Balance (1) | 1 711 |  |   |

# Bank Reconciliation Statement at 31 March 2017 (1)

|  Balance as per bank statement (1) | (11 400)  |
| --- | --- |
|  Less: Bank Error (1) | 4 911  |
|   | (6 489)  |
|  Add o/s eft (1) | 2 800  |
|   | (9 289)  |
|  Add o/s deposit (1) | 11 000  |
|  Balance as per cash book (1) | 1 711  |

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6