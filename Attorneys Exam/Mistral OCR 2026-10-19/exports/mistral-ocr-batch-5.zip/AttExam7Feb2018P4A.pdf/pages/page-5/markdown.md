BEN

|  Cash – Transfer duty | 50 000 | Cash | 50 000  |
| --- | --- | --- | --- |
|  Fees | 34 200 | T/F | 34 200  |
|   | 84 200 |  | 84 200  |

VAT

|   | Stevens | 70  |
| --- | --- | --- |
|   | Stevens | 140  |
|   | Stevens | 280  |
|   | Ben | 4200  |

(½ mark each)

FEE JOURNAL

|  Stevens | 570  |
| --- | --- |
|  Stevens | 1140  |
|  Stevens | 2280  |
|  Black | 34 200  |
|  Fees | 33 500  |
|  VAT | 4 690  |

(6)

TRANSFER JNL

|  Stevens (Trust) | 6840  |
| --- | --- |
|  Stevens (Business) |   |
|  Ben (Trust) | 34200  |
|  Ben (Business) |   |

6840

34200

(4)

STATEMENT TO STEVENS

|  Purchase price from Ben | 1 500 000 |   |
| --- | --- | --- |
|  Cash paid to you |  | 1 500 000  |
|  Fees (Collection) | 570 |   |
|  By cash debtor |  | 10 000  |
|  Fees | 1 140 |   |
|  Cash (cheque) |  | 5 000  |
|  Cheque unpaid | 5 000 |   |
|  Paid Counsel | 2 850 |   |
|  Fees | 2 280 |   |
|  Cheque herewith | 3 160 |   |
|   | 1 515 000 | 1 515 000  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5