# FEE JOURNAL

|  Correspondent B | Dr | 24000 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 24000  |
|  Fees | Dr | 8000 |   |
|  Correspondent B | Cr |  | 8000  |
|  Correspondent B | Dr | 36000 |   |
|  Fees | Cr |  | 36000  |
|  Fees | Dr | 12000 |   |
|  Correspondent B | Cr |  | 12000  |

(8)

# TRUST JOURNAL

|  Correspondent T | 24 000  |
| --- | --- |
|  Correspondent B | 24 000  |

Transfer fees (45)

QUESTION 2 [40]

# TRUST CASH BOOK

|  Stevens | 10 000 | Nedbank | 500 000  |
| --- | --- | --- | --- |
|  Ben | 500 000 | R/D cheque | 5000  |
|  Ben | 34 200 | Stevens | 1 500 000  |
|  Stevens (Reynolds) | 5 000 | Ben | 7800  |
|  Bank | 1 000 000 | Transfer | 34200  |
|  Nedbank | 507800 | Transfer | 6840  |
|   |  | Stevens | 3160  |

# BUSINESS CASH BANK

|  Ben | 50 000 | Transfer Duty | 50 000  |
| --- | --- | --- | --- |
|  T/F | 6840 | Counsel | 2850  |
|  T/F | 34200 |  |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3