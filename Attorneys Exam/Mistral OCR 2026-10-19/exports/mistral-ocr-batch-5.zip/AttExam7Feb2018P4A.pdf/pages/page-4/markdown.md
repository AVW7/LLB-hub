# TRUST LEDGER

# STEVENS

|  Cash (RD Cheque) | 5000 | Cash | 10 000  |
| --- | --- | --- | --- |
|  T/F | 6840 | Cash - Reynolds | 5000  |
|  Cash | 3160 |  |   |
|   | 15 000 |  | 15 000  |

# BEN

|  Cash | 1 500 000 | Cash - deposit | 500 000  |
| --- | --- | --- | --- |
|  Cash | 7800 | Cash - costs | 34 200  |
|  T/F | 34 200 | Cash | 1 000 000  |
|   |  | S78 (2)(A) | 7800  |
|   | 1 542 000 |  | 1 542 000  |

# NEDBANK S78 (2)(A) - BEN

|  Cash | 500 000 | Cash | 507 800  |
| --- | --- | --- | --- |
|  Ben | 7 800 | Cash |   |

# BUSINESS LEDGER

# STEVENS

|  Fees | 570 | T/F | 6840  |
| --- | --- | --- | --- |
|  Fees | 1140 |  |   |
|  Fees | 2280 |  |   |
|  Counsel | 2850 |  |   |
|   | 6840 |  | 6840  |

# FEES

|   | Stevens | 500  |
| --- | --- | --- |
|   | Stevens | 1000  |
|   | Stevens | 2000  |
|   | Ben | 30 000  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4