QUESTION 3

[10]

Each spouse, Grace and Precious, are entitled to a child's share or R250 000,00 whichever is the greater. [2] Section 1(1)(c)(i) of Act 81 of 1987 A child's share is R900 000,00 (R4 500 000,00 divided by 5). Therefore Grace and Precious each inherit R900 000,00.[2]

Lawrence's descendants inherit the balance of R2 700 000,00, equally [1]: Section 1(1)(c)(ii) of Act 81 of 1987.

Therefore David [1], Linda [1] and Simon [1] (who represents his father) each inherit R900 000,00.

Max, Ernest, Lennox and Pilani inherit nothing.[2]

QUESTION 4

[12]

# REDISTRIBUTION AGREEMENT

MADE AND ENTERED INTO BY AND BETWEEN:-
XOLO CELE

(surviving spouse of Deceased) [ ½ ]

And

BONGANI CELE

(major heir of deceased) [ ½ ]

NOBILE CELE

(major heir of deceased)

"the parties" [ ½ ]

# WHEREAS:-

1. The late Dunstan Cele died on 13 October 2016. [1]
2. The parties being the intestate beneficiaries are equal heirs to the whole of the deceased's assets. [1]

The parties agree as follows:-

1.

Xolo Cele shall be awarded the movable assets to the value of R1 500 000,00. [1]

2.

Bongani Cele and Nombile Cele shall inherit the immovable property to the value of R3 000 000,00 in equal shares. [2]

3.

The cash of R1 000 000,00 shall be used to pay the estate liabilities. [2]

4.

The parties acknowledge that this agreement is subject to confirmation by the Master of the High Court. [2]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5