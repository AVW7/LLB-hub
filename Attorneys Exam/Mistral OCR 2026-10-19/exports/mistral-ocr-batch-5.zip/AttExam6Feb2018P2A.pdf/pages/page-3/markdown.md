|  **DISTRIBUTION ACCOUNT:-**  |   |   |
| --- | --- | --- |
|  Balance available for distribution | 6 089 400,00 |   |
|  Add Funeral Expenses | 36 000,00 | [1]  |
|   | 6 125 400,00 |   |
|  Awarded to Bion Nel surviving spouse ½ share by virtue her marriage in Community of Property | 3 062 700,00 | [2]  |
|   | 3 062 700,00 |   |
|  Less Funeral Expenses | 36 000,00 | [1]  |
|  Balance for Distribution to Intestate Heirs | 3 026 700,00 |   |
|  Awarded to Bion Nel surviving spouse in terms of Section 1(1)(c)(i) of Act 81 of 1987 | 1 008 900,00 | [1]  |
|  Awarded to Cassie Nel minor, Identity No. 020214 5135 08 7 ito Section 1(1)(c)(ii) of Act 81 of 1987 | 1 008 900,00 | [1]  |
|  Award to Carla Nel major ito Section 1(1)(c)(ii) of Act 81 of 1987 | 1 008 900,00 | [1]  |
|   | 3 026 700,00 | 3 026 700,00  |
|  **FIDUCIARY ASSET ACCOUNT:-**  |   |   |
|  Nil |  | [1]  |
|  **ESTATE DUTY:-**  |   |   |
|  Assets as per Liquidation Account | 8 500 000,00 | [1]  |
|  LESS 30% Adjustment for Farm Vula | 1 200 000,00 | [1]  |
|   | 7 300 000,00 |   |
|  LESS Adjustment valuation of Shares in Agriblock (Pty) Ltd | 8 000,00 | [1]  |
|   | 7 292 000,00 |   |
|  LESS Old Mutual Policy | 600 000,00 | [1]  |
|   | 6 692 000,00 |   |
|  LESS ½ share of surviving spouse | 3 346 000,00 | [2]  |
|   | 3 346 000,00 |   |
|  ADD : Deemed property |  |   |
|  Sanlam Policy | 1 000 000,00 | [1]  |
|  Old Mutual Policy | 600 000,00 | [1]  |
|   | 1 600 000,00 |   |
|  Gross Value | 4 946 000,00 |   |
|  LESS Allowable deductions |  |   |
|  Funeral expenses | 36 000,00 | [1]  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3