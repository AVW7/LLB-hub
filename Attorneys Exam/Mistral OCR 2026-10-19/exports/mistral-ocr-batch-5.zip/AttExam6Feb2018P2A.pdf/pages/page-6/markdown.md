DATED AT

2017

# AS WITNESSES:-

1.
2.

XOLO CELE [½]

BONGANI CELE [½]

NOBILE CELE [½]

# QUESTION 5 [11]

1. False: In terms of Section 1 of the Wills Act a competent witness means a person of 14 years or over. (2)
2. True: The period in the notice shall be not less than 30 days or not more than 3 Months (Section 29). (2)
3. True. (2)
4. False: An illegitimate child is capable of inheriting intestate from its biological father as well as the father's blood relations. (2)
5. False: The surviving testator(s) must adiate. (3)

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6