|  Liabilities and administration expenses | 2 374 600,00 |  | [1]  |
| --- | --- | --- | --- |
|  LESS ½ liabilities and administration expenses | 1 187 300,00 | 1 187 300,00 | [1]  |
|  LESS deduction i.t.o sec4(q) |  | 1 008 900,00 | 2 232 200,00 [1]  |
|  Net Value |  |  | 2 713 800,00 [1]  |
|  LESS Section 4A Rebate |  |  | 3 500 000,00 [1]  |
|  Dutiable Amount |  |  | NIL [1]  |

# **NOTE TO MARKERS:**

If another method of estate duty calculation is used and the result is the same, the candidate must be given full credit.

# **CERTIFICATE**

I declare that this account is to the best of my knowledge and belief a true and proper account of the liquidation and distribution of this estate [1] and that all assets and income collected subsequent to the death of the deceased to the date of this account [1] have been disclosed herein. [1]

DATED AT

ON THIS

DAY OF

2017

EXECUTOR

QUESTION 2

[7]

# **2.1**

Any beneficiary who is insolvent at the time of my death[1] or becomes insolvent by the time he/she is entitled to receive his/her inheritance [1] shall forfeit all rights of inheritance in terms of my Will[1], and such beneficiary's inheritance shall devolve upon such beneficiary's intestate heirs[1].

# **2.2**

The Commissioner of Oaths must certify that he is satisfied as to the identity of the testator [1] and the Will so signed is the Will of the testator[1].

Each page of the Will excluding the page on which his certificate appears is also signed anywhere on the page by the Commissioner of Oaths.

Section 2(1)(v) of the Wills Act 7 of 1953[1]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4