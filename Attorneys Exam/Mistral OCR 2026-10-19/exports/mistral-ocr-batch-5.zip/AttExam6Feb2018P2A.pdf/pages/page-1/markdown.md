# ADMISSION EXAMINATION / TOELATINGSEKSAMEN

# ESTATES / BOEDELS

# PART 2 / DEEL 2

06 FEBRUARY / 06 FEBRUARIE 2018

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

QUESTION 1

[60]

FIRST AND FINAL LIQUIDATION AND DISTRIBUTION ACCOUNT IN THE JOINT ESTATE OF THE LATE DEON NEL [1] IDENTITY NO. 560213 5162 08 4 [1] WHO DIED ON 13 MARCH 2016 [1], MARRIED IN COMMUNITY OF PROPERTY TO BION NEL (BORN KENT), IDENTITY NUMBER 590207 5003 08 9 [1] MASTER'S REFERENCE NO. 1234/2016 [1]

LIQUIDATION ACCOUNT:-

ASSETS

IMMOVABLE PROPERTY

Farm Vula No. 3259, Registration

Division ET, Province of Kwazulu Natal

Measuring 850 hectares

Held under Deed of Transfer No. T13420/1988

At Valuation

(1)

4 000 000,00 [1]

Erf 570 Ballito Registration Division ET,

Province of Kwazulu Natal measuring 1000

Square metres

Held under Deed of Transfer no. T3324/1999

At Valuation

(2)

850 000,00 [1]

MOVABLES:-

Tractors and Farm Implements

(3)

800 000,00 [1]

Cattle realised

(4)

1 500 000,00 [1]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1