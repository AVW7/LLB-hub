|  Rugger Firearm No. SD10478 at valuation | (5) | 24 000,00 | [1]  |
| --- | --- | --- | --- |
|  2000 shares in Agriblock (Pty) Ltd : realised | (6) | 24 000,00 | [1]  |
|  1000 shares in Sasol: realised | (7) | 45 000,00 | [1]  |
|  Furniture and Household effects at valuation | (8) | 241 000,00 | [1]  |
|  Absa Bank Account No. 40923116 | (9) | 166 000,00 | [1]  |

# CLAIMS IN FAVOUR OF ESTATE:-

|  Proceeds of Old Mutual Policy No. OM/326714 | (10) | 600 000,00 | [1]  |
| --- | --- | --- | --- |
|  Momentum Policy No. Z86714 | (11) | 250 000,00 | [1]  |
|  TOTAL ASSETS |  | 8 500 000,00 |   |

# DIVESTMENT NOTE:-

|  The above assets 1, 2, 3, 5 & 8 are awarded to the Intestate Heirs in terms of Act 81 of 1987 | [2]  |
| --- | --- |

# LIABILITIES:-

|  Administration Expenses:  |   |   |
| --- | --- | --- |
|  Masters fees | 600,00 | [1]  |
|  Executors fees (3.5% of R8 500 000,00) | 297 500,00 | [1]  |
|  Best Brokers fees | 1 500,00 | [1]  |
|  Other Administration expenses | 8 000,00 | [1]  |
|  Honest valuers valuation costs | 3 000,00 | [1]  |
|  Absa Bond over Farm Vula | 1 800 000,00 | [1]  |
|  Old mutual loan on policy | 10 000,00 | [1]  |
|  Angel Funerals: Funeral expenses | 36 000,00 | [1]  |
|  SARS : Final assessment | 176 000,00 | [1]  |
|  Absa: Bank Charges | 2 000,00 | [1]  |
|  PSG Attorneys: Bond Cancellation and Transfer Costs | 76 000,00 | [1]  |
|  Total Liabilities | 2 410 600,00 |   |
|  Estate Duty | NIL |   |
|  Balance Available for Distribution | 6 089 400,00 | [1]  |
|   | 8 500 000,00 |   |

# RECAPITULATION STATEMENT:-

|  Cash Assets and assets reduced to cash (Items 4, 6, 7, 9, 10 and 11 in the Liquidation Account) |   | 2 585 000,00 [2]  |
| --- | --- | --- |
|  Liabilities | 2 410 600,00 | [1]  |
|  Estate Duty | NIL |   |
|  Surplus | 174 400,00 | [1]  |
|   | 2 585 000,00 | 2 585 000,00  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2