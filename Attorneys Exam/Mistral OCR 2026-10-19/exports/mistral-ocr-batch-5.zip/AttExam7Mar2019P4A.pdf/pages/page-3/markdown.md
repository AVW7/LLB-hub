# S 86(4) GLORIA - CAPITEC

|  Cash | 2 000 000  |
| --- | --- |

# VARIOUS CLIENTS

|   | Cash | 3 500 000  |
| --- | --- | --- |

# S 86(3) ABSA

|  Cash | 3 000 000 | Cash | 2 024 000  |
| --- | --- | --- | --- |
|  Fidelity Fund | 24 000 |  |   |

# MARTIN TRUST LEDGER

|  Cash (Shares) | 296 000 | Cash | 500 000  |
| --- | --- | --- | --- |
|   |  | Cash | 348 000  |

(1 mark for each cash book and ledger entry) (33)

# LIST OF TRUST CREDITORS

|  2.2 | Sibusiso | 850 000  |
| --- | --- | --- |
|   | Gloria | 2 550 000  |
|   | Sundry clients | 3 500 000  |
|   | Martin | 552 000  |
|   | **Total Trust liabilities** | **7 452 000**  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3