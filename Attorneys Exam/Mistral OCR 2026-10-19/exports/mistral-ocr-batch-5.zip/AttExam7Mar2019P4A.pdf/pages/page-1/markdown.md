# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
LEGAL PRACTITIONERS' BOOKKEEPING / REGSPRAKTISYNSBOEKHOU
PART 4 / DEEL 4

7 MARCH / MAART 2019

ANSWERS/ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

QUESTION 1

[15]

Supplementary Business Cash Book for June 2018✓ (1)

|  Deposit | 150 000✓ (1) | Balance | 300 000✓ (1)  |
| --- | --- | --- | --- |
|  Deposit error | 180 000✓ (1) | Incorrect deposit | 108 000✓ (1)  |
|  Balance | 99 800✓ (1) | Bank Charges | 5 600✓ (1)  |
|   |  | Interest | 16 200✓ (1)  |
|   | 429 800 |  | 429 800✓  |

Bank reconciliation statement as at 30 June 2018✓ (1)

Balance as per cash book

Add: Bank error

Subtotal

Less: Outstanding eft

Balance as per

bank statement

99 800(O/D)✓ (1)

105 000✓ (1)

204 800✓ (1)

160 000✓ (1)

44 800(O/D)✓ (2)

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1