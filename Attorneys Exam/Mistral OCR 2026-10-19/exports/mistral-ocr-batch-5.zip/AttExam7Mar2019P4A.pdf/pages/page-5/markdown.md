|  Fees Journal |  | (30)  |
| --- | --- | --- |
|  Patricia (B) | 11500 |   |
|  Fees |  | 10000  |
|  Output VAT |  | 1500  |
|  Fees and VAT - Trust |  | (5)  |
|  Transfer Journal |  |   |
|  Patricia (T) | 11500 |   |
|  Patricia (B) |  | 11500  |
|  Fees Transfer |  | (4)  |
|  Accounting Statement |  |   |
|  Patricia |  |   |
|  Deposit |  | 25000  |
|  Paid Financial Adviser | 3450 |   |
|  Fees | 10000 |   |
|  VAT @ 15% | 1500 |   |
|  Cheque herewith | 10050 |   |
|   | 25000 | 25000  |
|   |  | (8)  |

# QUESTION 4 [15]

4.1.1 At the conclusion of the matter, (1)
4.1.2 Yes (1)
4.1.3 All monies received, all disbursements made, the fee charged plus Vat. (3)
4.2.1 An attorney must open a Trust Banking Account (section 86(2)), and record all transactions in a Trust Cash Book, Journal and Ledger. The attorney must also open a Business Banking Account and record all business transactions in a Business Cash Book, Journal and Ledger. The accounting records must record how ALL Trust monies are dealt with including disbursements, payments to third parties, fee transfers and payments to client.
4.2.2 Section 87 states that the accounting records must contain detail of

(a) money received and paid on its own account;
(b) money received and paid on account of any person;
(c) money invested in terms of section 86;
(d) any interest on such investments.

4.2.3 Accounting records include those relating to

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5