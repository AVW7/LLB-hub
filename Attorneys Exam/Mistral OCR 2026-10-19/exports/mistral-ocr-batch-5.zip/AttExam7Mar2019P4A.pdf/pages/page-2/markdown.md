QUESTION 2

[40]

2.1

TRUST CASH BOOK

|  Nedbank - Sibusiso | 1 000 000 | Nedbank | 1 000 000  |
| --- | --- | --- | --- |
|  Nedbank | 250 000 | Counsel – Sibusiso | 150 000  |
|  Gloria | 2 500 000 | Capitec (Gloria) | 2 000 000  |
|  Various Clients | 3 500 000 | ABSA | 3 000 000  |
|  Gloria - Costs | 250 000 | Sars | 200 000  |
|  ABSA | 2 024 000 | Fidelity Fund | 24 000  |
|  Martin | 500 000 | Stock Broker | 296 000  |
|  Stock Broker | 348 000 | Balance | 3 702 000  |
|   | 10 372 000 |  | 10 372 000  |
|   |  |  | (15)  |

TRUST LEDGER

SIBUSISO

|  Counsel | 150 000 | Cash | 1 000 000  |
| --- | --- | --- | --- |

S 86(4) Sibusiso Nedbank

|  Cash | 1 000 000 | Cash | 250 000  |
| --- | --- | --- | --- |

GLORIA

|  SARS – Transfer Duty | 200 000 | Cash | 2 500 000  |
| --- | --- | --- | --- |
|   |  | Cash Costs | 250 000  |

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2