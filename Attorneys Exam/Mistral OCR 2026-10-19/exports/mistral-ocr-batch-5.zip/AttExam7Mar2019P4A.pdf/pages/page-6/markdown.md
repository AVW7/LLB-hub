(a) money held in trust;
(b) money invested (section 86);
(c) any estate of which practitioners (or administers on behalf of) is the executor, trustee or curator;
(d) The affairs of the practice.

(10)

# NOTE TO EXAMINER:

Since most candidates will not have seen the new manuals do not penalise references to old sections:

78(1) instead of 86(2)

78(2)(a) instead of 86(3)

78 (2A) instead of 86(4)

![img-0.jpeg](img-0.jpeg)

TOTAL: [100]

# LAW SOCIETY

# OF SOUTH AFRICA

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6