# 2.3 Trust Funds Available:

|  As Per Trust Cash Book | 3 702 000  |
| --- | --- |
|  S86(4) Sibusiso | 750 000  |
|  S86(4) Gloria | 2 000 000  |
|  S86(3) | 1 000 000  |
|   | 7 452 000  |

(4)

# QUESTION 3

[30]

Trust Cash Book

|  Patricia | 25000 | Financial Adviser | 3450  |
| --- | --- | --- | --- |
|   |  | Transfer to Business | 11500  |
|   | — | Patricia | 10050  |
|   | 25000 |  | 25000  |

Patricia Trust Account

|  Financial Adviser | 3450 | Deposit | 25000  |
| --- | --- | --- | --- |
|  Transfer to Business | 11500 |  |   |
|  Bank - Patricia | 10050 |  | —  |
|   | 25000 |  | 25000  |
|  Business Cash Book  |   |   |   |
|  Transfer ex Trust | 11500 |  |   |

Patricia (B)

|  Fees and VAT | 11500 | Transfer ex Trust | 11500  |
| --- | --- | --- | --- |
|  Fees  |   |   |   |
|   |  | Patricia | 10000  |

Output VAT

|   | 1500  |
| --- | --- |
|  (1 mark for each cashbook and ledger entry) | (13)  |

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4