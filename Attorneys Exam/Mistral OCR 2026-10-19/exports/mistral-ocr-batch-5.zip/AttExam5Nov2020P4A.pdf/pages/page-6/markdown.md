|  Transfer Journal |   | DT | CT  |
| --- | --- | --- | --- |
|   | Vuyo (T) Vuyo (B) Transfer Fees | 11 900 | 11 900  |
|  |   |   |   |
|  |   |   |   |
|  |   |   |   |
|  Trust Journal |   | DT | CT  |
|   | Vuyo (T) Avi (T) (Transfer of purchase price) | 300 000 | 300 000  |
|  |   |   |   |
|  |   |   |   |
|  |   |   |   |

#### QUESTION 4

[13]

*Note to examiners: candidates were informed of error on the exam paper: question 4 (e) read: "A debit order payment for your motor vehicle of R2000 is not reflected in the cashbook". The correct amount is R2500 and the sentence should read: "A debit order payment for your motor vehicle of R2500 is not reflected in the cashbook.*

|  Dr | Business Cash Supplementary Book - June 2020 (1) |   |   | Cr  |
| --- | --- | --- | --- | --- |
|  (1) | EFT | 10000,00 | Balance b/f | 65000,00  |
|   | Balance c/f | 58500,00 | Interest on overdraft | 1000,00  |
|   |  |  | Stop order - Motor Vehicle – DEBIT ORDER | 2500,00  |
|  |   |   |   |   |
|   |  | 68500,00 |  | 68500,00  |
|   |  |  | Balance b/d | 58500,00  |
|  |   |   |   |   |
|  Bank Reconciliation Statement as at 30 June 2020 (1)  |   |   |   |   |
|   | Balance as per bank statement |  | -47000,00 | (1)  |
|   | Add outstanding payments |  | 9000,00 | (1)  |
|   | Less outstanding deposits |  | 5000,00 | (1)  |
|   | Less bank error payment |  | 1500,00 | (1)  |
|   | Add bank error deposit |  | 9000,00 | (1)  |
|  |   |   |   |   |
|   | Balance as per supplementary cash book |  | -58500,00 | (1)  |
|  |   |   |   |   |

**TOTAL: [100]**

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

6