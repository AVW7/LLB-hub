|  Correspondent | Dr | 6900 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 6000  |
|  Vat | Cr |  | 900  |

# Being fees for Drafting Trust

|  Fees | Dr | 2000 |   |
| --- | --- | --- | --- |
|  Vat | Dr | 300 |   |
|  Correspondent (B) | Cr |  | 2300  |

# Being Allowance

(2 mark for each entry = 18)
(3 discretionary marks may be awarded)

# QUESTION 3 no marks for balance 1 mark per entry [37]

|  DT | TRUST CASHBOOK | [14] | CT  |
| --- | --- | --- | --- |
|  VUYO (T) | 300 000 | Section 86(4)(INVESTEC) | 300 000  |
|  VUYO (T) | 111 900 | Section 86(3)(ABSA) | 100 000  |
|  Section 86(4) – (INVESTEC) | 303 000 | VUYO (T) | 2 850  |
|   |  | LPFF | 150  |
|  Section 86(3)(ABSA) | 101 200 |  |   |
|  V (T) (STOCKBROKER) | 65 000 | LPFF | 1 200  |
|   |  | BCB – BUS ACC | 11 900  |
|   |  | A (T) – pay agent | 10 000  |
|   |  | V (T) – pay seller (AVI) | 290 000  |
|   |  | V (T) – pay broker | 100 000  |
|   |  | Balance | 65 000  |
|   | 881 100 |  | 881 100  |

|  DT | BUSINESS CASHBOOK | [1] | CT  |
| --- | --- | --- | --- |
|  TCB (TRUST ACC) | 11 900 |  |   |

# THE TRUST LEDGER ACCOUNTS

|  DT | Vuyo (T) PURCHASER[8] |  | CT  |
| --- | --- | --- | --- |
|  TCB – EX TCB | 2 850 | TCB (EX TCB) | 300 000  |
|  V (B) – TRFR VUYO(B) | 11 900 | TCB EX TCB) | 111 900  |
|  A (T) TRFR – AVI (T) | 300 000 | Section 86(4) (EX TCB) | 2 850  |
|  TCB | 100 000 | TCB (EX TCB) | 65 000  |
|  Balance | 65 000 |  |   |
|   | 479 750 |  | 479 750  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4