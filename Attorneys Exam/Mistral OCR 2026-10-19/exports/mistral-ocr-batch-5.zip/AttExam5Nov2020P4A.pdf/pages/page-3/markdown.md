## TRANSFER JOURNAL

|  Correspondent (T) | Dr | 25 350 |   |
| --- | --- | --- | --- |
|  Corr (B) | Cr |  | 25 350  |

Transfer of value

## FEES JOURNAL

|  Correspondent (B) | Dr | 1725 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 1500  |
|  Vat | Cr |  | 225  |

Being Fees – Warrant of Execution

|  Fees | Dr | 500 |   |
| --- | --- | --- | --- |
|  Vat | Dr | 75 |   |
|  Correspondent | Cr |  | 575  |

Being Allowance

|  Correspondent | Dr | 3450 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 3000  |
|  Vat | Cr |  | 450  |

Being Collection Commission

|  Fees | Dr | 1000 |   |
| --- | --- | --- | --- |
|  Vat | Dr | 150 |   |
|  Correspondent | Cr |  | 1150  |

Being Allowance

|  Correspondent | Dr | 3450 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 3000  |
|  Vat | Cr |  | 450  |

Being Fees – Undertaking

|  Fees | Dr | 1000 |   |
| --- | --- | --- | --- |
|  Vat | Dr | 150 |   |
|  Correspondent | Cr |  | 1150  |

Being Allowance

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3