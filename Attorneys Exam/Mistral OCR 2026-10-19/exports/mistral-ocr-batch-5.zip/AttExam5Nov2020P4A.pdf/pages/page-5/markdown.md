|  DT | Avi - SELLER (T) [2] |  | CT  |
| --- | --- | --- | --- |
|  TCB – (EX TCB) | 10 000 | V (T) TRFR VUYO (T) | 300 000  |
|  TCB – (EX TCB) | 290 000 |  |   |
|   | 300 000 |  | 300 000  |

|  DT | Section 86(4) – INVESTMENT - i.f.o. VUYO [2] |  | CT  |
| --- | --- | --- | --- |
|  TCB | 300 000 | TCB | 303 000  |
|  Vuyo(T) & LPFF | 3 000 |  |   |
|   | 303 000 |  | 303 000  |

|  DT | Section 86(3) [2] |  | CT  |
| --- | --- | --- | --- |
|  TCB | 100 000 | TCB | 101 200  |
|  LPFF | 1 200 |  |   |
|   | 101 200 |  | 101 200  |

### THE BUSINESS LEDGER ACCOUNTS

|  DT | Vuyo (B) [2] |  | CT  |
| --- | --- | --- | --- |
|  Fees | 11 900 | V (T) TFR: VUYO (T) | 11 900  |
|  |   |   |   |

|  DT | Fees (B) [1] |  | CT  |
| --- | --- | --- | --- |
|   |  | V (B) VUYO (B) | 11 900  |
|  |   |   |   |

### THE JOURNALS [6]

|  Fee Journal | DT | CT  |
| --- | --- | --- |
|  Vuyo (B) | 11 900 |   |
|  Fees |  | 11 900  |
|  Fees Earned – TFR FEES COLLECTED |  |   |
|  |   |   |
|  |   |   |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5