# TRUST LEDGER  
Correspondent (Green)

|  T/F CORR (B) | 25 350 | Cash EX TCB | 50 000  |
| --- | --- | --- | --- |
|  Cash EX TCB | 24 650 |  |   |
|   | **50 000** |  | **50 000**  |

# BUSINESS CASH BOOK

|  T/F TRUST ACC | 25 350 | Sheriff | 3000  |
| --- | --- | --- | --- |
|   |  | Registrar | 2000  |
|   |  | Counsel | 10 000  |

# BUSINESS LEDGER  
Correspondent (Green)

|  Fees + VAT | 1725 | Fees + VAT (ALL) | 575  |
| --- | --- | --- | --- |
|  Cash – EX BCB | 3000 | Fees + VAT (ALL) | 1150  |
|  Fees + VAT | 3450 | Fees + VAT (ALL) | 1150  |
|  Fees + VAT | 3450 | Fees + VAT (ALL) | 2300  |
|  Cash – EX BCB | 2000 | T/F – CORR (T) | 25 350  |
|  Cash – EX BCB | 10000 |  |   |
|  Fees + VAT | 6900 |  |   |
|   | **30 525** |  | **30 525**  |

# FEES

|  Correspondent (B) | 500 | Correspondent (B) | 1500  |
| --- | --- | --- | --- |
|  Correspondent (B) | 1000 | Correspondent (B) | 3000  |
|  Correspondent (B) | 1000 | Correspondent (B) | 3000  |
|  Correspondent (B) | 2000 | Correspondent (B) | 6000  |

# VAT

|  Correspondent (B) | 75 | Correspondent (B) | 225  |
| --- | --- | --- | --- |
|  Correspondent (B) | 150 | Correspondent (B) | 450  |
|  Correspondent (B) | 150 | Correspondent (B) | 450  |
|  Correspondent (B) | 300 | Correspondent (B) | 900  |

(1/2 mark each entry = 19)

LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

2