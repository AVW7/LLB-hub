# **ADMISSION EXAMINATION**
**LEGAL PRACTITIONERS' BOOKKEEPING**
**PART 4**

**5 NOVEMBER 2020**

**MEMORANDUM**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

# **QUESTION 1** **[10]**

1.1 - Duty to implement internal administrative systems to guarantee that practitioners know and keep records of their clients.
- Report suspicious transactions to the Financial Intelligence Centre.
- Implement internal rules
- Appoint a Compliance Officer
- Train employees to recognise and deal with suspected money laundering. (5)
1.2 To indicate that you have sufficient funds in your Trust banking account and investment accounts to cover your trust liabilities. (1)
1.3 - Immediately report the deficit / shortfall to the LPC.
- Immediately rectify the Trust deficit / shortfall by transferring monies from the Business account to the Trust Account. (2)
1.4 - At the completion of a mandate.
- At early termination of a mandate. (2)

# **QUESTION 2** **[40]**

TRUST CASH BOOK

|  Debtor | 50 000 | T/F - BUS ACC | 25 350  |
| --- | --- | --- | --- |
|   |  | Correspondent (T) | 24 650  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1