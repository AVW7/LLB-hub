QUESTION 8

[5]

# VAT CLAUSE:

8.1 The purchaser and the seller hereby reciprocally warrant to each other that they are at the signature date, duly registered as VAT vendors; (1)
8.2 And it is agreed between them that:
8.2.1 the enterprise is disposed of as a going concern; (1)
8.2.2 the purchaser and seller have agreed that the enterprise will be an income producing activity at the date of transfer thereof; (1)
8.2.3 that the consideration agreed upon is inclusive of VAT at the rate of zero percent; (1)
8.2.4 if the Commissioner of Inland Revenue, rules that VAT is payable in respect of the sale of the business pursuant to this agreement at a rate exceeding zero percent then the purchaser shall pay such VAT in addition to the purchase price. (1)

TOTAL: [100]

# LAW SOCIETY

# OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6