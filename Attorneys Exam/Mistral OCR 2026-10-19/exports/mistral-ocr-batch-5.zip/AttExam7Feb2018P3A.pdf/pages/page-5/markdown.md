(a) delivered by hand;
(b) sent by prepaid registered post; or
(c) sent by courier; or
(d) sent by telegram; or
(e) sent by telefax; to the domicilium or address as selected by tenant.

7.2.4 A notice given as set out above shall be deemed to have been duly given:

(a) if delivered by hand, on the date of delivery; or
(b) if sent by prepaid registered post, on the \(7^{\text{th}}\) day after posting; or
(c) if sent by courier, on the date of delivery by the courier concerned; or
(d) if sent by telegram, on the day following the day on which the text of the notice is given to the post office for transmission; or
(e) if sent by telefax, on the expiration of 24 hours after the time of transmission. (10)

7.3 The lessee shall not, except with the prior written consent of the lessor:

7.3.1 cede all or any of its rights under this lease;
7.3.2 sublet the premises or any part thereof;
7.3.3 give up possession of the premises or any part thereof to any third party; provided that if the lessee is a juristic person the transfer of a controlling interest in lessee shall be deemed to be a cession; and provided further that the lessor shall not withhold its consent unreasonably. (5)
7.4 The lessor grants to the lessee for the duration of the lease period an option to purchase the premises on the following terms and conditions, viz:
7.4.1 The purchase price shall be the amount of R500 000 payable against registration of transfer which payment lessee shall secure by delivery to lessor or its nominee of a bank guarantee in customary form within 14 days of exercising the option.
7.4.2 Lessee may exercise the option by delivering to lessor a written notice to that effect at lessor's domicilium.
7.4.3 The sale arising from the exercise of the option shall further be subject to the terms and conditions set forth in Annexure A hereunto annexed, including the obligation of lessee/purchaser to pay all costs of transfer. (6)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5