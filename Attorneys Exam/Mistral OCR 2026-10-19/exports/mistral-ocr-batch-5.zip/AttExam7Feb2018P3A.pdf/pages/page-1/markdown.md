# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
ATTORNEYS' PRACTICE / PROKUREURSPRAKTYK
PART 3 / DEEL 3

07 FEBRUARY / 07 FEBRUARY 2018

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A
CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable
variations in practice which are brought out in the answers. When this
happens the examiner should apply his discretion in marking the answer.

# QUESTION 1

[11]

1.1 The marriage can be:

(a) in community of property - no additional formalities;
(b) out of community of property with the accrual system - ANC required;
(c) out of COP with exclusion of accrual - ANC which specifically excludes accrual. (3)

1.2 Out of COP is clearly indicated. Accrual should probably be excluded but reward any sensible answer either way. (2)
1.3 Under S.21 of Act 88/1984 the parties may jointly:
1.3.1 apply to court; (1)
1.3.2 change the property regime; (1)
1.3.3 they must show sound reasons; (1)
1.3.4 they must show notice to creditors; (1)
1.3.5 they must show no prejudice to other persons; (1)
1.3.6 the actual change is effected by means of a notarial contract duly registered. (1)

# QUESTION 2

[4]

This is an exception where an inferior court (maintenance court) can amend the order of a
superior court. Since the wife will not need representation the costs of taking action will be
minimal. The husband may also seek a decrease. Children remain entitled to maintenance
until they become self-supporting.

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1