4.2 In a discretionary trust the trustees have freedom to decide whether to make payments to whom and the amounts thereof. (2)
4.3.1 An income beneficiary may receive distributions of the income earned by the trust; (1)
4.3.2 Capital beneficiaries may or must receive a share in the capital of the trust; (1)
4.3.3 On its termination (or before if specifically provided for). (1)
4.4 The existence of a will avoids: delay in appointing an executor; (1) uncertainty arising from intestate succession; (1) uncertainty on the exact wishes of the deceased. (1)

# QUESTION 5 [6]

5.1 It is improper to borrow money from a client unless:
5.1.1 the client is a money-lender; or
5.1.2 the client is independently advised. (3)
5.2 Colleague's mandate must be terminated in writing by client; ethically you should not act until colleague's fees and disbursements have been paid or secured; as a matter of etiquette, a telephone call seems indicated. Legally, a colleague has a right of retention on documents which he/she drew or on which skill and labour has been bestowed. (3)

# QUESTION 6 [11]

6.1 S.15 of Act 53 of 1979 requires that the court be satisfied that applicant:
6.1.1 is fit and proper;
6.1.2 is 21 years of age;
6.1.3 is a SA citizen or holds permanent residence;
6.1.4 has obtained an acceptable LLB;
6.1.5 has passed the practical examination;
6.1.6 has attended an approved training course;
6.1.7 has completed the required service under a contract of articles/service. (7)
6.2 Under the new Legal Practice Act a National Forum of advocates and attorneys must agree on the implementation of the above requirements. Both advocates and attorneys become legal practitioners; those who take money from public still need trust accounts; practitioners who act on referral need not. (4)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3