QUESTION 7

[33]

7.1.1 The landlord will be entitled to cancel this lease by written notice to the tenant if the latter:

(a) fails to make any payment in terms of this lease on due date and remains in default for 7 (seven) days after receiving written notice from the landlord to make the payment;

(b) commits any other breach of this lease and fails to remedy the breach within 14 (fourteen) days after receiving written notice from the landlord to do so.

7.1.2 Should the tenant, fail to make payment to a third person as required by the lease or fail to perform any other obligation due in terms of this lease, and remain in default for 7 (seven) days after receiving written notice from the landlord, to remedy the default the landlord may without prejudice to its rights under 1, make the payment or carry out the obligation and recover the amount paid or the cost of carrying out the obligation (as the case may be) from the tenant on demand.

7.1.3 The landlord's remedies under 1 and 2 are additional to any other remedies he may have.

7.1.4 Should the landlord cancel this lease and the tenant dispute the landlord's right to do so and remain in occupation of the premises then, pending the determination of the dispute:

(a) the tenant shall continue to make all payments in terms of this lease on their due dates;

(b) the landlord's acceptance of those payments will not in any manner affect his right to cancel this lease or any other remedy he may have.

7.1.5 Should the dispute between the landlord and the tenant be determined in favour of the landlord, the payments made in terms of (a) will be regarded as amounts paid by the tenant on account of the loss sustained by the landlord as a result of the holding over of the premises by the tenant. (12)

7.2.1 For the purpose of the giving of notices and the serving of legal process in terms of this agreement the tenant chooses as its domicilium citandi et executandi (domicilium) the following:

(physical address)
(post box)
(fax number).

7.2.2 The tenant may at any time, by notice in writing to the landlord/lessor change its domicilium to any other address in the Republic of South Africa which is not a post box or poste restante.

7.2.3 Any notice given in terms of this agreement shall, save where a particular form of notice is stipulated, be:

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4