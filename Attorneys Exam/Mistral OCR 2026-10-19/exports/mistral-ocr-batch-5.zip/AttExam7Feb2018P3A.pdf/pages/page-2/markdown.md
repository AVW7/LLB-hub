QUESTION 3

[19]

# 3.1 Special power of attorney (1)

We, the undersigned, A & O

hereby appoint (name)

with power of substitution;

as our attorney and lawful agent to sign and execute on our behalf all documents necessary to establish a private company; (1)

of which we will both be directors and equal shareholders; (1)

including specifically the Notice and Memorandum of Incorporation; (1)

and any other document required by CIPC in order to effect registration; (1)

and to uplift the Certificate of Registration; (1)

and we hereby:

(a) undertake to ratify whatever our agent shall lawfully do by virtue hereof; (1)
(b) indemnify our agent against all and any costs, expenses and charges incurred in the lawful execution of the powers hereby conferred. (1)

Thus done and signed ...

# 3.2 Pre-incorporation agreement

A written agreement (1)

entered into by a person who is acting on behalf of a company which does not yet exist; (1)

with the intention that once the company comes into existence the company will be bound by the contract; (1)

once the company is incorporated the board of directors may, within three months of date of incorporation, (1)

completely, partially or conditionally ratify or reject any pre-incorporation agreement; (1)

when the three month period expires the company will otherwise be deemed to have ratified the agreement; (1)

but the person/s who entered into such contract will be jointly and severally liable for liabilities created if: (1)

(a) the company is not incorporated; or (1)
(b) once incorporated, the company rejects any part of the agreement; (1)

unless the company enters into an agreement on the same terms as, or in substitution for the agreement entered into before its incorporation; (1)

if the agreement is rejected the person who will incur liability in terms of the agreement will be permitted to recover from the company any benefit that the company received in terms of the agreement. (1)

# QUESTION 4 [11]

4.1 A trust must have a founder (donor/settlor); trustees, beneficiaries which parties may overlap. (3)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2