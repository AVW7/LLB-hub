## QUESTION 2

[11]

Jairos's estate will devolve as follows:

Selina, Mpho and Olga will each inherit either a child's share or R250 000.00, whichever is the greater (Section 1(1)(c)(i) of the Intestate Succession Act, as amended). [1]

A child's share is R1 743 000.00 ÷ 7 = R249 000.00. [1]

Selina, Mpho and Olga will therefore each inherit R250 000.00 as it is greater than the child's share. [1]

The remainder in the amount of R993 000.00 will be divided among the descendants of the deceased [1] in terms of Section 1(1)(c)(ii) of the Intestate Succession Act, as amended, as follows:

Jacob will inherit R248 250.00. [1]

Elliot will inherit R248 250.00 as he is a minor and has no capacity to renounce his rights of inheritance (Section 1(6) of the Intestate Succession Act, as amended). [1]

Ronald will inherit R124 125.00 by representation as he is the descendant of the predeceased daughter Fikile (Section 1(4)(a) of the Intestate Succession Act, as amended). [1]

Adam will inherit R124 125.00 by representation as he is the descendant of the predeceased daughter Fikile (Section 1(4)(a) of the Intestate Succession Act, as amended). [1]

Susan's share of R248 250.00 will be inherited by her husband Peter in terms of Section 1(1)(c)(i) as it is smaller than R250 000.00. [1]

Rose and Mary will not inherit anything as Susan's share will be inherited by their father. [1]

Thomas and Sophie will not inherit anything as they are ascendants. [1]

## QUESTION 3

[8]

3.1 The letter that Susan left behind is not a valid Will as it was not signed by witnesses [1].

3.2 In terms of Section 2(3) the Court is empowered to order the Master to accept a document as a valid Will [1] if the Court is satisfied that it was drafted [1] or executed [1] by a person, who has since died [1], and who intended that document to be his or her Will [1], although it does not comply with all the formalities for the execution of Wills [1]. Therefore, Steven and Mathilda will inherit if the court is satisfied that Susan intended the letter to be her Will [1].

## QUESTION 4

[8]

4.1 The ordinary place of residence of the deceased prior to his death [1], irrespective of the duration of his residence there [1].

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5