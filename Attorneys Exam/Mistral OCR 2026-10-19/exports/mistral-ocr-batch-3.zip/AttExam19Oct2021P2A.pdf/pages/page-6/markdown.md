4.2 Once the Master has exercised jurisdiction, e.g. by registering and accepting the Will, he shall continue to have jurisdiction [1].

4.3 The appointment letter shall be granted to a person who is an officer / director of the nominated corporation [1] and has been duly authorised by the said corporation to act on their behalf [1] and for whose acts and omissions as executor, the corporation accepts liability [1].

4.4 Where the value of the estate does not exceed R250 000.00 [1].

4.5 As soon as there are more than R1 000.00 estate funds on hand [1].

# **QUESTION 5**

[6]

Betty has full capacity to inherit as she did not sign as a witness [1]. In terms of the provisions of Section 4A of the Wills Act a person who signs a Will as a witness may not benefit from that Will [1]. James was appointed as the executor which is a benefit in terms of the Will [1] and therefore will not benefit [1]. Dolly, although she had capacity to sign as a witness [1], may also not benefit in terms of the Will [1].

TOTAL: [100]

![img-0.jpeg](img-0.jpeg)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6