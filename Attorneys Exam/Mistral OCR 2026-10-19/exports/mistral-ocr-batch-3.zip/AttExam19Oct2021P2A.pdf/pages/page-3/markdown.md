|  Recapitulation Statement |  |  |   |
| --- | --- | --- | --- |
|  Cash and assets reduced to cash |  |  | 3 300000.00[1]  |
|  Less: |  |  |   |
|  Liabilities |  | 300 000.00[1] |   |
|  Cash Legacies |  | NIL |   |
|  Estate Duty |  | NIL |   |
|  Cash surplus to be awarded to John Mabuza and Shirley Mabuza |  | 3000000.00 [1] |   |
|   |  | 3 300 000.00 | 3 300 000.00  |
|  Distribution Account |  |  |   |
|  Balance for distribution |  |  | 4500 000.00[1]  |
|  Awarded to: |  |  |   |
|  Amanda Mabuza, major surviving spouse i.t.o. section 1(1)(c) )(i) of the Intestate Succession Act of 1987 [1] read together with the Redistribution Agreement [1] |  | 1 500 000.00 |   |
|  Award Consists of : |  |  |   |
|  Immovable Property R1 500 000.00 [1] |  |  |   |
|  John Mabuza, major surviving son i.t.o. section 1(1)(c)(ii) of the Intestate Succession Act of 1987 read[1] together with the Redistribution Agreement[1] |  | 1 500 000.00 |   |
|  Award Consists of Cash R1 500 000.00 [1] |  |  |   |
|  Shirley Mabuza, major unmarried daughter i.t.o. section 1(1)(c)(ii) of the Intestate Succession Act of 1987 [1] read together with the Redistribution Agreement [1] |  | 1 500 000.00 |   |
|  Award Consists of Cash R1 500 000.00 [1] |  |  |   |
|   |  | 4 500 000.00 | 4 500 000.00  |
|  Income & Expenditure Account |  |  |   |
|  Interest on fixed deposit at P-Bank after date of death | 26 |  | 10 000.00[1]  |
|  Executor's remuneration @ 6% on R10 000.00 | 27 | 600.00[1] |   |
|  Balance |  | 9 400.00[1] |   |
|   |  | 10 000.00 | 10 000.00  |
|  Fiduciary Assets Account |  |  |   |
|  None |  |  | Nil [1]  |

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3