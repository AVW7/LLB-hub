|  Estate Duty Addendum |  |   |
| --- | --- | --- |
|  Actual Property of the deceased |  |   |
|  Assets as per liquidation account |  | 4800 000.00[1]  |
|  Less: Life Policy A payable to estate | 955 000.00[1] | 3 845 000.00  |
|  Less: Life Policy D payable to estate | 690 000.00[1] | 3 155 000.00  |
|  Less: Sanlam Policy paid to the estate | 40 000.00[1] | 3 115 000.00  |
|  Less: Difference in value of private shares | 30 000.00 [1] |   |
|  Less: 30% on Farming property | 450 000.00[1] | 2 635 000.00  |
|  Property Deemed to be Property |  |   |
|  Add: Life Policy A payable to estate |  | 955 000.00[1]  |
|  Add: Life Policy D payable to estate |  | 690 000.00[1]  |
|  Add: Sanlam Policy paid to the estate |  | 40 000.00[1]  |
|  Life Insurance Policy C paid to Shirley |  | 320 000.00[1]  |
|  Less: Premiums plus 6% interest | 20 000.00[1] |   |
|  Gross value of the estate |  | 4620000.00[1]  |
|  Deductions – Sec 4 |  |   |
|  Costs of Administration and Claims - Sec 4 (a-d) | 300 000.00[1] |   |
|  Sec 4(q) Benefits: |  |   |
|  Surviving spouse Amanda – inheritance | 1500 000.00[1] | 1 800 000.00  |
|  Net value of the estate |  | 2820 000.00[1]  |
|  Less: Primary Rebate – Sec 4A |  | 3500 000.00[1]  |
|  Dutiable Amount |  | 0.00[1]  |
|  Estate Duty at 20% on R0.00 |  | 0.00  |

### Executor's Certificate

I, the undersigned, John Mabuza, executor in the estate of the late Owen Mabuza, estate number 136/2021 [1] hereby declare that the estate account is to the best of my knowledge a true and proper account of the administration of the estate [1], and that to the best of my knowledge all income and expenditure after date of death are reflected [1].

Signed at Pretoria on this

day of

2021.

John Mabuza

[1]

Executor

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4