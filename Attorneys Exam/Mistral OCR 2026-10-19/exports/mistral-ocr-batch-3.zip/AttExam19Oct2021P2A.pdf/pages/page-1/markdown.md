# ADMISSION EXAMINATION

# ESTATES

# PART 2

19 OCTOBER 2021

MEMORANDUM

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

THIS GUIDELINE RECORDS THE VIEWS OF THE DRAFTERS. THERE MAY BE JUSTIFIABLE VARIATIONS IN PRACTICE WHICH ARE BROUGHT OUT IN THE ANSWERS. WHEN THIS HAPPENS THE EXAMINER SHOULD APPLY HIS DISCRETION IN MARKING THE ANSWER.

# QUESTION 1

[67]

The First and Final Liquidation and Distribution Account in the intestate estate of the late Owen Mabuza (Identity Number 520915 5638 08 3) [1] who died on 1 January 2021 [1] and who was married out of community of property without the accrual system [1].
Master's reference number: 136/2021 [1]

|  Liquidation account Assets: Immovable property The farm DINKU 879, Registration Division, JR, Gauteng Province; Measuring 210 hectares; Held by Deed of Transfer T1417/2001. [1] |  |  |   |
| --- | --- | --- | --- |
|  At valuation (To be awarded to Amanda Mabuza, major surviving spouse of the deceased, i.t.o. section 1(1)(c) of the Intestate Succession Act of 1987, read together with the Redistribution Agreement) [1] | 1 |  | 1500 000.00[1]  |
|  Movable property |  |  |   |
|  Jeep Reg. No. FXJ 795GP Sold for | 2 |  | 258000.00[1]  |
|  Sanlam Policy (ceded to ABSA bank) | 3 |  | 40 000.00[1]  |
|  Proceeds of Life Insurance Policy A | 4 |  | 955 000.00[1]  |
|  Life Insurance Policy B @ surrender value | 5 |  | 230 000.00[1]  |
|  Proceeds of Life Insurance Policy D | 6 |  | 690 000.00[1]  |
|  Shares in MEAT (Pty) Ltd Sold for | 7 |  | 480 000.00[1]  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1