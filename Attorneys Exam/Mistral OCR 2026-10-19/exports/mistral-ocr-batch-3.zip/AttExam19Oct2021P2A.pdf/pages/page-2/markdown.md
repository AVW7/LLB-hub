|  Shares in SHEEP Ltd | 8 |  | 57 000.00[1]  |
| --- | --- | --- | --- |
|  Sold for |  |  |   |
|  P-bank – Fixed deposit account No. 45268 |  |  |   |
|  Capital | 9 |  | 550 000.00[1]  |
|  Interest as at date of death | 10 |  | 40 000.00[1]  |
|  Total Assets |  |  | 4800 000.00[1]  |
|  Liabilities: |  |  |   |
|  Administration Costs |  |  |   |
|  Advertising for Debtors and Creditors |  |  |   |
|  Government Gazette | 11 | 37.82[1] |   |
|  The Star Newspaper | 12 | 362.18 |   |
|  Advertising Account for inspection |  |  |   |
|  Government Gazette | 13 | 37.82[1] |   |
|  The Star Newspaper | 14 | 362.18 |   |
|  Master's fees (maximum) | 15 | 7 000.00[1] |   |
|  Executor's fees at 3.5% on R4 800 000.00 | 16 | 168 000.00[1] |   |
|  Bank charges [1] | 17 | 3 000.00 |   |
|  Provision for Bank charges [1] | 18 | 2 150.00 |   |
|  Postage and Petties | 19 | 260.00[1] |   |
|  Broker's fees for selling shares | 20 | 2 850.00[1] |   |
|  Valuation fees for immovable property [1] | 21 | 4 000.00 |   |
|  Transfer costs on immovable property [1] | 22 | 14 500.00 |   |
|  Claims against the estate |  |  |   |
|  FINALREST – funeral expenses | 23 | 22 440.00 |   |
|  Absa Bank Overdraft | 24 | 40 000.00[1] |   |
|  Loan against Policy A | 25 | 35 000.00[1] |   |
|  Total Liabilities |  | 300 000.00 |   |
|  Estate Duty |  | Nil |   |
|  Balance for distribution |  | 4 500 000.0 |   |
|   |  | 4 800 000.00 |   |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2