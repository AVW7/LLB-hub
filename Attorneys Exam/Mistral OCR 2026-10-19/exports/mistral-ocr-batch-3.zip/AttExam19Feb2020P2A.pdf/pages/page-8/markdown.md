|  Income & Expenditure Account |  |   |
| --- | --- | --- |
|  Income |  |   |
|  Interest received on TYME Bank account |  | 8 500.00[1]  |
|  Dividends on JSE shares |  | 10 500.00[1]  |
|  Expenditure |  |   |
|  Executor's remuneration @ 6% on R 19 000.00 | 1 140.00[1] |   |
|  VAT@ 15% on R1 140.00 | 171.00[1] |   |
|  Balance awarded to Jeff Maree as the sole heir | 17 689.00[1] |   |
|   | 19 000.00 | 19 000.00  |
|  Fiduciary Assets Account |  |   |
|  Assets: |  |   |
|  FARM ORANGES 143 |  |   |
|  REGISTRATION DIVISION IR, PROVINCE OF LIMPOPO: |  |   |
|  MEASURING: 1 200H |  |   |
|  HELD UNDER DEED OF TRANSFER NO 753/96 AND REGISTERED ON 1 MAY 1996 [1] |  |   |
|  VALUED AT | 25 | 900 000.00[1]  |
|  (AWARDED AND TO BE TRANSFERRED TO JEFF MAREE MAJOR SON I.T.O. CLAUSE 4 OF THE WILL OF GABRIEL MAREE WHOSE ESTATE WAS |  |   |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

8