questioned under oath in connection with the claim [1]. **Section 32** of the Administration of Estates Act. The Master or Magistrate takes a record of the proceedings [1] and the Executor makes a decision based on the evidence submitted [1]. If he rejects the claim, he notifies the claimant in writing by registered post giving reasons [1]. **Section 33** of the Administration of Estates Act. (5)

2.3 If the claim is rejected, you are entitled to institute legal action against the estate [1], citing the Executor in his official capacity as the defendant [1]. (2)

# **QUESTION 3** [12]

3.1 On the last page (1/2), anywhere (1/2). (1)
3.2 a) Commissioner of Oaths; (1)
b) On any page [1]; anywhere [1] (2)
c) Except for the page on which the certificate appears, anywhere on all the other pages. (1)
d) That he has satisfied himself as to the identity of the testator [1] and that the will so signed is the will of the testator [1]. (2)
3.3 In view of the fact that Brian died within three months after he was divorced, Section 2(B) of the Wills Act will be applicable [1]. Pretty is considered to have died before the dissolution of the marriage [1] and she will therefore not benefit under the will [1], and the estate devolves according to the law on intestate succession [1]. As Brian has died without leaving children, his new wife, Maria, will be the sole beneficiary in terms of the Intestate Succession Act of 1987 [1].

# **QUESTION 4** [68]

THE FIRST AND FINAL LIQUIDATION AND DISTRIBUTION ACCOUNT IN THE ESTATE OF THE LATE SAMUEL MAREE (IDENTITY NUMBER 720712 5638 08 3) [1] WHO DIED ON 15 JANUARY 2019 [1] AND WHO WAS UNMARRIED AT THE TIME OF HIS DEATH [1].

MASTER'S REFERENCE NUMBER : 169/2019 [1]

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2