# **ADMISSION EXAMINATION / TOELATING SEKSAMEN  
ESTATES / BOEDELS  
PART 2 / DEEL 2**

**19 FEBRUARY / FEBRUARIE 2020**

**ANSWERS / ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY  
NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE  
MOMENT OF READING.**

**NOTE TO EXAMINER:** *THIS GUIDELINE RECORDS THE VIEWS OF THE DRAFTERS.  
THERE MAY BE JUSTIFIABLE VARIATIONS IN PRACTICE WHICH  
ARE BROUGHT OUT IN THE ANSWERS. WHEN THIS HAPPENS THE  
EXAMINER SHOULD APPLY HIS DISCRETION IN MARKING THE  
ANSWER.*

# **QUESTION 1** **[10]**

Mike's estate will devolve as follows:

Lindi, Monica and Ella each inherit a child's share or R250 000.00 whichever is the greater (Section 1(1)(c)(i) of the Intestate Succession Act, as amended). (1)

A child's share is R1 470 000.00 ÷ 6 = R245 000.00. (1)

Lindi therefore inherits R250 000.00 (1)

Monica therefore inherits R250 000.00 (1)

Ella therefore inherits R250 000.00 (1)

Fikile will inherit R240 000.00 (1)

Stella will inherit R240 000.00 and (1)

Bongani will inherit R240 000 (1)

Being the remainder and because they are the descendants of the deceased in terms of Section 1 (1)(c)(ii) of the Intestate Succession Act, as amended. (1)

Xolane and Lizie do not inherit anything. (1)

# **QUESTION 2** **[10]**

2.1 It is permissible to file a late claim against an estate [1]. If you do not satisfy the Master that you have a reasonable excuse for the delay, you will be liable for the cost of reframing the account as a result of the delay [1]. You will not have any recourse against any other creditor of the estate who has been paid a valid claim [1]. **Section 31** of the Administration of Estates Act. (3)

2.2 The Executor may require the claimant to lodge an affidavit to support his claim [1]. The Executor may require the claimant, with the consent of the Master, to appear before the Master or Magistrate nominated by the Master to be

**LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]**$^{TM}$

1