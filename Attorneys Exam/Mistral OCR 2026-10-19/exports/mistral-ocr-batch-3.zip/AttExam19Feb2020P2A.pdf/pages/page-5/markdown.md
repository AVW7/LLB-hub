|  TYME BANK FIXED DEPOSIT |  |  |   |
| --- | --- | --- | --- |
|  ACCOUNT NUMBER 9011545132566 |  |  |   |
|  CAPITAL | 8 |  | 200 000.00[1]  |
|  INTEREST AT DATE OF DEATH | 9 |  | 15 500.00[1]  |
|  (COLLECTED) |  |  |   |
|  LOAN OWING BY HANY |  |  |   |
|  COLLECTED | 10 |  | 17 000.00[1]  |
|  TOTAL ASSETS |  |  | 1 930 000.00[1]  |
|  Liabilities: |  |  |   |
|  Administration Costs |  |  |   |
|  Advertising for Debtors and Creditor |  |  |   |
|  Government Gazette |  | 37.82 |   |
|  The Star |  | 312.18[1] |   |
|  Advertising Account for inspection |  |  |   |
|  Government Gazette |  | 37.82 |   |
|  The Star | 11 | 312.18[1] |   |
|  Master's fees | 12 | 3 600.00[1] |   |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5