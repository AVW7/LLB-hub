# Recapitulation Statement

Cash and assets reduced to cash

Less:

Liabilities

Cash Legacies

Estate Duty

Cash surplus

TO BE AWARDED TO JEFF MAREE, MAJOR BROTHER AS SOLE HEIR I.T.O. SECTION 1(1)(E)(I) (BB) OF THE INTESTATE SUCCESSION ACT 81 OF 1987, AS AMENDED)

150 000.00[1]

NIL

NIL

1020000.00[1]

1 170 000.00

1 170 000.00[1]

1 170 000.00

# Distribution Account

Balance for distribution

Awarded to:

Jeff Maree, major brother of the deceased, identity number 8203135838080 as sole heir in terms of section 1(1)(e) (i) (bb) of the Intestate Succession Act 81 of 1987, as amended) [1]

Award Consists of:

Immovable property R425 000.00 [1]

Movable property R 335 000.00 [1]

Cash R1 020 000.00[1]

1 780 000.00[1]

1 780 000.00

1 780 000.00

1 780 000.00

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7