|  Liquidation account |  |  |   |
| --- | --- | --- | --- |
|  ASSETS: |  |  |   |
|  IMMOVABLE PROPERTY - AWARDED |  |  |   |
|  UNDIVIDED HALF SHARE ON ERF 145 SUNNYSIDE TOWNSHIP |  |  |   |
|  REGISTRATION DIVISION JR,PROVINCE OF GAUTENG |  |  |   |
|  MEASURING 1800M². [1] |  |  |   |
|  HELD BY DEED OF TRANSFER NO. T346/2001 | 1 |  |   |
|  VALUED AT R850 000.00 |  |  | 425 000.00[1]  |
|  (TO BE TRANSFERRED TO JEFF MAREE, HIS MAJOR BROTHER AS SOLE HEIR I.T.O. SECTION 1(1)(E) (I) (BB) OF THE INTESTATE SUCCESSION ACT 81 OF 1987, AS AMENDED) [1] |  |  |   |
|  Movable property |  |  |   |
|  Furniture and Fittings |  |  |   |
|  VALUED AT | 2 |  | 160 000.00[1]  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3