|  Executor’s fees at 3.5% on R1 930 000.00 | 13 | 67 550.00[1]  |
| --- | --- | --- |
|  VAT@ 15% on R67 550.00 | 14 | 10 132.50[1]  |
|  P Petty – Valuation costs –house [1] | 15 | 3 500.00  |
|  R Ross – Valuation costs movable property [1] | 16 | 2 500.00  |
|  Strachan Attorneys–Transfer costs -house [1] | 17 | 16 000.00  |
|  Bank charges (to date) [1] | 18 | 3 000.00  |
|  Provision for Bank charges [1] | 19 | 2 500.00  |
|  Brokers’s valuation fees | 20 | 1 500.00[1]  |
|  Postage and petties | 21 | 260.00[1]  |
|  Claims against the estate |  |   |
|  HAMBA – funeral expenses [1] |  | 20 500.00  |
|  RECEIVER OF REVENUE FOR FINAL INCOME TAX ASSESSMENT | 22 | 18 257.50[1]  |
|  Total Liabilities |  | 150 000.00  |
|  Estate Duty | 23 | NIL  |
|  Balance for distribution |  | 1 780 000.00  |
|   | 24 | 1 930 000.00  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6