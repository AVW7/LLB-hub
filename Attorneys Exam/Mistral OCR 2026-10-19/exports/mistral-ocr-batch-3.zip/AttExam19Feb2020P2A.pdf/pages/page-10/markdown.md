|  Estate Duty Addendum |  |   |
| --- | --- | --- |
|  Property of the deceased |  |   |
|  Assets as per liquidation account |  | 1 930 000.00[1]  |
|  Less: Liberty Life Policy payable to estate | 225 000.00[1] | 1705 000.00  |
|  Less: Difference in value of private shares | 20 000.00[1] | 1 685 000.00  |
|  Value of Ceasing Fideicommissum |  | 876 482.64[1]  |
|   |  | 2 561 482.64  |
|  Property Deemed to be Property |  |   |
|  Add: Liberty Life Policy payable to estate | 225 000.00[1] | 450 000.00  |
|  Sanlam Life Insurance Policy | 240 000.00[1] | 3 011 482.64[1]  |
|  Less: Premiums plus 6% p.a compounded interest thereon | 15 000.00[1] |   |
|  Gross value of the estate |  |   |
|  Deductions – Sect 4 |  | 150 000.00[1]  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

10