# ADMISSION EXAMINATION / TOELATING SEKSAMEN

# ATTORNEYS' PRACTICE / PROKUREURSPRAKTYK

# PART 3 / DEEL 3

# 19 AUGUST / AUGUSTUS 2015

# ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

# QUESTION 1

[55]

1.1 The various law societies have rules on attorney-and-client fees for debt collection. You may enter into a contingency fee agreement. The agreement must be in writing in the prescribed form, stating on what contingency you become entitled to a fee and how it is calculated and that your client was informed of all options. You may not recover more than double your normal fee or more than \(25\%\) of the amount recovered (whichever is lower). (8)
1.2 You may recover the tariff stipulated in the rules of the magistrate's court for undefended actions or any attorney-and-client fees if the debtor has consented in writing. In the Northern Provinces Rule 81 will apply. (4)
1.3 It was clearly the intention that the brothers should bind themselves jointly and severally as sureties as appears from the wording of the deed. Therefore the failure by one of the sureties to sign the document will render it invalid in terms of the provisions of section 6 of Act no 50 of 1956. You will not succeed against the signatory unless the suretyship specifically provides otherwise.(6)
1.4 It is normal practice to appoint a tracing agent on a "no trace no pay" basis. In your summons you must add a further claim for tracing costs. Substituted service is possible but not cost-effective. (4)
1.5 Yes, since A was a partner and liable at the time the cause of action arose, he remains liable. (2)
1.6 You may claim against Abe's insolvent estate and require the trustee to set aside the sale of the business in terms of Section 34 of the Insolvency Act. Ben should have required the sale to be advertised in terms of Section 34. (6)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

1