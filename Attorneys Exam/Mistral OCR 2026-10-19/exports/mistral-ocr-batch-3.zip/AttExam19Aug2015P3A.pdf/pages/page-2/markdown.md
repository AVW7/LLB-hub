1.7

14 July 2014

PER REGISTERED POST

Mr D Debtor

23 Bank Street

Margate

Dear Sir,

We act on behalf of A and refer to the acknowledgement of debt signed by you on the (date) in terms of which you acknowledged your indebtedness to our client as will more fully appear from the acknowledgement of debt.

The acknowledgement of debt provided that in the event of your failure to pay any instalment by due date our client would be obliged to give 14 days notice in writing by prepaid registered post requiring you to effect payment and in the event of your failure to make such payment our client would have the right to claim the full outstanding balance. The balance owing is the sum of R50 000 together with interest thereon at the rate of 9% per annum.

The instalment of R5 000 which was payable by you on the (date) has not been paid and consequently in accordance with the provisions of the acknowledgement of debt we hereby call upon you to effect payment of such instalment within 14 days from date of the receipt of this letter by you. Should you fail to effect payment the aforementioned full balance will become due and payable and we have instructions to issue summons against you for the recovery thereof.

This notice to you is in terms of Section 129 of the National Credit Act and you are entitled to approach us, or a debt reviewer, to deal with the repayment thereof. (5)

(Guide to examiner – this answer is a guide only. Marks to be allocated for appropriately drafted letters – reference must be made to Section 129).

1.8 You may in addition to the usual Section 65 remedies

1.8.1 Obtain an emolument attachment order in order to recover part of the salary directly from the employer;
1.8.2 You could attach the vehicle and have same sold in execution; and
1.8.3 You could attach the claim against debtor's brother by way of garnishee order.
1.9.1 The issue here is whether there is a danger of a contribution your client may be required to pay at the end of the day. A contribution is payable when there are not enough funds in the estate to defray the costs of liquidation, in which event a contribution becomes payable by those (concurrent) creditors that proved claims, on a pro rata basis. (5)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

2