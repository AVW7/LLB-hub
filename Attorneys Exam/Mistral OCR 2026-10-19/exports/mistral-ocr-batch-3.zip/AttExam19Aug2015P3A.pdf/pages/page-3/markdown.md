1.9.2 a) Resolution by your clients, if applicable;
b) Special power of attorney;
c) Affidavit;
d) Statement of account and/or other documentary proof of the claim. (4)

1.9.3 Letter to client:

We confirm that the claim forms have now being submitted to the Liquidator who will see to it that the claim will be proved at the next meeting of creditors.

After the second meeting of creditors, and provided no special meetings are held, the liquidator has to draw his account and submit same to the Master of the High Court who will inspect same, prepare a list of queries or approve the account and allow the liquidator to advertise the fact that the account will be confirmed. Thereafter the liquidator will make a distribution in terms of the account and will pay dividends to the proved creditors insofar as they have not been paid earlier. (6)

# QUESTION 2

[10]

An attorney may in principle refuse or accept any mandate. An attorney must refuse in the following circumstances:

2.1 He does not have the necessary expertise to do the work;
2.2 He does not have sufficient time to do the work;
2.3 He is in a conflict of interest situation;
2.4 He cannot come to a satisfactory arrangement about fees;
2.5 The instruction is unlawful, immoral or contrary to public policy.

He must accept a mandate from an existing client in an emergency situation. He might have to accept the mandate if there are a limited number of attorneys in a particular area which has the effect that there is no other attorney to assist the client.

# QUESTION 3

[15]

3.1 First the necessary research e.g. read Lewis and any relevant authority, then seek guidance from senior colleagues and finally from your Law Society. (3)
3.2 It is not only in order but also advisable that an attorney agrees on a fee in advance with the advocate as this will eliminate the surprise element and resultant problems if the fee is more than anticipated. It is the attorney's duty to keep his client informed of the cost implications of each case. (2)
3.3 Section 83(8) provides that only an attorney may prepare the following documents with the expectation of a fee, gain or reward;

1. An agreement or deed in respect of immovable property or rights in or to immovable property, other than leases not exceeding 5 years;
2. Conditions of sale or broker's notes;
3. a will or testamentary writing;
4. memorandum and articles of association or prospectus of a company;
5. documents relating to the creation or dissolution of a partnership or any variation of the terms thereof; and

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

3