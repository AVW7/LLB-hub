6. any instrument or document required or intended for use in civil proceedings in the Republic.

There are exemptions for advocates, trust companies and trustees in insolvencies. (5)

3.4 An attorney may not under any circumstances arrange a consultation if he knows that he will not be able to be present. Should unforeseen circumstances occur and the consultation must necessarily take place, the attorney must arrange that one of his partners, a professional assistant or a candidate attorney in his employ or a correspondent, attend to the consultation. If it is necessary for the attorney himself to attend because it is the wish of his client that he does so, the consultation should rather be postponed. (5)

# QUESTION 4 [20]

4.1 i) Notarial Bond on the equipment sold - executed in favour of seller.
ii) Cession of book debts
iii) A surety by a third party on behalf of the purchaser
iv) The taking out of an insurance policy on the life of purchaser/or a policy ceded to the seller for the balance of the purchase price.
v) Also ensure that the agreement makes provision for the reservation of ownership and has an acceleration clause. (5)

4.2 1) Perfecting of a lease agreement with a landlord
2) Obtaining/transfer of liquor licence. (2)

4.3 In the event of the purchaser failing to make any payment on due date, the entire amount/balance due in terms of this agreement shall immediately become due owing and payable. (3)
4.4 The seller will not for a period of five years, calculated from the effective date, operate a business or have an interest in/ albeit direct or indirect in any bottle store business in Gauteng. The seller agrees that this restriction is fair and reasonable having regard to the nature of the business purchased, the duration thereof and the area to which it applies. (5)

# 4.5 SECTION 34 OF THE INSOLVENCY ACT 36 AS AMENDED

Notice is hereby given in terms of Section 34(1) of the Insolvency Act 24 of 1936 that Adams Smith intends to sell his business trading as ... carried on at ... to John Brown after a period of 30 days from the date of the last publication of this notice.

DATED AT ... THIS DAY OF ... 2014.07.21

XYZ ATTORNEYS

ADDRESSS

(5)

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

4