9.4 An application for condonation will have to be brought by way of a Notice of Motion and an accompanying Affidavit filed by the Appellant and possibly by any other person who can assist (possibly an attorney acting on behalf of the Appellant). (2)

# **QUESTION 10**

[3]

Out of the Magistrates Court of Johannesburg as a *domicilium citandi et executandi* (service address) address does not confer jurisdiction and one cannot consent to the jurisdiction of a specific Magistrate's Court. You need to follow his residential address.

# **QUESTION 11**

[2]

ABC Pty Ltd will be the plaintiff as the owner of the vehicle who suffered the damages.

# **QUESTION 12**

[9]

# **NOTICE IN TERMS OF SECTION 129 OF THE NATIONAL CREDIT ACT 34 OF 2005**

**NAME OF DEBTOR:** Mr Smith  
**IDENTITY NO:** XXXXXXXXX  
**TOTAL ARREAR AMOUNT:** R R70 000  
**INTEREST RATE:** 10.25% p.a. from 1 July 2019

We act on behalf of XYZ PTY LTD, a company duly registered in accordance with the laws of the Republic of South Africa, with registration number XXXXXXX.

XYZ PTY LTD is a registered credit provider under registration number NCRCP10.

In terms of **Section 129** read together with **Section 130 of the National Credit Act No. 34 of 2005**, we advise that you have not met your obligations to our client in respect of the above account and you are in default of your payment obligations, for at least **20(twenty)** business days. Your account is in arrears as indicated above.

**In terms of Section 126B of the above Act the debt incurred in respect of your above-mentioned account has not yet been extinguished by prescription under the Prescription Act 68 of 1969.**

We request you to immediately settle the total outstanding amount to bring the arrears up to date. The amount payable may include permitted default charges and our reasonable costs to enforce the agreement up to the date of your payment. Further interest will also be charged at the rate as mentioned above on the total balance outstanding until date of final payment. Should you require the total balance due as at the day of settlement or should there be any reason why you are not making payments, kindly contact our offices on **(011) 450 1234**.

You may approach a debt counsellor in order to develop a plan that is acceptable to both you and our client to bring the payments under the agreement up to date.

---*LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

7