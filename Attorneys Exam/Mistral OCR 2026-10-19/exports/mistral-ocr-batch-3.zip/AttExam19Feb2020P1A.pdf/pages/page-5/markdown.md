1. Payment of the amount of R2,000,000 plus vat at the rate of 15%
2. Interest at the rate of 10.25% per annum from date of mora to date of payment
3. Costs of suit

Also see the precedent and notes in Harms : Amler's Precedents of Pleadings Fifth edition p 182-184. Answer 3 [4]. (10)

# QUESTION 7

[4]

7.1 In terms of Section 60 (11B) an accused is obliged to inform the Court whether:
He has previously been convicted of any offence; and
There are any charges pending against him or her and whether he or she has been released on bail in respect of these charges. (2)
7.2 Wilful failure by an accused to comply with the disclosure requirement is an offence punishable by a fine or to imprisonment. Furthermore, a Court may withdraw bail if an accused has not correctly disclosed all his previous convictions or has failed to make a full disclosure. (2)

# QUESTION 8

[5]

8.1 Yes. (1)
8.2 The attorney is an officer of the Court and may accordingly not mislead the Court in any way. (1)
8.3 The onus is upon the State to prove its case and accordingly:
The State is challenged to prove its case by way of a plea of not guilty.
No explanation of plea is to be given and the accused is to exercise his right to remain silent.
No misleading questions can be put to witnesses during cross examination which will give impression that the accused was not present, did not stab the deceased etc;
The accused will not be able to give evidence.
As soon as it appears that the State has proved its case against the accused he will be obliged either the change his plea to one of guilty to any offence which the State has been able to prove at that time or alternatively the accused will close his case and he will address he Court on the evidence before it at that point in time. (3)

# QUESTION 9

[16]

9.1

IN THE REGIONAL COURT FOR THE REGIONAL DIVISION OF GAUTENG HELD AT PRETORIA

CASE NO.

In the matter between:

MR

APPELLANT

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5