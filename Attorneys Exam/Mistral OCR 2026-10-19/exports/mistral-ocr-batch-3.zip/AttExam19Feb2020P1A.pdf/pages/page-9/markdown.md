**[1 mark for an indication that the document is a plea]**

1. The Defendant denies that this honourable court has jurisdiction to hear Plaintiff's claim as:

**[1 mark for the denial of jurisdiction]**

a. The agreement which forms the basis of the Plaintiff's claim was not concluded in the jurisdiction of the above honourable court and therefore the whole cause of action did not arise in the jurisdiction of the above honourable court; and

b. The Defendant's registered address or place of business is not in the jurisdiction of the above honourable court and never has been, the registered address and place of business is in Prince Alfred Hamlet.

**[1 mark for the above grounds in amplification of the denial of jurisdiction]**

**WHEREFORE** the Defendant prays for an order that the Plaintiff's claim be dismissed with costs.

**[1 mark for the prayer that the claim be dismissed and 1 mark for "with costs"]**

**[And 1 mark if the candidate pleads on the merits in some or other way denying liability: ]**

**DEFENDANT'S PLEA**

**KINDLY TAKE NOTE** that the Defendant pleads to Plaintiff's Particulars of Claim as follows:

**1. AD PARAGRAPH 1 OF THE PARTICULARS OF CLAIM**

The Defendant admits that the content of this paragraph only in as much as it is averred that the Plaintiff is ... (Pty) Ltd. The Defendant has no knowledge as to the rest of the content of this paragraph, denies same and puts the Plaintiff to the proof thereof... Denies any liability.

**WHEREFORE** the Defendant prays for the claim to be dismissed with costs.

Signed at [insert place] on [insert date]

...
**ATTORNEYS FOR THE DEFENDANT**
[insert address]

**TO: THE REGISTRAR OF THE REGIONAL COURT**
[insert court]

**AND TO: ...**
**ATTORNEYS FOR PLAINTIFF**

[insert address]

**TOTAL: [100]**

*LAW SOCIETY OF SOUTH AFRICA*
*LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

9