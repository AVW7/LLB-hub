# PARTICULARS OF CLAIM

1.

The plaintiff is Jennifer Jones, an adult/major female estate agent, residing at ... (or under trading under the name and style of Easysell Properties from Houghton Centre, Houghton, Johannesburg, Gauteng.

2.

The defendant is John Smith, an adult / major male pensioner, residing at 15 West Street, Durban, KwaZulu-Natal / (at least name and address required plus whose full and further particulars are unknown to the plaintiff.)

3.

The above honourable court has jurisdiction to hear the matter...

4.

Plaintiff is an estate agent who, at all relevant times, was the holder of a valid fidelity fund certificate issued to him in terms of section 29(a) of Act 112 of 1976 and who had fidelity insurance in terms of section 26(b) of Act 112 of 1976.

5.

On (date) at (place) defendant orally gave plaintiff a mandate to find a purchaser for defendant's property, being (describe) at a selling price of at least (amount).

6.

Plaintiff accepted the mandate.

7.

On (date) plaintiff introduced (X) to defendant and to the said property.

8.

As a direct result of this introduction (X) purchased the aforesaid property at a purchase price of (amount). (A copy of the deed of sale is annexed).

9.

Plaintiff was the effective cause of the sale and in the premises plaintiff duly performed her obligations in terms of the mandate given to her.

10.

It was an express term of the mandate that should plaintiff duly perform thereunder, she would be paid a commission equal to (10%) of the purchase price plus vat thereon.

11.

Despite lawful demand, defendant fails or neglects to pay the amount claimed.

Wherefore plaintiff prays for an order in the following terms:

---*LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

4