5.5 Unless the Court otherwise order by giving security for the Respondent's costs of appeal to the amount of R1 000.00 (1 mark).

5.6 An appeal shall be prosecuted within sixty (60) days after the noting of such appeal by:

5.6.1 The appellant shall within forty (40) days of noting the appeal applied to the Registrar in writing and with notice to all parties for the assignment of a date for the hearing (1 mark).
Upon receipt of such an application the appeal shall be deemed to have been duly prosecuted.

5.6.2 Upon receipt of such an application the Registrar shall forthwith assign a date of hearing which date shall be at least forty (40) days after receipt of the said application (1 mark).

5.6.3 The applicant shall simultaneously with the lodging of the application for a date for the hearing of the appeal lodge with the Registrar two copies of the record (1 mark).

5.6.4 File a notice of set down in terms of the notice from the Registrar assigning a trial date (1 mark).

# **QUESTION 6**

[13]

6.1

- No, although the general rule is that a spouse married in community of property, cannot sue or defend legal proceedings without the written consent of the other spouse. (1)

Written permission is not necessary with regard to:

- Actions between spouses. (½)
- The spouse's separate property. (½)
- The recovery of damages due to the commission of a delict against the spouse. (½)
- Any matter relating to the trade, profession or business of the spouse. (½)

**Notes: (Section 17 (1) of the Matrimonial Property Act) Dealt with in HCP Manual p31**

6.2

IN THE HIGH COURT OF SOUTH AFRICA
__________________ DIVISION

In the matter between:

__________________ Plaintiff
__________________ Defendant

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3