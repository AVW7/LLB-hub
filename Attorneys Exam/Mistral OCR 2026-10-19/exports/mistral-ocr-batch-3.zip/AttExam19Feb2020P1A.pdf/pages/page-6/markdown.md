and

THE STATE

# NOTICE OF APPEAL

**BE PLEASED TO TAKE NOTICE THAT** the Appellant notes an Appeal to the Gauteng Division of the High Court of South Africa, Pretoria against the sentence imposed upon him by the Regional Magistrate on the 3rd July 2018.

The grounds of Appeal are as follows:

1. The sentence imposed upon the appellant induces a sense of shock.
2. The learned Magistrate failed to take into consideration the personal circumstances of the Appellant and in particular that he is a first offender, is married and supports a wife and four minor children, is the sole breadwinner of the family and is a solid citizen performing social work.
3. The Magistrate erred in not taking into consideration the circumstances under which the offence was committed and in particular that the accident happened early in the morning when the traffic was light and the degree of negligence was fairly slight.
4. The Court erred in not considering the imposition of one of the following sentences:
   4.1 A fine which the Appellant was well capable of paying;
   4.2 A period of imprisonment wholly suspended subject to conditions;
   4.3 The imposition of a fine coupled with a period of suspension, both suspended in their entirety;
   4.4 The imposition of periodical imprisonment;
   4.5 The imposition of correctional supervision in terms of Section 276 (1) (h).

DATED AT PORT ELIZABETH ON THIS THE DAY OF 2018.

APPELLANT'S ATTORNEYS

TO: THE CLERK OF THE COURT
PRETORIA

AND TO: THE HONOURABLE MAGISTRATE
MR JACOBS
c/o CLERK OF THE COURT
PRETORIA

(12)

9.2 Power of Attorney (1)

9.3 Within fourteen (14) days of date of sentence. (1)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6