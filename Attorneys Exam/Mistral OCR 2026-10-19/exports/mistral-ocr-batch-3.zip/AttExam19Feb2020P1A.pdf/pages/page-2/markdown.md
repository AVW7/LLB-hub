Similarly, Mr Jones' claim for loss of earnings / earning capacity is capped at an annual amount which is prescribed by Regulation and increased quarterly by inflation. The current cap is approximately R281 000.00 per annum; (4)

2.2 Mr Jones can claim compensation for the damage to his motorcycle and any other material damages arising from the accident from the negligent motorist who caused the collision.

Mr Jones cannot claim the balance of the damages for personal injuries not covered by the Road Accident Fund Act from the negligent motorist as the common law right to claim damages not covered by the Road Accident Fund Act was abolished by the Road Accident Fund Amendment Act, 2005. (3)

2.3 The fact that Mr Jones did not have a licence to ride a motorcycle is not, per se, a bar to any claims he might have either in terms of the Road Accident Fund Act or in terms of the common law. Liability arises in delict. (2)

# **QUESTION 3** [3]

For a passenger to succeed with a claim against the Road Accident Fund proverbial 1% negligence needs to be proven on the side of the insured driver whereas for a driver to avoid any apportionment of his claim 100% negligence needs to be proven on the side of the insured driver. In other words, an apportionment is not possible against a passenger but is possible against the driver of a vehicle depending on the degree of negligence of both drivers.

# **QUESTION 4** [4]

1. Benefits derived from insurance and assurance policies maintained by the third party or bread winner;
2. Insurance and pension benefits payable to dependant's;
3. All ex gratia payments of whatever nature;
4. Money obtained from a child grant.

# **QUESTION 5** [12]

Within fifteen (15) days (1 mark) of the judgment in the Magistrate's Court hand to the Registrar or Clerk of the Court a request that a judgment in writing must be delivered showing (1 mark)

5.1 The facts that the Magistrate has found to be proved (1 mark); and
5.2 His reasons for judgment (1 mark).
5.3 An appeal may be noted within twenty (20) days after the date of the judgment appealed against or within ten (10) days after the Registrar of the Clerk of the Court has supplied a copy of the judgment in writing to the party applying therefor which ever period shall be the longer (2 marks).
5.4 An appeal shall be noted by the delivery of a notice of appeal served and filed in the Magistrate's Court (1 mark).

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2