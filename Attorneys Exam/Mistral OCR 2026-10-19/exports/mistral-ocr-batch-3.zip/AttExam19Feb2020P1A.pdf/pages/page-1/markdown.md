# **ADMISSION EXAMINATION / TOELATINGSEKSAMEN  
COURT PROCEDURES / HOFPROSEDURES  
PART 1 / DEEL 1**

**19 FEBRUARY / FEBRUARIE 2020**

**ANSWERS / ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY  
NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE  
MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

# **QUESTION 1**

**[9]**

1.1 Ms Adams will be entitled to claim as a life partner even though she and Mr Jansen were not legally married. The facts show that the deceased had undertaken to support her, creating a legally binding and enforceable contract which is protected by Section 9 of the Constitution. The common law, insofar as is necessary, has been developed to protect Ms Adam’s claim for loss of support. See **BRENDA JACOBS VS ROAD ACCIDENT FUND [ZAGPPHC 830: 2019 (2) SA 275 (GP)]** and cases referred to therein. (4)

1.2 The deceased as the biological parent of his minor children owed them a legal duty of support which he was fulfilling at the time of his death. The fact that he was not legally married to their mother is irrelevant to his duty of support. The period of support will depend on the circumstances of the family and whether, but for the accident, the children would have been supported beyond the age of 18 (attending tertiary training or work seeking).

Ms Adams, as the sole natural guardian of the children, has *locus standi* to recover on their behalf. (3)

1.3 Ms Adams in her personal capacity and as mother and natural guardian of her minor children is an “*innocent*” Plaintiff and thus no apportionment based on any alleged negligence of Mr Jansen can be applied in respect of her claims. (2)

# **QUESTION 2**

**[9]**

2.1 Mr Jones can only claim for personal injuries suffered by him from the Road Accident Fund, subject, however, to the limits imposed in the Act. His claim for general damages for pain and suffering is subject to a threshold imposed by the Road Accident Fund Amendment Act, 2005 as read with the 2008 Regulations. If Mr Jones’ injuries are not classified as “*serious*” in terms of the criteria stipulated in the Regulations he will not be entitled to claim any compensation for general damages from the Road Accident Fund.

---**LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™**

1