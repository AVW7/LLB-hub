Should there be a dispute pertaining to the agreement or the outstanding amount, you may approach:

- An alternative dispute resolution agent
- A consumer court
- An Ombud with jurisdiction

to resolve any dispute.

Unfortunately should you not respond to this notice within 10 business days of this notice being delivered to you, or sent to you by registered mail, *alternatively* respond to this notice by rejecting our proposals, we may approach a court and proceed with legal action to enforce the agreement in terms of Section 130 of the National Credit Act 34 of 2005.

**Note to examiner: reference to made to**

- Debtor
- Amount due and payable
- Interest rate
- Confirmation that amount in arrears for at least 20 business days
- S126 B that claim has not prescribed
- Options including alternative dispute resolution agent, Consumer Court, Ombud
- That legal action will be instituted after 10 business days if none of the options are elected

**QUESTION 13** [4]

a. Summons in which is included a rent interdict (Rent Interdict Summons). (1)
b. Combined Summons. (1)
c. Interpleader Summons. (1)
d. Provisional Sentence Summons. (1)

**QUESTION 14** [7]

*Note examiner: award any 7 of the following*

IN THE REGIONAL COURT FOR THE REGIONAL DIVISION OF [insert region]
HELD AT [insert seat of court]

CASE NO: 123/2020

In the matter between:

**X (PTY) LTD**

and

**Y**

**[2 marks for heading]**

**PLAINTIFF**

**DEFENDANT**

**DEFENDANT'S SPECIAL PLEA**

The Defendant refers to Plaintiff's Summons, as amplified by the Particulars of Claim, and pleads thereto as follows:

*LAW SOCIETY OF SOUTH AFRICA*
*LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]*™

8