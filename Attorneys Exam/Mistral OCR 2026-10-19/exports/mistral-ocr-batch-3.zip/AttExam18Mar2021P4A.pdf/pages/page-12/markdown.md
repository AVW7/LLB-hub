Trust reconciliation of trust creditors:

Trust Cash Book : 1 819 000

Total Trust Creditors : 1 819 000

Madonna - 650 000

Prince - 300 000

Wayne - 200 000

Bruno -150 000

Sibiya - 519 000

(7)

3.1 - (1) mark each for each ledger account = 33 marks

3.2 and 3.3 - (1) mark each balance in the trust reconciliation = 7 marks

Total = 40 marks

TOTAL: [100]

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

12