|  Correspondent | Dr | 6900 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 6000  |
|  Vat | Cr |  | 900  |

# Being Vat for Default Judgment

|  Fees | Dr | 1200 |   |
| --- | --- | --- | --- |
|  Vat | Dr | 180 |   |
|  Correspondent | Cr |  | 1380  |

# Being 20% allowance

|  Correspondent | Dr | 6900 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 6000  |
|  Vat | Cr |  | 900  |

# Being for Writ

|  Fees | Dr | 1200 |   |
| --- | --- | --- | --- |
|  Vat | Dr | 180 |   |
|  Correspondent | Cr |  | 1380  |

# Being 20% allowance

---*LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

2