|  Correspondent | 200 | Correspondent | 1000  |
| --- | --- | --- | --- |
|  Correspondent | 3000 | Correspondent | 15000  |

# **VAT**

|  Correspondent | 90 | Correspondent | 450  |
| --- | --- | --- | --- |
|  Correspondent | 180 | Correspondent | 900  |
|  Correspondent | 180 | Correspondent | 900  |
|  Correspondent | 30 | Correspondent | 150  |
|  Correspondent | 450 | Correspondent | 2250  |

½ mark each for transactions Dr or Cr = (22)

# **ABC ATTORNEYS**

Re: RED VS GREEN

|  Fee Summons | 3000 | 600  |
| --- | --- | --- |
|  Vat | 450 | 90  |
|  Paid Sheriff | 1500 |   |
|  Fee Default Judgment | 6000 | 1200  |
|  Vat | 900 | 180  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6