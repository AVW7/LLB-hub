## TRANSFER JOURNAL

|  Business Cash Book | Dr | 38 020 |   |
| --- | --- | --- | --- |
|  Trust Cash Book | Cr |  | 38 020  |
|  Correspondent (T) | Dr | 38 020 |   |
|  Correspondent (B) | Cr |  | 38 020  |

½ mark each for transactions Dr or Cr -No mark for narration and headings

(Total mark 17)

## TRUST CASH BOOK

|  Correspondent (Green) | 100 000 | Transfer | 38 020  |
| --- | --- | --- | --- |
|   |  | Correspondent | 61 980  |

## BUSINESS CASH BOOK

|  Transfer | 38 020 | Sheriff | 1500  |
| --- | --- | --- | --- |
|   |  | Sheriff | 3000  |
|   |  | Co Registered | 5000  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4