Madonna (T)

TCB – interest

4 750

TCB – deposit

650 000

Section 86(4) -
Interest

4 750

Prince (T)

TCB – deposit

300 000

Wayne (T)

TCB – deposit

200 000

![img-0.jpeg](img-0.jpeg)

Bruno (T)

TCB – deposit

150 000

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

10