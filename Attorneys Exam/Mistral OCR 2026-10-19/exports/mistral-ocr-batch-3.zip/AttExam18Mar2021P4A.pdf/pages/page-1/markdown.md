# **ADMISSION EXAMINATION  
LEGAL PRACTITIONERS' BOOKKEEPING  
PART 4  
18 MARCH 2021**

# **MEMORANDUM**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

# **QUESTION 1**

**[45]**

# Fee Journal

Correspondent Dr 3450

Fees Cr 3000

Vat Cr 450

# Being Summons Fees

Fees Dr 600

Vat Dr 90

Correspondent Cr 690

# Being 20% allowance

---**LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™**

1