|  Fee Writ | 6000 | 1200  |
| --- | --- | --- |
|  Vat | 900 | 180  |
|  Paid Sheriff | 3000 |   |
|  EFT Green |  | 100 000  |
|  Collection Commission | 1000 | 200  |
|  VAT | 150 | 30  |

Re: Registration of Company

|  Fee drafting MOI | 15000 | 3000  |
| --- | --- | --- |
|  Vat | 2250 | 450  |
|  Paid Registrar | 5000 |   |
|  EFT You | 61980 |   |
|   | 107 130 | 107 130  |

**6 marks (¼ mark for each entry)**

**TOTAL QUESTION 1 [45]**

---*LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

7