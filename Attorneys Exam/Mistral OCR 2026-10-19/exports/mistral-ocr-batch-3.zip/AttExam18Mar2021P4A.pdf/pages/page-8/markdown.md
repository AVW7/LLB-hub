QUESTION 2

[15]

# DR (+) Supplementary Cash book for February 2021 (½) CR (-)

|  Balance b/f (1) | 25 000 | Firm error – dep (1) | 18 629  |
| --- | --- | --- | --- |
|  Firm error – dep (1) | 18 269 | Bank charges (1) | 500  |
|  Reverse post dated EFT (1) | 21 600 | Interest overdraft (1) | 1 200  |
|  EFT payment–client (1) | 15 100 | Stop order (1) | 1 150  |
|   |  | Debit order (1) | 20 000  |
|   |  | Balance c/f (1) | 38 490  |
|   | 79 969 |  | 79 969  |

# Bank reconciliation statement as at 28 February 2021 (½)

|   | DR (-) | CR (+)  |
| --- | --- | --- |
|  Balance as per bank statement (1) | 15 000 |   |
|  Outstanding EFT payment from client (1) |  | 38 500  |
|  Bank error – Trust payment (1) |  | 14 990  |
|  Balance as per supplementary cash book (1) | 38 490 |   |
|   | 53 490 | 53 490  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

8