# TRUST LEDGER CORRESPONDENT (ABC ATTORNEYS)

|  Transfer | 38 020 | Cash | 100 000  |
| --- | --- | --- | --- |
|  Cash | 61 980 |  |   |

# **BUSINESS LEDGER CORRESPONDENT (ABC ATTORNEYS)**

|  Fees | 3450 | Fees | 690  |
| --- | --- | --- | --- |
|  Cash | 1500 | Fees | 1380  |
|  Fees | 6900 | Fees | 1380  |
|  Fees | 6900 | Fees | 230  |
|  Cash | 3000 | Fees | 3450  |
|  Fees | 1150 | Transfer | 38 020  |
|  Fees | 17 250 |  |   |
|  Cash | 5000 |  |   |

# **FEES**

|  Correspondent | 600 | Correspondent | 3000  |
| --- | --- | --- | --- |
|  Correspondent | 1200 | Correspondent | 6000  |
|  Correspondent | 1200 | Correspondent | 6000  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

5