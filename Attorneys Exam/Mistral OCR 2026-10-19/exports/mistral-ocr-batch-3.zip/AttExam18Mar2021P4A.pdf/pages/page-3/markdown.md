|  Correspondent | Dr | 1150 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 1000  |
|  Vat | Cr |  | 150  |

# Being collection commission

|  Fees | Dr | 200 |   |
| --- | --- | --- | --- |
|  Vat | Dr | 30 |   |
|  Correspondent | Cr |  | 230  |

# Being 20% allowance

|  Correspondent | Dr | 17 250 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 15 000  |
|  Vat | Cr |  | 2 250  |

# Being fees for MOI

|  Fees | Dr | 3000 |   |
| --- | --- | --- | --- |
|  Vat | Dr | 450 |   |
|  Correspondent | Cr |  | 3 450  |

# Being 20% allowance

---*LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

3