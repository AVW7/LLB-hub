# Sibiya (T)

|  Purchase of shares | 186 000 | TCB – deposit | 500 000  |
| --- | --- | --- | --- |
|   |  | Sale of share | 205 000  |

# Section 86(4) – First Bank

|  TCB | 650 000 | TCB | 655 000  |
| --- | --- | --- | --- |
|  Interest – Madonna | 4 750 |  |   |
|  Interest – Fidelity Fund | 250 |  |   |

# Section 86(3)– Second Bank

|  TCB | 100 000 | TCB | 110 000  |
| --- | --- | --- | --- |
|  Interest | 10 000 |  |   |

# Legal Practitioner's Fidelity Fund

|  TCB | 250 | Interest | 250  |
| --- | --- | --- | --- |
|  TCB | 10 000 | Interest | 10 000  |

(33)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

11