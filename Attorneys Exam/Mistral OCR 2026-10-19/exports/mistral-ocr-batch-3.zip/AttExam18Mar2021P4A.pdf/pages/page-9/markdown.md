**QUESTION 3**

**[40]**

Trust Ledger:

|  TRUST CASH BOOK  |   |   |   |
| --- | --- | --- | --- |
|  Madonna(T) | 650 000 | Purchase of shares | 186 000  |
|  Prince(T) | 300 000 | S86(4) | 650 000  |
|  Wayne(T) | 200 000 | S86(3) | 100 000  |
|  Bruno(T) | 150 000 | Interest – Madonna | 4 750  |
|  Sibiya(T) | 500 000 | Interest – Fidelity Fund | 250  |
|  Sale of shares | 205 000 | Interest – Fidelity Fund | 10 000  |
|  S86(4) withdrawal | 655 000 | Balance | 1 819 000  |
|  S86(3) withdrawal | 110 000 |  |   |
|   | 2 770 000 |  | 2 770 000  |
|  Balance | 1 819 000 |  |   |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

9