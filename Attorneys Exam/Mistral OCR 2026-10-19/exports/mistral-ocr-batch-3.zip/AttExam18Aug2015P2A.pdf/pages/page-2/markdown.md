|  Liquidation account Assets: Immovable property Erf 615 Naledi Township Registration Division JR, Province of Gauteng Measuring 1800m². Held by Deed of Transfer No. T234/90 [1] Sold for (to be transferred to the purchaser Sam Jones) Movable property Household Furniture and effects (½) Valued at Audi A3 motor vehicle with registration number CA4526 (½) Valued at (the above assets to be transferred to the surviving spouse as sole heir i.t.o. section 1(1)(a) of the Intestate Succession Act) [1] Liberty Life Insurance Policy No.137345X8 Proceeds of Policy Old Mutual Life Insurance Policy No.OM345Y At surrender value | 1 2 3 4 5 |  | 1 300 000.00[1] 160 000.00[½] 270 000.00[1] 560 000.00[2] 589 125.00[2]  |
| --- | --- | --- | --- |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

2