|  Property Deemed to be Property | [½] | 560 000.00[½] |   |
| --- | --- | --- | --- |
|  Add: Liberty Life Policy payable to estate |  | 170 000.00[1] |   |
|   |  | 20 000.00[1] |   |
|  Proceeds of Sanlam Life Insurance Policy |  |  |   |
|  Less: Premiums and 6% Interest |  | 59 400.00[½] | 769 400.00  |
|  Add: Accrual Claim |  |  | 3 315 000.00  |
|  Gross value of the estate |  |  |   |
|  Deductions – Sect 4 | [½] |  |   |
|  Costs of Administration and claims |  | 420 000.00[1] |   |
|  Benefits to Surviving spouse – Sect 4(q) |  | 2750000.00[1] | 3 170 000.00  |
|  Net value of the estate |  |  | 145 000.00[1]  |
|  Less: Primary Rebate – Sect 4A |  |  | 3 500 000.00[1]  |
|  Dutiable Amount |  |  | 0.00[1]  |
|  Therefore no estate duty is payable (1) |  |  | ==========  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

7