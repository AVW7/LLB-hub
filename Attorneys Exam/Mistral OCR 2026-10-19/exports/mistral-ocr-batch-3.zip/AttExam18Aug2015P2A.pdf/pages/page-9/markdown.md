IN WITNESS WHEREOF I have hereunto set my hand at CAPE TOWN this the day of JUNE 2014, in the presence of the undersigned witnesses who, in my presence and in the presence of each other have hereto subscribed their names as witnesses. (2)

RONALD EAGLE

Witnessed by:

1) ____________________ 2)____________________ (1)

QUESTION 3 [4]

The accrual of the marriage is R1 750 000.00 plus R1 250 000.00 = R3 000 000.00 (1). Each spouse should obtain R1 500 000.00 (1).

The amount of W's accrual claim is R1 500 000.00 less R1 250 000.00 = R250 000.00 (2)

QUESTION 4 [6]

1) D, E & F each inherit R500 000,00 in terms of Section 1(1) (e)(bb) of Act No. 81 of 1987. (3)
2) P would not inherit as she is not a blood relation of A. (1)
3) Yes. F would be disqualified from inheriting (1) so D and E would each inherit R750 000,00. (1)

QUESTION 5 [9]

Section 4A of the Wills Act (1) disqualifies the person who writes the will of another in his own handwriting from receiving any benefit from that will. (2) However, if the writer would have been an intestate heir of the testator if the testator had died intestate, the writer may receive the benefit, (2) provided he receives no more than he would have as an intestate heir. (2)

If A had died intestate, B would have been the sole intestate heir. (1) B may therefore receive the full testamentary benefit. (1)

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

9