|  Shares in Mogodu (Pty) Ltd |  |  |   |
| --- | --- | --- | --- |
|  Sold for | 6 |  | 11 475.00[1]  |
|  Surebank – Fixed deposit account No. 34268 | 7 |  |   |
|  Capital |  |  | 190 000.00[1]  |
|  Interest to date of death |  |  | 30 000.00[1]  |
|  Accrual claim against surviving spouse | 8 |  | 59 400.00 [1]  |
|  Total Assets |  |  | 3 170 000.00  |
|  Liabilities: |  |  |   |
|  Administration Costs |  |  |   |
|  Advertising for Debtors and Creditor |  |  |   |
|  Government Gazette |  |  |   |
|  The Star newspaper | 9 | 38.70 (¼) |   |
|   |  | 311.30 (¼) |   |
|  Advertising Account for inspection |  |  |   |
|  Government Gazette |  |  |   |
|  The Star newspaper | 10 | 38.70 (¼) |   |
|   |  | 311.30 (¼) |   |
|  Master's fees (maximum) | 11 | 600.00[1] |   |
|  Executor's fees at 3.5% on R3 170 000.00 | 12 | 110 950.00[1] |   |
|  VAT@ 14% on (R110 950.00) | 13 | 15 533.00[1] |   |
|  P Mbambala – Bond cancellation –house [1] | 14 | 5 200.00 |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

3