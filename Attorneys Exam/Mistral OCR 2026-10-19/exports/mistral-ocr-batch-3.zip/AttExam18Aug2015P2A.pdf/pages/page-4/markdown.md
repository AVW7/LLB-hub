|  J Ridge –Valuation costs of movable assets [1] | 15 | 3 000.00  |
| --- | --- | --- |
|  Bank charges [1] | 16 | 2 500.00  |
|  Postages and petties | 17 | 150.00[1]  |
|  REST – funeral expenses [1] | 18 | 8 500.00  |
|  Claims against the estate |  |   |
|  Final income tax assessment [1] | 19 | 17 867.00  |
|  Worstbank – loan for financing motor vehicle | 20 | 55 000.00[1]  |
|  Gert – bond over house | 21 | 70 000.00[1]  |
|  Agent's commission | 22 | 130 000.00[1]  |
|  Total Liabilities |  | 420 000.00  |
|  Estate Duty |  | NIL  |
|  Balance for distribution |  | 2750000.00  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

4