# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
ESTATES / BOEDELS
PART 2 / DEEL 2

18 AUGUST / AUGUSTUS 2015

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A
CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF
READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be
justifiable variations in practice which are brought out in the
answers. When this happens the examiner should apply his
discretion in marking the answer.

QUESTION 1

[65]

The First and Final Liquidation and Distribution Account in the estate of the late Koos
Swart (Identity Number 500915 5638 08 3) [1] who died on 16 July 2014 [1] and who
was married out of community of property with the inclusion of the accrual system.

[1]

Master's reference number : 369/2014 [1]

(Note: The liquidation and distribution account commences on page 2)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

1