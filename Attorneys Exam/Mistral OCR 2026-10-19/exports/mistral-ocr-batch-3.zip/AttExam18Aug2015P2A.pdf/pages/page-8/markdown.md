# Certificate

I the undersigned, Martie Swart, executrix in the estate of the late Koos Swart, (1) hereby declare that the estate account is to the best of my knowledge and belief a true and proper account of the liquidation and distribution of the estate, (1) and that to the best of my knowledge and belief all the assets (1) and income collected subsequent to date of death of the deceased to the date of this account have been disclosed. (1)

Signed at Tshwane on this 10th day of November 2014. (1)

MARTIE SWART

EXECUTRIX

QUESTION 2

[16]

LAST WILL AND TESTAMENT

This is the Last Will and Testament of me, RONALD EAGLE (Identity Number: 3201135025086), unmarried, presently of 17 The Gorge, Muizenberg, Cape Town. (1)

1. I revoke all Wills, Codicils or other testamentary acts previously made by me. (2)
2. I bequeath the following legacy:-
To my nephews, PHILIP EAGLE and ANTHONY EAGLE (1) (and failing either or both of them to his respective children by representation) (1), a cash legacy of R1 750 000.00 each (1). (3)
3. I bequeath the residue of my Estate to Dolly Hare (1) or, failing her, my descendants or, failing descendants, my said two nephews. (1) (2)
4. I appoint, ROBERT HARRIS and, failing him, NEIL HARRIS (1), to be the Executor of this my Will giving to my said Executor all powers as are allowed in law and especially the power of assumption (1). I especially direct that my Executor shall not be called upon to furnish security for acting in such capacity (1). (3)
5. I direct that the inheritance devolving upon any beneficiary under my Will as well as the proceeds, the reinvestment of such proceeds and the income thereon shall be free from the legal effects, including any accrual system, of any present or future marriage of such beneficiary whether in or out of community of property. (2)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

8