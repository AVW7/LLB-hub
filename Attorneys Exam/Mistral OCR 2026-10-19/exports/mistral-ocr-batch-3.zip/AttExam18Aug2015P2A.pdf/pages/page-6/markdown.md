|  Income & Expenditure Account |  |   |
| --- | --- | --- |
|  INCOME |  |   |
|  Interest paid on fixed deposit with Surebank |  | 10 000.00[1]  |
|  Expenditure |  |   |
|  Executor's remuneration @ 6% on R10 000.00 | 600.00 [1] |   |
|  VAT @ 14% on R600.00 | 84.00 [1] |   |
|  Balance to be paid to the surviving spouse as sole heir [1] | 9 316.00 [1] |   |
|   | 10 000.00 | 10 000.00  |
|  Fiduciary Assets Account |  |   |
|  None |  | Nil [1]  |
|  Estate Duty Addendum |  |   |
|  Property of the deceased [½] |  |   |
|  Assets as per liquidation account |  | 3 170 000.00[1]  |
|  Less : Liberty Life Policy payable to estate | 560 000.00[½] |   |
|  Less: Difference in value of private shares | 5 000.00[1] | 2 610 000.00  |
|  Less: Accrual Claim | 59 400.00[½] | 2 605 000.00  |
|   |  | 2 545 600.00  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

6