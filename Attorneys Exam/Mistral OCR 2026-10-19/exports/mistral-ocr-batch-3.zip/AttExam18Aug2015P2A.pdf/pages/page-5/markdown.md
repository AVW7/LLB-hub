|  Recapitulation Statement |  |   |
| --- | --- | --- |
|  Cash and assets reduced to cash |  | 2 740 000.00[2]  |
|  Less: |  |   |
|  Liabilities | 420 000.00[1] |   |
|  Cash Legacies | NIL |   |
|  Estate Duty | NIL |   |
|  Cash surplus | 2 320 000.00[1] |   |
|  (to be awarded to the surviving spouse as sole heir) [1] | 2 740 000.00 | 2 740 000.00  |
|  Distribution Account |  |   |
|  Balance for distribution |  | 2 750 000.00[1]  |
|  Awarded to: |  |   |
|  Martie Swart, surviving spouse [1], as sole heir i.t.o. section 1(1)(a) of the Intestate Succession Act of 1987 [1] | 2 750 000.00 |   |
|  Award Consists of: |  |   |
|  Movable assets R 430 000.00[1] |  |   |
|  Cash R2 320 000.00[1] | 2 750 000.00 | 2 750 000.00  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]©

5