|  **Distribution Account** |  |  |   |
| --- | --- | --- | --- |
|  Balance for distribution |  |  | 4 800 000.00 [1]  |
|  Awarded to: Jane Venter, a major surviving spouse of the deceased in terms of clause 4 & 5 of the Last Will and Testament of the Deceased [1] |  | 4 800 000.00 |   |
|  Award Consists of: Immovable Property: R2 300 000.00[1] Movable Property: R 336 000.00[1] Cash: R2 164 000.00[1] R4 800 000.00 |  |  |   |
|   |  | **4 800 000.00** | **4 800 000.00**  |
|  **Income & Expenditure Account** |  |  |   |
|  Interest paid on investment account | (26) |  | 10 000.00 [1]  |
|  Dividends paid on MILK Ltd shares | (27) |  | 54 000.00 [1]  |
|  Executor's Remuneration @ 6% on R64 000.00 | (28) | 3 840.00 [1] |   |
|  Balance awarded to Jane Venter as sole heir |  | 60 160.00 [1] |   |
|   |  | 64 000.00 | 64 000.00  |
|  **Fiduciary Assets Account** |  |  |   |
|  None |  |  | 0.00 [1]  |
|  **Estate Duty Addendum** |  |  |   |
|  Property of the deceased |  |  |   |
|  Assets as per liquidation Account |  |  | 5 200 000.00 [1]  |
|  Less: Proceeds of Liberty Life Insurance Policy |  | 300 000.00 [1] |   |
|   |  |  | 4 900 000.00  |
|  Less: Difference in value of private shares |  | 100 000.00 [1] |   |
|   |  |  | 4 800 000.00  |
|  Less: 30% on Farming property |  | 690 000.00 [1] |   |
|   |  |  | 4 110 000.00  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5