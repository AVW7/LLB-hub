1.8 Collation is the process by which the inheritance of certain heirs of the deceased is adjusted in the distribution account to consider any benefits received from the testator during his lifetime. [2]

## QUESTION 2

[8]

2.1 Jill inherits a child's share (R5 000 000.00 ÷ 4 = R1 250 000.00) or R250 000.00 of the Estate in terms of Section 1(1)(c)(i) of the Intestate Succession Act 81 of 1987, whichever is the greater [2]. As a child's share is greater, Jill will inherit a child's share in the amount of R1 250 000.00. [1]
2.2 Jack does not inherit as Tom is survived by his spouse and descendants. [1]
2.3 Lynn does not inherit as they were no longer married. [1]
2.4 Ed and Samantha inherit a child's share of R1 250 000.00 each. [2]
2.5 Craig will inherit a child's share of R1 250 000.00. [1]

## QUESTION 3

[59]

The First and Final Liquidation and Distribution Account in the estate of the late Piet Venter (Identity Number 650315 5638 08 3) [1] who died on 5 November 2020 [1] and who was married out of community of property without the accrual system. [1]

Master's reference number: 1369/2020. [1]

|  **Liquidation Account Assets:** Immovable Property The farm Morula 501, Registration Division, JR, Gauteng Province; Measuring 360 HA; Held by Deed of Transfer T1206/2009 [1] At Valuation To be transferred to Jane Venter, the surviving spouse, in terms of clause 4 of the Last Will and Testament of the Deceased [1] Erf 168 Doornkop Township Registration Division JR, Province of Gauteng Measuring 900m² | (1) | R | R  |
| --- | --- | --- | --- |
|   |  |  | 2 300 000.00 [1]  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2