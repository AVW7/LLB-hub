|  Master's Fees (maximum) | (15) | 7 000.00 [1] |   |
| --- | --- | --- | --- |
|  Executor's Fees at 3.5% on R5 200 000.00 | (16) | 182 000.00 [1] |   |
|  Bank charges to date | (17) | 25 000.00 [1] |   |
|  Provision for bank charges [1] | (18) | 2 000.00 |   |
|  Postage and petties [1] | (19) | 1 500.00 |   |
|  Brokers fees for valuation of JSE shares [1] | (20) | 260.00 [1] |   |
|  Ntuli & Co. – Valuation costs for the farm and movable properties [1] | (21) | 22 000.00 |   |
|  Fouche Attorneys – Provision for transfer costs for the farm [1] | (22) | 27 000.00 |   |
|  Claims against the estate | (23) | 48 000.00 |   |
|  Phomola – Funeral Expenses [1] | (24) | 54 440.00 |   |
|  Loan against Liberty Policy | (25) | 30 000.00 [1] |   |
|  **TOTAL LIABILITIES** |  | **400 000.00** |   |
|  Estate Duty |  | 0.00 |   |
|  Balance for Distribution |  | 4 800 000.00 |   |
|  **TOTAL** |  | **5 200 000.00** | **5 200 000.00**  |

|  **Recapitulation Statement** |  |  |   |
| --- | --- | --- | --- |
|  Cash and assets reduced to cash |  |  | 2 564 000.00 [1]  |
|  Less: Liabilities |  | 400 000.00 [1] |   |
|  Cash Legacies |  | 0.00 |   |
|  Estate Duty |  | 0.00 |   |
|  Cash surplus to be paid to Jane Venter as sole heir |  | 2 164 000.00 [1] |   |
|   |  | **2 564 000.00** | **2 564 000.00**  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4