# **ADMISSION EXAMINATION**
**ESTATES**
**PART 2**
**17 MARCH 2021**

# **ANSWERS / ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** *THIS GUIDELINE RECORDS THE VIEWS OF THE DRAFTERS. THERE MAY BE JUSTIFIABLE VARIATIONS IN PRACTICE WHICH ARE BROUGHT OUT IN THE ANSWERS. WHEN THIS HAPPENS THE EXAMINER SHOULD APPLY HIS DISCRETION IN MARKING THE ANSWER.*

# **QUESTION 1** [18]

1.1 Massing occurs when two or more persons, with testamentary capacity [1], combine or consolidate their separate estates (or their undivided half shares of their joint estate when they are married in community of property) into a single estate [1], prescribing in the Will what must be done with their consolidated estate [1] but leaving a benefit in favour of the survivor [1]. A joint will is usually drawn in this instance.

1.2 I, Arthur Boyd, in my capacity as Commissioner of Oaths, certify that
1.2.1 I have satisfied myself as to the identity of the testator [1]
1.2.2 This Will so signed is also the Will of the testator [1]

DATED AT _______________ THIS ___ DAY OF _______________ 2021

ARTHUR BOYD
COMMISSIONER OF OATHS [1]

1.3 The Commissioner of Oaths must certify as soon as possible after the testator has signed [1] even after testator has died. [1]

1.4 A person of the age of 14 years [1] and competent to give evidence in a Court of law. [1]

1.5 A person of the age of 16 years or more [1] and as long as he is mentally capable of appreciating the nature and effect of his act. [1]

1.6 A bequest in a Will of specific property (movable or immovable) [1] to a specific person, Trust or Charity. [1]

1.7 No. [1]

*LAW SOCIETY OF SOUTH AFRICA*
*LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

1