# **QUESTION 4**

**[10]**

4.1 Notice to debtors and creditors [also Sect 29 Notice] **[1]** and that the Liquidation and Distribution account lies open for inspection [also Sect 35 Notice]. **[1]**

4.2 Sect 29 – after receipt of the Letters of Executorship.**[1]**
Sect 35 – after the estate account has been approved by the Master. **[1]**

4.3 Government Gazette **[1]** and the Local newspaper circulating in the area where the deceased was resident. **[1]**

4.4 Sect 29 = minimum of 30 days and maximum of 3 months. **[1]**
Sect 35 = not less than 21 days. **[1]**

4.5 Sect 29 = to request creditors to submit their claims against the estate. **[1]**
Sect 35 = to give interested parties the opportunity to inspect and lodge an objection against the estate account (if any). **[1]**

# **QUESTION 5**

**[5]**

|  Net value of Estate | 7 000 000,00 **[1]**  |
| --- | --- |
|  Less Primary Rebate | 3 500 000,00 **[1]**  |
|   | ---  |
|   | 3 500 000,00  |

|  Less Roll over of the rebate from the estate of the first dying spouse | 3 500 000,00 **[2]**  |
| --- | --- |
|   | ---  |
|   | NIL **[1]**  |
|   | ==========  |

Therefore no estate duty payable.

**TOTAL: [100]**

*LAW SOCIETY OF SOUTH AFRICA*
*LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

7