|  Held by Deed of Transfer T1786/99 [1] Sold For | (2) |  | 450 000.00 [1]  |
| --- | --- | --- | --- |
|  Movable Property: Farm Implements At Valuation: | (3) |  | 190 000.00 [1]  |
|  1200 shares in Milk Ltd Valued by Stockbrokers | (4) |  | 146 000.00 [1]  |
|  Items 3 & 4 to be awarded to Jane Venter, the surviving spouse, in terms of clause 5 of the of the Last Will and Testament of the Deceased [1] |  |  |   |
|  Loan Collected (The Venter Family Trust) | (5) |  | 280 000.00 [1]  |
|  BMW X5, Registration BD 80 LD GP Sold for | (6) |  | 209 000.00 [1]  |
|  Proceeds of Liberty Life Insurance Policy | (7) |  | 300 000.00 [1]  |
|  Shares in COWS (Pty) Ltd Sold For | (8) |  | 1 100 000.00 [1]  |
|  Investment at ABC Bank Account 4050635667 Capital | (9) |  | 200 000.00 [1]  |
|  Accrued interest to date of death | (10) |  | 25 000.00 [1]  |
|  **TOTAL ASSETS** |  |  | **5 200 000.00** [1]  |
|  **Liabilities:** |  |  |   |
|  Administration Costs: |  |  |   |
|  Advertising Debtors and Creditor [1] |  |  |   |
|  Government Gazette | (11) | 37.82 |   |
|  Pretoria News | (12) | 362.18 |   |
|  Advertising Account for Inspection [1] |  |  |   |
|  Government Gazette | (13) | 37.82 |   |
|  Pretoria News | (14) | 362.18 |   |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3