|  Property Deemed to be Property |  |   |
| --- | --- | --- |
|  Add: Proceeds of Liberty Life Insurance Policy |  | 300 0000.00 [1]  |
|  Proceeds of Old Mutual Policy: R1 100 000.00 [1] Less: Premiums paid plus 6% Interest: R100 000.00 [1] |  | 1 000 000.00  |
|  **Gross value of the estate** |  | **5 410 000.00**  |
|  **Deductions – Section 4** |  |   |
|  Costs of Administration and claims | 400 000.00 [1] |   |
|  Surviving spouse’s Inheritance: s4q | 4 800 000.00 [1] | 5 200 000.00  |
|  Net value of the estate |  | 210 000.00  |
|  Less Primary Rebate – Section 4A |  | 3 500 000.00 [1]  |
|  Dutiable Amount |  | 0.00 [1]  |
|  Estate Duty at 20% on R0.00 |  | 0.00  |

### Certificate

I the undersigned, Eva Venter, executrix in the estate of the late Piet Venter No. 1369/2020, hereby declare that the estate account is to the best of my knowledge and believe a true and proper account of the liquidation and distribution account of the estate [1], and that to the best of my knowledge and belief all the assets, income and expenditure after date of death are reflected. [1]

Signed at Pretoria on this 17$^{th}$ day of March 2021. [1]

Eva Venter

Executrix

LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

6