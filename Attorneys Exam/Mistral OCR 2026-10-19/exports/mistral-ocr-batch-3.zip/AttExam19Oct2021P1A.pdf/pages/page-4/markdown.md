7.3

In the High Court of South Africa
(Eastern Cape Local Division, Port Elizabeth) (1) case no. /2021

In the matter between: Peter Brown (Plaintiff)
Piet Botha (Defendant)

Defendant's Special Plea

1.

Defendant specially pleads that the above honourable court lacks jurisdiction to hear the matter as (1):

The Defendant resides outside the area of jurisdiction of the above honourable court / resides within the area of jurisdiction of the Eastern Cape Main Division, Makanda / Grahamstown and (1)

The cause of action arose outside the area of jurisdiction/arose in the area of jurisdiction of the Gauteng Division (1).

Wherefore Defendant prays that the Plaintiff's case be dismissed (1) with costs (1).

Note to examiner: Claim has not prescribed, amount only became due and payable on the 30th of April 2018.

QUESTION 8

[16]

8.1

(6)

IN THE REGIONAL COURT FOR THE DISTRICT OF PORT ELIZABETH HELD AT PORT ELIZABETH

In the matter between:

M ACCOUNTANT

APPELLANT

and

THE STATE

RESPONDENT

(1)

NOTICE OF APPEAL

BE PLEASED TO TAKE NOTICE THAT THE APPELLANT hereby notes an appeal to the Eastern Cape Division of the High Court of South Africa against the sentence imposed upon him by the Honourable Magistrate G Masimbi on the 15th day of March 2020. The Appellant hereby appeals on the following grounds: (1)

1. The Magistrate erred in not taking the personal circumstances into consideration. (1)
2. The Magistrate erred in not taking alternative forms of punishment into consideration. (1)
3. The Magistrate erred in over-emphasising the interests of the public above that of the appellant. (1)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

4