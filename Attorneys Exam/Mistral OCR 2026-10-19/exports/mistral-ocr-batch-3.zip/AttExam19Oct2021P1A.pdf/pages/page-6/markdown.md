### Correctional supervision:

Under Section 276 (h) for a period not exceeding three years. I would attempt to persuade the court that this is the punishment which should be considered. A probation officer or a correctional officer's report is to be obtained and requested in this regard and the matter will have to be postponed until such time as the report is available. In argument in support of this form of punishment, one can argue that: (2)

- (a) Correctional supervision is less intrusive than imprisonment and should be applied in cases where a fine is inappropriate;
- (b) The family life of the offender can continue;
- (c) A compulsory training and educational programme recommended by the probation officer can be very beneficial in developing the social skills of the offender;
- (d) The offender is not exposed to the negative influences of the prison sub-culture;
- (e) It is cost effective and involves the community in the punishment and rehabilitation;
- (f) The personal circumstances of the offender, including his family situation and employment, make it possible to maintain effective control and supervision of the offender;
- (g) The offender is willing to subject himself to correctional supervision. (5)

### Imprisonment in terms of Section 276 (i)

If it becomes clear that the court will impose imprisonment, then this alternative should be requested. (1)

*Any ten of the whole question will be marked correct.*

**Note to examiner:** The reasons for the various sentences are not exhaustive and students are at liberty to present other reasons.

## QUESTION 9

[9]

9.1 Section 7 of the CPA: In any case in which the National Prosecuting Authority declines to prosecute for an alleged offence-

- (a) any private person who proves some substantial and peculiar interest in the issue of the trial arising out of some injury which he individually suffered in consequence of the commission of the said offence;
- (b) a husband if the said offence was committed in respect of his wife;
- (c) the wife or child or, if there is no wife or child, any of the next of kin of any deceased person, if the death of such person is alleged to have been caused by the said offence, or
- (d) the legal guardian or curator of a minor lunatic, if the said offence was committed against his ward either in person or by legal representative, institute and conduct a prosecution in respect of such offence in any court competent to try that offence.
- (e) above is applicable in this instance. (3)

*Any three of the above will be marked correct.*

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6