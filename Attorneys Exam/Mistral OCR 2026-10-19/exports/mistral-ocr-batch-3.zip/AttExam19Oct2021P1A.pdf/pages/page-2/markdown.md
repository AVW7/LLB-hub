2.2 The driver is the person who, for purposes of the RAF Act, drives the vehicle (1) within the meaning of Section 17 of the Act (1).

### QUESTION 3

[5]

Factual questions to be answered to ascertain objectively whether a vehicle is a “motor vehicle:

- (a) Would the vehicle normally be expected to be seen on the road by the normal ordinary rational driver? (1)
- (b) Does the vehicle have headlights? (1)
- (c) Does it have brake lights? (1)
- (d) Does it have direction indicators? (1)
- (e) What is the maximum speed limit of the vehicle? (1)

Other factual questions would be:

- (a) Does the driver of the vehicle have an unobstructed view, e.g., forklifts? (*Chauke’s case*). (1)
- (b) Does the vehicle steer with the front wheels or back wheels? (*Chauke’s case*). (1)
- (c) Is the vehicle fitted with a speedometer? (1)
- (d) Does the vehicle have a hooter? (1)
- (e) What is the size of the tyres and does the size differ between the front and back wheels? (1)

*Choose any 5 of the above answers.*

### QUESTION 4

[4]

* Please note there was an error in Question 4 in the Afrikaans paper. The question referred to the defendant instead of the Plaintiff. An announcement was made to inform candidates of the correct version being the Plaintiff. The English question is correct.

Further note that the Afrikaans question as it stands cannot be answered as the RAF in accident claims is always the defendant.

In practice, if the Fund refuses to settle the merits formally and refuses to make any interim payment then the Plaintiff must:

- Serve summons in the High Court; (1)
- Apply to separate the issues of liability and *quantum* in terms of Rule 33 (4); (1)
- Obtain an order in the Plaintiff’s favour on liability; (1)
- Bring a formal application to Court in terms of Rule 34A for an interim payment. (1)

### QUESTION 5

[7]

- 5.1 Apply to court for an order that Plaintiff pays the costs of the action as well as costs of the application. (1)
- 5.2 Within 20 court days from the date of receiving of the notice of withdrawal. (1)
- 5.3 “Take note that application will be made on behalf of the above-named Applicant

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

2