Certificate of *nolle prosequi*:

No private prosecutor under this section shall obtain the process of any court for summoning any person to answer any charge unless such private prosecutor produces to the officer authorised by law to issue such process a certificate (1) signed by the National Director of the NPA or the Director of Public Prosecutions (DPP) (senior prosecutor) that he has seen the statements or affidavits on which the charge is based and that he declines to prosecute at the instance of the State (1).

The National Director of the NPA or the Director of Public Prosecutions (DPP) (senior prosecutor) shall, in any case in which he declines to prosecute, at the request of the person intending to prosecute, grant the certificate referred to above (1).

A certificate issued under this subsection shall lapse unless proceedings in respect of the offence in question are instituted by the issue of the process referred to in paragraph (a) within three months of the date of the certificate (1).

***Any six of the whole question will be marked correct.***

9.2 Section 12(2): Where the prosecution is instituted under section 7(1) and the accused pleads guilty to the charge, the prosecution shall be continued at the instance of the State (1).

**The National Director of the NPA** or the Director of Public Prosecutions (DPP) (senior prosecutor) **may intervene:**

The National Director of the NPA or the Director of Public Prosecutions (DPP) (senior prosecutor) may in respect of any private prosecution apply by motion to the court before which the private prosecution is pending to stop all further proceedings (1) in the case in order that a prosecution for the offence in question may be instituted or continued at the instance of the State, and the Court shall make such an order (1). (3)

**QUESTION 10** [4]

Mary is paying out R140 000 (2), i.e. R20 000 (2) more than her contract price.

**QUESTION 11** [6]

11.1 Notice to amend recording that if no objection is made the summons will be amended. (2)
11.2 Object in ten (10) days giving reasons. (2)
11.3 File the amended page. (2)

**QUESTION 12** [4]

12.1 Plaintiff must give 10 days' notice that he will be using the photographs. (2)
12.2 The photographer will have to be called (Award an extra mark if he points out Magistrate may penalise the Defendant with a costs order). (2)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7