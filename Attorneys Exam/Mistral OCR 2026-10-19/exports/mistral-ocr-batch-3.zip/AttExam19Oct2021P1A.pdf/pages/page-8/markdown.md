# **QUESTION 13**

**[7]**

In the Magistrate's Court:

13.1 Exception:
13.2 The clerk of the Court and;
13.3 Defendant's attorney;
13.4 Please take notice that Plaintiff excepts to the Defendant's plea in that it fails to disclose a defence;
13.5 Particulars;
13.6 The fact that apprentice does not have a licence does not excuse his negligence;
13.7 Prayer;
13.8 That this exception be upheld with costs.

*Any 7 for 1 mark each.*

# **QUESTION 14**

**[4]**

14.1 No, not included. (1)
14.2 Yes, included. (1)
14.3 Yes, included. (1)
14.4 Yes, included. (1)

![img-0.jpeg](img-0.jpeg)

**TOTAL: [100]**

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

8