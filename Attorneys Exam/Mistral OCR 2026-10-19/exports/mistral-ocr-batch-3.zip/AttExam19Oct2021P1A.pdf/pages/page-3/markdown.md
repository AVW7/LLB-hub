on (date) and (time) or as soon thereafter as Applicant's legal representative may be heard for an order in the following terms: (1)

- Plaintiff pays the costs of the withdrawn action (1)
- Plaintiff pays the costs of this application (1)

Further take note that the affidavit of (Applicant) will be used in support of the application. (1)

Kindly enroll the matter accordingly. (1)

## **QUESTION 6** [8]

6.1

1. Copy of the summons together with the documents on which the claim rests (½)
2. The copy of the return of service (½)
3. The original liquid document (½)
4. A copy of the Defendant's answering affidavit (½)
5. A copy of the Plaintiff's replying affidavit (½)
6. A copy of notice of set down (½)

6.2

1. Where the Defendant is in default with his Notice of intention to defend. (½)
2. Where the Defendant failed to plead after service on him/her of Notice of Bar. (½)
3. Where the Plaintiff failed to deliver a Declaration and was barred from doing so. (½)
4. Where the Plaintiff or Defendant failed to appear at the hearing. (½)

6.3 After the Defendant has filed a plea. (1)

6.4 - Plaintiff must prove that there is no *bona fide* defence and attach the plea.
- Plaintiff must identify any point of law relied upon, the facts upon which the Plaintiff's claim is based, and explain briefly why the defence pleaded does not raise any issue for trial. (2)

## **QUESTION 7** [10]

7.1 A special plea does not concern itself with the merits of the case but with some special defence or objection to Plaintiff's case (pleas that could postpone Plaintiff's case i.e. dilatory special pleas or pleas that could destroy Plaintiff's case i.e. special pleas in abatement). (1)

7.2 **NOTE TO MARKER** *Any six of the following (½ mark for each correct answer maximum marks 3)*

Arbitration
Lis Pendens
Prescription
Misjoinder/Non-joinder
Jurisdiction
Non locus standi in iudicio
Res judicata

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3