# ADMISSION EXAMINATION
COURT PROCEDURES
PART 1

19 OCTOBER 2021

MEMORANDUM

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

# QUESTION 1 [10]

1.1 6 November 2021. (½)

1.2 6 November 2023. (½)

1.3
1. RAF Form 1 (½)
2. With completed statutory medical report (½)
3. Section 19(f)(i) affidavit (1)
4. Power of Attorney (½)
5. Copy of Client's Identity Document (½)
6. Accident Report (½)
7. Hospital / clinical records (½)

1.4
1. Orthopedic surgeon (1)
2. Occupational therapist (1)
3. Neurosurgeon (1)
4. Industrial psychologist (1)
5. Actuary (1)
6. The following answers would also be correct: neurologist; neuropsychologist; plastic and reconstructive surgeon.

# QUESTION 2 [6]

2.1
1. Motor dealer in relation to unsold motor vehicles; (1)
2. Transporter of new vehicles from one place to another; (1)
3. Instalment sale purchaser (hire purchaser); and (1)
4. Lessee where the period of the lease exceeds 12 months. (1)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1