4. The Magistrate erred in not finding that there were substantial and compelling circumstances making it possible not to impose a minimum sentence. (1)
5. The sentence imposed induces a sense of shock. (1)
6. Etc, etc. (the candidates can provide additional relevant reasons/motivations and markers must use their discretion) (1)

Dated at Port Elizabeth on this 16th day of March 2020.

APPELLANT'S ATTORNEY
12 Graham Street
PORT ELIZABETH

TO: The Clerk of the Regional Court
PORT ELIZABETH

AND TO: Regional Magistrate G Masimbi (1)

(Any six will be marked correct)

8.2 (10)

In terms of Section 276 the relevant sentences which may be imposed are:

1. Imprisonment
2. Periodical imprisonment
3. A fine
4. Correctional supervision (Section 276(h))
5. Correctional supervision, that is imprisonment from which such a person may be placed under correctional supervision in his discretion by the Commissioner (Section 276 (i)). (3)

Any three would be correct for one mark.

Imprisonment:

Unsuitable as he will be removed from society, family and business will suffer, the effect of accused being criminalized in prison.

Remind the court of the general rule that first offenders are to be kept out of prison as far as possible (etc., etc.). (2)

Periodical imprisonment:

This should only be resorted to if the court finds it necessary and unavoidable to imprison the accused. The advantage will be that he will be able to continue with his business during the week and will serve a period of imprisonment over weekends. The disadvantage is that he will come into contact with criminals. (2)

A fine:

This should be seriously considered by the court and could be coupled with a period of imprisonment, alternatively a fine. The court can be addressed on the ability of the accused to pay the amount and requested to allow the accused to repay same by way of monthly instalments. (2)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5