ABC LOAN SPECIALISTS CC
CK 90/00492/23

("the creditor")

R200 000 (two hundred thousand Rand)
("the capital sum") (4)

In respect of monies lent and advanced to me by the creditor.

2. INSTALMENTS

2.1 I will pay the instalments:

2.1.1 in cash, free of deduction or set-off;
2.1.2 On the first day of each month, commencing in the month following that in which this acknowledgement is signed;
2.1.3 To the creditor at the address which it specifies in writing from time to time, being initially [state payment address].

2.2 If so required by the creditor, I shall arrange (at my own expense) for payments to be made by means of a stop or debit order. (4)

2. ADDITIONAL CHARGES (2)

The creditor may include in the principal debt or recover all amounts permitted by the National Credit Act, 2005, to be included or recovered if the creditor is authorised by written agreement to do so. Such charges are the following: [The consumer has a right to information in terms of the NCA and such charge amounts must be set out in the agreement. Be lenient.]

3. DEFAULT (8)

3.1 Should I fail to make payment on due date of any amount owing in terms of this acknowledgement, I will be liable for interest on that amount at the rate then payable on the capital sum in terms of 2.1.

3.2 If any of the following occurs:

3.2.1 I fail to make payment of any amount by due date;
3.2.2 I am sequestrated (provisionally or finally) or if I take steps to surrender my estate;
3.2.3 I make, or attempt to make, a compromise with any of my creditors;
3.2.4 Any of my property is attached in execution of a court judgment; the full balance outstanding (including interest) will immediately become due and payable and the creditor will be entitled, without prejudice to any other remedy he may have against me, to proceed immediately for recovery of the balance.

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

2