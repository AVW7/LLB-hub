# **ADMISSION EXAMINATION / TOELATINGSEKSAMEN  
ATTORNEYS' PRACTICE / PROKUREURSPRAKTYK  
PART 3 / DEEL 3**

**20 FEBRUARY / FEBRUARIE 2020**

**ANSWERS / ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY  
NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE  
MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

# **QUESTION 1** **[10]**

1.1 A body corporate gives continuity and sometimes protection against personal liability. It may be beneficial to avoid sequestration and has a better organised regulatory structure and may have tax flexibility. (5)

1.2 See Section 8 and definition of "non-profit company" in new Companies Act No. 71 of 2008. Types of company are:

1.2.1 Profit company, which can be either a
(a) State-owned company; or
(b) Private company;
(c) Personal liability company; or
(d) Public company.

1.2.2 Non-profit company, i.e. incorporated for a public benefit or other object (similar to old Section 21 Company). (5)

# **QUESTION 2** **[24]**

**Note: this precedent is what is taught to candidates in the Practice Manual to reflect "plain English"**

The agreement:

1. ACKNOWLEDGEMENT

I, the undersigned,

JOHN DOE

acknowledge that I owe

LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

1