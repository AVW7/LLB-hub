# **QUESTION 8**

**[5]**

Lewis (at 249) gives as an example a number of reasons as to when there is good cause for an attorney to withdraw:

- Improper conduct on the part of the client;
- The client's deliberate fraud;
- If the attorney finds that his own personality clashes with that of the client;
- Where the client does not accept his attorney's advice and persists or defending an action when his attorney most strongly advises settlement;
- The failure to provide funds to enable the attorney to continue will also justify his terminating the relationship;
- Also failure to give instructions;
- Illness of the attorney.

# **QUESTION 9**

**[5]**

Damage A

R100 000

50% thereof

R50 000

Damage B

R90 000

50% thereof

R45 000

Net award to A

R5 000

Costs awarded to A but probably on scale C.

**TOTAL: [100]**

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

5