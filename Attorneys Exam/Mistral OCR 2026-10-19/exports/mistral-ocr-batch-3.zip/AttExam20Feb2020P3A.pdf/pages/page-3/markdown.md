# 4. PROOF OF AMOUNT OF INDEBTEDNESS (2)

A certificate signed by a person identified in the certificate (or otherwise) as a member of the creditor will be proof, until the contrary is proved, of the amount then owing by me and the due date (dates) for payment.

# 5. LEGAL COSTS (4)

I will be liable for:

5.1 the legal costs (including any tax or duty) incidental to the negotiation, preparation, and signing, of this acknowledgement of debt;
5.2 any legal costs, including attorney and own client costs, incurred by the creditor in enforcing this acknowledgement of debt, except costs which the creditor incurred, or which were incurred on its behalf, before it gave instructions to institute proceedings.
5.3 Value Added Tax on the costs and collection commission.

[Date and place for debtor and witnesses to sign.]

[Magistrates' Court has jurisdiction into s 29 of the Magistrates' Court Act for enforcing the AOD.]

# **QUESTION 3** [5]

3.1 Included (1)
3.2 Included (1)
3.3 Excluded (1)
3.4 Excluded (1)
3.5 Included (1)

# **QUESTION 4** [17]

4.1 The small claims court; (1)
4.2 A High Court; (2)
4.3 The CCMA; (2)
4.4 The Pension Fund Adjudicator; (1)
4.5 The Master of the High Court who may appoint a magistrate; (2)
4.6 The Maintenance Court; (2)
4.7 The Law Society (Assessment Panel); (2)
4.8 The Attorneys Fidelity Fund and Law Society; (3)
4.9 Sue the attorney in the appropriate court. The attorney may approach the AIIF and his own indemnity insurers. (2)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

3