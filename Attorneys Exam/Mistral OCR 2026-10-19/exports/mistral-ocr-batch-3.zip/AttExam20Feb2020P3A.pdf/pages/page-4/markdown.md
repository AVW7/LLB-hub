## QUESTION 5

[5]

The magistrate must recuse herself. You must first inform her in chambers (1) that you will apply for recusal. If she declines, you apply in open court (1) if she still refuses you continue (i.e. no review/appeal) (1). If your client is acquitted, no harm done (1); if client is convicted you have grounds for review (1).

## QUESTION 6

[20]

### a) Stocktaking

On the take-over date the parties will do a stocktaking of the business in accordance with the following provisions:

- ○ Each party will be entitled to be present or represented at the stocktaking.
  - • The stock will be valued at the cost price thereof.
  - • After the stocktaking, a schedule reflecting the stock and its value will be prepared and signed by the parties.
  - • Any stock which is damaged or is unsaleable will be excluded for the purpose of valuing the stock unless the parties agree in writing as to its value.
  - • If there is a dispute as to whether any stock is damaged or unsaleable the Seller will retain ownership therein and this stock shall also be excluded for the purposes of valuing the stock.
- ○ The parties agree that the value of the stock as reflected in the said schedule shall be final and binding upon them. (8)

### b) Restraint of trade

The Seller, in order to protect the goodwill of the business and the interest of the Purchaser in such goodwill, agrees and undertakes in favour of the Purchaser that he will not, within a radius of 50 km from the premises in which the business is conducted, and for a period of three years after the take-over date, either as principal, agent, partner, shareholder, director, employee, or in any similar capacity, directly or indirectly be associated with or engaged in any firm, business, or company which carries on a business the same as, or similar to the business sold or in any new but similar business. The Seller agrees that the restraints imposed by this clause are necessary to protect the Purchaser and are reasonable both as to area and duration. Each of the restraints constitutes a separate and independent restraint several from others. (12)

## QUESTION 7

[9]

The claim is "extinguished" and becomes unenforceable (1). Payments may validly be received (1) but a summons is open to a special plea (1). You advise client to seek independent advice (1) but do not admit liability (1); inform the AIIF and your own insurers (1) of any claims; pay the excess deductible (1). You need not inform the Law Society (1) but must respond to any complaints (1).

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

4