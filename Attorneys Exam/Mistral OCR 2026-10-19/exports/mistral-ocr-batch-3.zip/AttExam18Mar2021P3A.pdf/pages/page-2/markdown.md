1.3 Improvements / alterations

The tenant shall not make any structural alterations or additions to the premises without the landlord's consent, which shall not be unreasonably withheld. (1)

Any alterations or additions made with the landlord's consent must be carried out by the tenant:

- at its own cost; (1)
- should the landlord so require, under the supervision of an architect (approved by the landlord) whose fee the tenant shall pay, and (1)
- in accordance with any other reasonable conditions and requirements stipulated by the landlord. (1)

a) The Tenant shall, if required to do so by the Landlord in writing within 30 (thirty) days after that expiration or termination, remove that alteration or addition and reinstate the Lease Premises (or part of the Leased Premises in question) at the Tenant's cost, to its same condition prior to the carrying out of that alteration or addition; (2)

b) If the Landlord does not exercise the rights in terms of clause 1.3 (a), those additions or alterations shall not be removed by the Tenant but shall become the Landlord's property and no compensation therefor shall be paid by the Landlord; (2)

QUESTION 2

[9]

The sale of the trading business is affected by:

2.1 The L.R.A which provides in S197 that the purchaser in all respects steps into the shoes of the seller qua employer and is bound by all the obligations of the seller to the employees. (3)

2.2 The Insolvency Act (S34) provides that the sale must be advertised 30 days in advance failing which the sale will be void as against creditors and the trustee in case of insolvency of the Seller. (3)

2.3 The VAT Act provides that if both parties are registered vendors the transaction will be zero-rated for VAT provided certain requirements are met. (3)

QUESTION 3

[10]

DEED OF SURETYSHIP

I, the undersigned

Joe Soap

Identity number:

Married in community of property (1)

of ... (address)

do hereby interpose and bind myself to and in favour of: (1)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2