They are bound to market both their practices and businesses within the confines of the Legal Practice Rules and the LP Act (1). Furthermore, they cannot conduct a copying business under the name and style of the practising attorney, as this is in contravention of the applicable legislation, and not allowed (1).

*Guideline - to test the candidates' ability to differentiate between touting and running more than a practice as an attorney from an attorney's practice. Reference to specific parts of the Act and Rules is not necessary but the explanation from the ethical point of view relating to attorneys is.*

# **QUESTION 7**

**[2]**

All four actions are permissible.

![img-0.jpeg](img-0.jpeg)

**TOTAL: [100]**

LAW SOCIETY OF SOUTH AFRICA

---*LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™*

6