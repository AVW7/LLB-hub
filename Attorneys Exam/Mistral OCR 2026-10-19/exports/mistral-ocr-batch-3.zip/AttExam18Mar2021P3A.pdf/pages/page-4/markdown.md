The Master will require (give credit for a maximum of 6 of the following):

5.3.1 The Trust deed in duplicate (1)
5.3.2 The prescribed fee (1)
5.3.3 Security by the trustee or exemption by the Master (1)
5.3.4 Acceptance of Trust by the trustee (1)
5.3.5 Consent to act of an Auditor (1)
5.3.6 Name of the Bank where the Trust will operate its account (1)
5.3.7 Name and address of person who will keep the records of the Trust (1)
5.3.8 Occupation of the Trustee (1)
5.3.9 Experience of Trustees, as such (1)
5.3.10 If exemption is asked for the Master may have further requirements. (1)

# **QUESTION 6** [6]

The Prescription Act provides that the claim is extinguished (1). This means that while the claim cannot be enforced it does remain a natural obligation (1). The claim can therefore be resisted in litigation by way of a special plea (1). However, if the debtor pays on receipt of a demand or summons the amount may validly be accepted (1). If the special plea is not raised, the presiding officer may not raise it *mero motu* (1). The practical approach is to sue and withdraw if the special plea is raised (1).

# **SECTION B**

# **QUESTION 1** [9]

Having satisfied him/herself of the identity of the deponent (1) the commissioner of oaths must ask the deponent whether he/she knows and understand the contents of the affidavit (1), must ask the deponent whether he/she has any objection to taking the prescribed oath (1), must ask the deponent whether he/she regards the oath as binding on his/her conscience (1). If the deponent has an objection to taking the oath, he/she may make a solemn declaration (1). The affidavit or solemn declaration is then signed in the presence of the commissioner of oaths, who also signs it (1). A certificate must be added to the bottom of the document, confirming that the document was signed and attested to before him/her (1). The affidavit must contain the full names, physical address and authority of the commissioner of oaths (2).

# **QUESTION 2** [9]

2.1 Small Claims court (1)
2.2 The High Court (1)
2.3 The Compensation Commissioner and Road Accident Fund (2)
2.4 The High Court (Rule 43) or Regional Court (2)
2.5 Magistrate's Court (1)
2.6 CIPC (1)
2.7 Magistrate's Court (1)

# **QUESTION 3** [5]

A private for profit company is registered –

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

4