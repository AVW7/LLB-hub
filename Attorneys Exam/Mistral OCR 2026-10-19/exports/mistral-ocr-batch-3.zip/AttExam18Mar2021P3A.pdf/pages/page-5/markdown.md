• in terms of Act 70/2008 (1)
• by one or more person (S.13 (1)) (1)
• completing and signing a notice of incorporation (S13, Rule 14) in prescribed form (COR 14.1) (1)
• lodging it with CIPC (1)
• together with a memorandum of incorporation (S 13(2)(b) Rule 15) (1)
• in the form of forms (COR 15IA OR 151B or any unique form in compliance with S15). (1)

**Any five (5) answers would suffice.**

**QUESTION 4** [4]

The benefits of conducting a business in corporate form rather than as a sole proprietor or partnership, are:

4.1 Continuity (survives death of individual); (1)
4.2 Avoiding personal liability; (1)
4.3 A sound regulatory and governance system; (1)
4.4 Possible tax benefit. (1)

**QUESTION 5** [6]

A person who believes (usually has been informed) that his attorney has allowed his claim to prescribe should be advised to:

5.1 Terminate the mandate, collect his file from the negligent attorney to have his position assessed by the new attorney; (1)
5.2 Instruct his new attorney to send a letter of demand to the previous attorney; (1)
5.3 Inform the Legal Practice Council in his region of the claim; (1)
5.4 Await an approach from the attorneys for the LP Insurance Indemnity Fund who are likely to seek a settlement; (1)
5.5 If there is undue delay issue summons against the negligent attorney for damages; (1)
5.6 Consider any offers of payment or settlement from either the attorney himself or the LPIIF, taking into account any contributory negligence. (1)

**QUESTION 6** [5]

The court has held that lawyers serve society and that allowing them to advertise their services would provide consumers with valuable information about available legal assistance (1). After certain landmark cases, attorneys could advertise to obtain clients (1). They cannot, under their logo and brand names, advertise themselves in a way that transgresses the rules governing touting (1).

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

5