# **ADMISSION EXAMINATION  
ATTORNEYS' PRACTICE  
PART 3**

**18 MARCH 2021**

**MEMORANDUM**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

# **SECTION A**

# **QUESTION 1** **[17]**

1.1 Option to Extend  
The lessor gives the lessee an option to extend the lease for a further period of three years on condition that: (1)1.1.1 a written notice of such exercising of the option reaches the lessor not later than three months before the termination of the lease period; (1)1.1.2 the rental as prescribed in the lease agreement is increased by 10% in regard to every year of such extended lease period starting on the date when the extended lease period comes into operation; (1)1.1.3 all the remaining provisions of the lease contract save the right to extend remain applicable to such extended lease period; (1)1.1.4 this option is granted on the express condition that the lessee strictly and faithfully complies with the provisions of the contract. (1)1.2 Subletting, cession and assignment  
The tenant shall not, without the prior written consent of the lessor (which shall not unreasonably withhold consent):1.2.1 sublet the premises or any part thereof; (1)1.2.2 allow any other party to occupy the premises or any part thereof on any conditions or for any reason; (1)1.2.3 assign the lease or cede any of its rights under this lease; (1)1.2.4 transfer a controlling interest in the lessee if it is a juristic person. (1)

---*LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

1