Mrs. A.
("the Creditor")

as surety and co-principal Debtor in solidum with (2)

XYZ (Pty) Ltd
Reg no.: ...(1)
("the Debtor")

renouncing the benefits of the *exceptiones excussionis* and *cedendarum actionum* (1)
for the due and timeous fulfilment by the Debtor of all its obligations (1) in terms of or
arising out of a deed of sale of a business (1) between the Creditor and Debtor and for
the payment of all amounts owing by the Debtor to the Creditor in terms thereof. (1)

Thus done and signed...

CONSENT

I, the undersigned, Mary Soap, ID no: ... (1) being married to the surety in community
of property (1) herewith consent that Joe Soap enters into the above suretyship (1).

This consent is given in terms of section 15(2) of the Matrimonial Property Act (1).

Thus done and signed...

(maximum 10 marks)

QUESTION 4

[6]

4.1 Benefit of excussion (*beneficium excussionis*)
Where the surety may claim that the debt must as far as possible be recovered
from the principal debtor before he himself is sued. (2)
4.2 Benefit of division (*beneficium divisionis*)
It means that where there is more than one surety, the one who is sued may
claim that the debt be divided between all the sureties so that he is only liable for
his proportionate share. (2)
4.3 Benefit of cession of actions (*Beneficium cedendarum actionum*)
Where a surety may in fact refuse to pay unless the creditor cedes to him all
actions which the latter may have against the principal debtor and other sureties.
(2)

QUESTION 5

[12]

5.1 An *inter vivos* trust is created by the founder executing a trust deed before a
notary public. (2)
5.2 The trust deed should identify the founder, the trustees and the beneficiaries (in
respect of income and capital). (3)
5.3 A trust must be registered with the Master of the High Court in the area where
the founder resides. (1)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3