# **ADMISSION EXAMINATION**
**COURT PROCEDURES**
**PART 1**

**4 NOVEMBER 2020**

**MEMORANDUM**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

# **QUESTION 1**

**[10]**

In terms of section 1 of the Road Accident Fund Act, 1996 (the "RAF Act") a motor vehicle is defined as "any vehicle designed or adapted for propulsion or haulage on a road by means of fuel, gas or electricity, including a trailer, a caravan, an agricultural or any other implement designed or adapted to be drawn by such motor vehicle."

The definition identifies three requirements for a vehicle to be classified as a motor vehicle under the Act. The vehicle must be:

1. propelled by fuel, electricity, or gas; (1)
2. designed for propulsion; (1)
3. capable of being driven or operated on a road (1)

The reach stacker in question was equipped with full road going lighting, including taillights, indicators, brake lights and reverse lights. Furthermore, it was fitted with windscreen wipers and washers, a hooter, and a handbrake. The requirements set out in the definition of the RAF Act have been met. The reach stacker was designed and equipped to be propelled around the port along roads and over parking and storage spaces. (4)

In **Road Accident Fund v Mbele** (where a pedestrian who was employed as a stevedore at a multipurpose terminal died as a result of injuries sustained when a reach stacker collided into him) the Supreme Court of Appeal the court considered this very issue and was satisfied that the reach stacker could be classified as a motor vehicle having regard to the definition in the RAF Act. The RAF's liability was thus extended to include reach stackers as defined as a "motor vehicle" in section 1 of the RAF Act (3)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

1