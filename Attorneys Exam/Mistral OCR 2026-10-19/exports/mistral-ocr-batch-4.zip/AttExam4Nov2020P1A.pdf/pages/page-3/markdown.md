(iii) I caused a copy of the notices to be affixed to a notice board inside my business premises and to which my employees have access **OR** I caused a copy of the notices to be affixed to the front gate of my business premises **OR** I caused a copy of the notices to be affixed to the front door of the premises from which I conducted my business immediately prior to the bringing this Application (1).

I annex, marked “**C**” an Affidavit by __________ confirming that this notice was given in the manner described (1/2).

(iv) I caused a copy of the notices to be posted to the South African Revenue Service (1) I annex, marked “**D**” proof of postage (1/2).
(v) My statement of affairs (Annexure “**A1**” lay for inspection at the office of the Master in Bloemfontein (1) and the office of the magistrate of the district of Mangaung (1) for a period of fourteen (14) days as from __________ being the date mentioned in the notice of surrender. I annex certificates from the Master and Magistrate, marked “**E**” and “**F**” respectively (1).

# **QUESTION 6** [4]

1. Maintenance pendente lite. (1)
2. a contribution towards the costs of a pending matrimonial action (1)
3. interim care of any child (1)
4. interim contact with any child (1)

# **QUESTION 7** [6]

**Any six(6) of the following:**

- The date, place and duration of the conference and the names of the parties present (1)
- The nature of prejudice and non-compliance if any (1)
- That every party claiming relief has requested such party’s opponent to make a settlement proposal and that such opponent has reacted thereto (1)
- Whether any issue has been referred by the parties for mediation, arbitration or decision by third party (1)
- Whether the case should be transferred to another court (1)
- Which issues should be decided separately (1)
- Admission made by each party (1)
- Any dispute regarding the onus of proof or duty to begin (1)
- Which documents will, without further evidence, serve as evidence of what they purport to be. (1)
- Which party shall be responsible for the copying and preparation of documents. (1)

# **QUESTION 8** [2]

You approach the prosecutor (1) and request him/her to accompany you to the Magistrate and to introduce you to him/her (1).

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3