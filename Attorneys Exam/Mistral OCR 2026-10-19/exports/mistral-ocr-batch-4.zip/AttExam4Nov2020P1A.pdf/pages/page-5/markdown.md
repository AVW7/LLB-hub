THE STATE (1/2)

vs

THABO SEEKOEI (1/2)

ACCUSED

# STATEMENT IN TERMS OF SECTION 112(2) OF ACT 51 OF 1977, AS AMENDED

1. I admit that I am the above-mentioned accused. (1mark)
2. I admit making this statement voluntarily whilst at my sober senses without any unduly influence. (1mark)
3. I admit that the contents of the charge sheet are correct and wish to plead guilty on the alternative charge. (1mark)
4. The incident happened on the 10th April 2020 along a public road namely Church Street, Bloemfontein in the Court's jurisdiction. (1mark)
5. I admit that I was the driver of the BMW motor vehicle with registration letters and number HBH 483 FS. (1mark)
6. I admit that my blood was drawn, stored, dispatched and analysed in accordance with the statutory prescripts. (1mark)
7. I admit that the results of the blood alcohol test were 0.15 gram per 100 ml, which is more than the statutory maximum of 0.05 gram per 100 ml. (The laboratory report is attached as Annexure "A") (1mark)
8. I admit that I knew that I should not have driven but that I proceeded doing so. I was aware of what I was doing and that it was against the law. (1mark)

SIGNED at BLOEMFONTEIN this day of DECEMBER 2020.(1/2mark)

T SEEKOEI (1/2mark)

# QUESTION 13

[7]

1. Plaintiff is the owner of a motor vehicle being a 2010 Toyota sedan registration number ND 123.
2. Defendant is in possession of the vehicle.
3. Alternatively, if defendant is not in possession of the vehicle, she disposed of it while was aware of Plaintiffs ownership of the vehicle.

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5