# **QUESTION 9**

**[5]**

9.1 Obtain a letter from the doctor/hospital where the client is being treated which can confirm it. (1)
9.2 Show the letter to the prosecutor. (1)
9.3 Request the Magistrate to receive the letter. (1)
9.4 Request the Court to issue a warrant but the execution to be held over until a future date. (1)
9.5 Postpone the case to a next date. (1)

# **QUESTION 10**

**[2]**

Convey to the Court that your instructions are that your client is in hospital. (1)

Inform the Court that the doctor or hospital's letter will be available at the next Court appearance. (1)

# **QUESTION 11**

**[5]**

11.1 The likelihood that the accused will try to evade his trial. (1)
11.2 The likelihood that the accused will try to influence and/or intimidate the potential state witnesses or conceal/destroy evidence. (1)
11.3 The likelihood that the accused will undermine or jeopardise the objectives of the proper functioning of the criminal justice system, including the bail system. (1)
11.4 The likelihood that the accused will endanger the safety of the public and/or any particular person or will commit a schedule 1 offence. (1)
11.5 The likelihood that in exceptional circumstances, the release of the accused will disturb the public order or undermine public peace or security. (1)

# **QUESTION 12**

**[11]**

IN THE MAGISTRATES' COURT FOR THE DISTRICT OF BLOEMFONTEIN
HELD AT BLOEMFONTEIN (½)

Case number: 123/10 (½)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4