## QUESTION 2

[10]

The Road Accident Fund provides compensation for:

- medical expenses (1) that result from a motor vehicle accident (1)
- funeral expenses (1) in the case of a death caused by an accident (1)
- general damages for pain and suffering (1), provided you suffered a serious injury (as determined with reference to set criteria), have lost an unborn child or have sustained serious disfigurement, mental impairment or the loss of a bodily function (1)
- lost earnings (1), if you were unable to work as a result of an accident (1)
- loss of support (1), if a household's main income provider was killed in a road accident that resulted from someone else's negligence (1).

## QUESTION 3

[4]

The Defendant is the Road Accident Fund (1), a juristic person (1) created in terms of The Road Accident Fund Act, Act 56 of 1996 as amended (1), (hereinafter referred to as "the Act"), with the legal capacity to institute and defend legal action, with its main place of business at 38 Ida Street, Menlo Park, Tshwane, Gauteng (1).

## QUESTION 4

[1]

No (1)

(Fund v Mothupi [2000] 3 All SA 181 (SCA), 2000 (4) 38 (SCA))

## QUESTION 5

[15]

5.1 (i) That the surrender of the Applicant's estate is accepted (1).
(ii) That further or alternative relief is granted to the Applicant (1).

5.2 (i) The debtor's estate is, in fact, insolvent (1).
(ii) The debtor owns realisable property of sufficient value to defray all costs of the sequestration which will, in terms of the Act, be payable out of the free residue of his estate (1).
(iii) Sequestration will be to the advantage of creditors (1).
(iv) All formalities as required in the Insolvency Act have been complied with (1).

5.3 (i) I caused copies of the notices to be posted to every one of my creditors whose address I know or have been able to ascertain (1)
I annex, marked "A" proof of postage (1/2)

(ii) I caused a copy of the notices to be posted to _______________
which is the registered trade union that, to my knowledge, represents my employees (1) I annex, marked "B" proof of postage. (1/2)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2