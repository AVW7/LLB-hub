4. The value of the vehicle is R200 000.00

5. Despite demand Defendant refuses to give possession of the vehicle to the Plaintiff. Wherefore Plaintiff prays judgment for

(a) return to the Plaintiff of the vehicle alternatively
(b) payment of the sum of R200 000.00
(c) interest a temporae morae

# **QUESTION 14**

**[10]**

14.1 Direct the Sheriff serve the warrant at defendants domicilium executandi i.e. at 100 Broad street. (2)

14.2 The prescription period for a dishonoured cheque is six years after presentation. Yes. (2)

14.3 There is no allegation that the employee was driving in the course and scope of his employment. No. (2)

14.4 The reduction in your claim comes off the amount abandoned. Judgment for R360 000. (2)

14.5 Interpleader. (2)

# **QUESTION 15**

**[8]**

15.1 The errors are as follow:

- The plaintiff's full name, gender, occupation and his residential address or his place of business
- An unassisted minor cannot be sued – no allegation that he was emancipated or assisted.
- No allegation that Plaintiff owns the vehicle he was driving.
- Repair costs not stated to be fair and reasonable and no indication of the pre-accident value of vehicle.
- Interest rate wrong – interest calculated from incorrect date
- Costs on ordinary scale – no reason to justify attorney-and-client scale (5)

15.2 The expert witness must testify on:

(a) his occupation
(b) his expertise (experience)
(c) he inspected the items
(d) his opinion of the value (3)

**TOTAL: [100]**

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6