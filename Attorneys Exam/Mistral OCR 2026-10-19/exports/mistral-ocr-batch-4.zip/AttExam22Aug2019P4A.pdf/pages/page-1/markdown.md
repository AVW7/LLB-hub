# **ADMISSION EXAMINATION / TOELATING SEKSAMEN**
**LEGAL PRACTITIONERS' BOOKKEEPING /**
**REGSPRAKTISYNSBOEKHOU**
**PART 4 / DEEL 4**

**22 AUGUST / AUGUSTUS 2019**

**ANSWERS/ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

**QUESTION 1**

**[15]**

**Supplementary Cash Book for February 2019✓**

|  Balance | 211 000✓ | Incorrect deposit | 1 238✓  |
| --- | --- | --- | --- |
|  Direct deposit | 150 000✓ | Debit order | 26 920✓  |
|  Correct deposit | 1 283✓ | Bank Charges | 1 200✓  |
|   |  | Balance | 332 925✓  |
|   | 362 283 |  | 362 283✓  |

**Bank reconciliation statement as at 28 February 2019✓**

Balance as per cash book 332 925✓

Less: Outstanding deposits 60 000✓

**LAW SOCIETY OF SOUTH AFRICA**
**LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™**

1