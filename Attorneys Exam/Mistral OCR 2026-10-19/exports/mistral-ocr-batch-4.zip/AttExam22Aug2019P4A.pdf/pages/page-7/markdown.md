Which fee Reference
Indicate Trust monies
Cash or EFT

(8)

3.3.1 Business Account (2)
3.3.2 Trust Account (2)
3.3.3 Account for both payments to your client. Prepare an accounting statement setting out the amounts received, amounts due in respect of fees and disbursements and the EFT to client (5)
3.4 Trust Reconciliation is a list of ALL the Trust Creditors balances in your Trust Ledger reconciled with the balance in your Trust Cash Book and the Trust Investments in terms of Section 86(3) and Section 86 (4). (6)

TOTAL: [100]

![img-0.jpeg](img-0.jpeg)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

7