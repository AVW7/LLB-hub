# ACCOUNT TO SIPHO

# Collection Matter

Fee letter of Demand 345

Credit Debtor 50 000

Collection Commission 2 300

# Sale of Property

Purchase Price 7 500 000

Paid You 7 500 000

# Registration of Company

By cover You 50 000

Paid Agents 20 000

Fees 23 000

EFT herewith 54 355

7 600 000 7 600 000

3 marks

# QUESTION 3 [25]

3.1 Your annual fee income exceeds R1m (2)

3.2 Pre numbered

Duplicate

Nature of Receipt

Amount in words and figures

From whom received

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6