# Being fee letter of demand

|  Sipho | Dr | 23 000 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 20 000  |
|  Vat | Cr |  | 3 000  |

# Being fees for Registration of transfer

|  Black | Dr | 115 000 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 100 000  |
|  Vat | Cr |  | 150 000  |

# Being fees in property sale

# TRUST LEDGER

# S86 (4) ABSA – ITF BLACK

|  Cash | 1 500 000 | Cash | 1 700 000  |
| --- | --- | --- | --- |
|  Cash | 10 000 |  |   |
|  Cash | 190 000 |  |   |

# BUSINESS LEDGER

|  BLACK  |   |   |
| --- | --- | --- |
|  Fees | 115 000 | Transfer  |
|   |  | 115 000  |
|   |  | (1 mark each)  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5