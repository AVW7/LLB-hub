Subtotal

272 925✓

Less: bank error

12 878✓

Balance as per bank statement

260 047✓

# QUESTION 2

[60]

TRUST CASH BOOK

|  Sipho (D) | 50 000 | ABSA | 1 500 000  |
| --- | --- | --- | --- |
|  Black | 1 500 000 | SARS | 300 000  |
|  Black | 415 000 | Agent | 20 000  |
|  Sipho | 50 000 | Sipho | 7 500 000  |
|  ABSA | 1 700 000 | Fidelity Fund | 10 000  |
|  Nedbank | 6 000 000 | Black | 190 000  |
|   |  | Transfer | 115 000  |
|   |  | Transfer | 25 645  |
|   |  | Sipho | 54 345  |
|   |  | Balance |   |

BUSINESS CASH BOOK

|  Transfer | 115 000  |
| --- | --- |
|  Transfer | 25 645  |

½ mark each

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2