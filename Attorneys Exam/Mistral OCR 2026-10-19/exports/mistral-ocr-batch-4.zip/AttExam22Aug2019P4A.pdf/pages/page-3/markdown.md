|  **TRUST LEDGER**  |   |   |   |
| --- | --- | --- | --- |
|  SIPHO  |   |   |   |
|  Cash | 20 000 | Cash Debtor | 50 000  |
|  Transfer | 25 645 | Cash Debtor | 50 000  |
|  Cash | 54 345 |  |   |
|   | 100 000 |  | 100 000  |
|  **BUSINESS LEDGER**  |   |   |   |
|  SIPHO  |   |   |   |
|  Fees | 2 300 | Transfer | 25 645  |
|  Fees | 345 |  |   |
|  Fees | 23 000 |  |   |
|  **TRUST LEDGER**  |   |   |   |
|  BLACK  |   |   |   |
|  Cash | 300 000 | Cash | 1 500 000  |
|  Cash | 7 500 000 | Cash | 415 000  |
|  Transfer | 115 000 | Cash | 6 000 000  |
|   | 7 915 000 |  | 7 915 000  |

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3