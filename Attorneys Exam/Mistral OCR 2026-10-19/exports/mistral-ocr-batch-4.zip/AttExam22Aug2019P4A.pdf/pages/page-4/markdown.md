|  FEES  |   |   |
| --- | --- | --- |
|   | Sipho | 2 000  |
|   | Sipho | 300  |
|   | Sipho | 20 000  |
|   | Black | 100 000  |
|  VAT  |   |   |
|   | Sipho | 300  |
|   | Sipho | 45  |
|   | Sipho | 3 000  |
|   | Black | 15000  |
|  Fee Journal  |   |   |
|  Sipho | Dr | 2 300  |
|  Fee | Cr | 2000  |
|  Vat | Cr | 300  |
|  Being Collection Commission  |   |   |
|  Sipho | Dr | 345  |
|  Fee | Cr | 300  |
|  Vat | Cr | 45  |

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4