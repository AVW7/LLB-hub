QUESTION 11

[8]

The introduction of FICA impinges upon the traditional role and independence of the attorneys' profession and upon the confidentiality of all communications between attorneys and their clients. Apart from having the duty to establish and verify the identity of clients and of their authority, they are obliged to keep detailed records of clients, business relationships and of transactions for a specified period; they are also under an obligation:

1. to make such records available to the Financial Intelligence Centre on the strength of a warrant;
2. to inform the centre on request of the existence of a current or past mandate;
3. to report cash transactions above a prescribed amount to the Centre; and
4. to report to the Centre the conveyancer in terms of a transaction with a client of cash above a prescribed amount to or through a specified account or institution.

QUESTION 12

[8]

Dear X

On discovering that the claim of A had prescribed due to our negligence, I called A in and informed him of the position. While not admitting liability I advised him to consult another attorney to assert his rights. As you know we cannot continue to act in this matter (e.g. by taking the chance that the defendant will not raise a plea of prescription).

The client will no doubt get his new attorney to send us a letter of demand which I shall pass on to the Attorney Indemnity Fund. We are covered for amounts in excess of R200 000-00 and should be out of pocket in the worst case by no more than the excess payment of R20 000-00. I understand that the AIIF normally instructs their own attorneys to handle the matter and either to defend or settle same as they may be advised in consultation with us.

TOTAL: [100]

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6