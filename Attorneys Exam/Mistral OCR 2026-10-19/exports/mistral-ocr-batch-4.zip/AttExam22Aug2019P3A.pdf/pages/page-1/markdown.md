# **ADMISSION EXAMINATION / TOELATINGSEKSAMEN**
**ATTORNEYS' PRACTICE / PROKUREURSPRAKTYK**
**PART 3 / DEEL 3**

**22 AUGUST / AUGUSTUS 2019**

**ANSWERS / ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

**QUESTION 1**

**[6]**

She should make use of the provisions of Rule 43 (High Court) to apply for:

- a. Interim maintenance for herself and children;
- b. A contribution to costs;
- c. Interim custody;
- d. Access, if applicable.

The rule limits the costs and the order is not appealable.

**QUESTION 2**

**[5]**

Section 197: (any 5 of the following)

- a. The purchaser is automatically substituted in the place of the old employer;
- b. This can only be avoided by a written agreement;
- c. All rights and obligations that existed at time of transfer continue in force;
- d. Anything done by the old employer is considered to have been done by the new employer;
- e. Any new terms and conditions (e.g. pensions) must be no less favourable than before;
- f. Dismissal by reason of transfer is automatically unfair;

Old employer remains jointly liable for any claims arising from dismissal within 12 months for operations reasons.

**QUESTION 3**

**[4]**

The requirements for an interim interdict are:

- a. A prima facie right;
- b. Irreparable harm;

**LAW SOCIETY OF SOUTH AFRICA**
**LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]**™

1