1.8.1 Shall be final and binding upon them; (1)
1.8.2 Will be carried into effect: (1)
1.8.3 May be made an order of court of the country to whose jurisdiction such Party to the dispute may be subject. (1)
1.9 The provisions of this clause constitute the irrevocable consent of the Parties to the arbitration proceedings in terms hereof and none of the Parties shall be entitled to withdraw therefrom or to claim at any such arbitration proceedings that it is not bound by the provisions of this clause." (1)

[Also note that consumer legislation such as the Rental Housing Act, 1999, the NCA, and the CPA introduces consumer tribunals and other ADR for which may also be made use of in such clauses. One must just be careful to read the various applicable statutes as there are limitations. (For example, the Rental Housing Tribunal does not have jurisdiction to evict tenants).]

# QUESTION 10

[15]

10.1 • The seller and purchaser will do a stock taking together at close of business on the day preceding the effective date. All items which, for whatever reason are not marketable, will be excluded from the purchase except if the parties agree otherwise.
• The seller's statements of account and invoices for stock will serve as proof of the cost price thereof.
• If the seller cannot provide adequate proof of the cost price of any item, it will be referred to the supplier thereof for a determination and his determination will be binding on the parties.
• The parties will reduce the cost price of the stock to writing and will sign the document.
• The parties will take all reasonable steps and cooperate fully with each other to complete the stock taking and to calculate the stock taking and to calculate the cost price thereof before the effective date. (5)
10.2 The seller will not for a period of three years, calculated from the effective date, operate a business or have an interest direct or indirect in any restaurant business in the Magistrates District of Kuruman. The seller agrees that this restriction is fair and reasonable having regard to the nature of the business purchased, the duration thereof and the area to which it applies. (5)
10.3 I will advise the client to place an advert in the newspaper circulating in the area where the business is conducted in order to protect him against claims from creditors. Section 34 of the Insolvency Act makes provision for the advert. An omission to advertise could prejudice the purchaser in case the seller is sequestrated. (5)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

5