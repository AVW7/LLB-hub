7.4.2 Yes, as it guarantees an instalment sale which is a credit transaction in terms of s8(4)(c) NCA. (½)

# **QUESTION 8**

**[11]**

***Note: too many examples indicate lack of understanding or of drafting ability***

8.1 A person who displays the characteristics of honesty, integrity and reliability; (1)
8.2 Anything which is likely to affect your judgment adversely in advising or representing your client; (1)
8.3 Overreaching is abusing the ignorance of another in recovering excessive amounts from clients or debtors containing an element of impropriety; (1)
8.4 Documents on which the attorney has bestowed skill and labour; (1)
8.5 The Fund was established to reimburse members of the public who have suffered financial loss through the theft by an attorney, his employee or candidate attorney of funds or goods entrusted to that attorney; (2)
8.6 It is a rule of evidence that an attorney may not disclose to the Court without the consent of the client information given to him for purpose of legal advice or representation. (2)
8.7 Lack of expertise/qualification/experience (1); danger of a conflict of interest (1); mandate to do or assist in the doing of something illegal or improper. (1)

# **QUESTION 9**

**[20]**

# **ARBITRATION**

Any dispute, difference, impasse, or deadlock between the parties pursuant to this agreement must be referred to arbitration in terms of the rules and regulations of the Arbitration Foundation of South Africa ("AFS").

Please note that arbitrations before AFSA are not mandatory, and parties may choose a different form of arbitration, where the clause appears as follows:

"1 Arbitration

1.1 should any dispute arise between the Parties in regard to:

1.1.1 the interpretation of;
1.1.2 the carrying into effect of; or
1.1.3 the Parties' respective rights and obligations in terms hereof; or
1.1.4 the rectification of; or
1.1.5 the termination or arising out of the termination of; or
1.1.6 any question as to whether a valid and binding agreement was concluded between the Parties or whether such agreement is of legal force or effect; or
1.1.7 any other matter whatsoever emanating from this Agreement; (3)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3