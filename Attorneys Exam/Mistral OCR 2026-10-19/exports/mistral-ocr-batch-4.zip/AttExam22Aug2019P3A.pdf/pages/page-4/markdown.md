that dispute shall be submitted to and finally settled by arbitration. (1)

1.2 Any Party to this Agreement may demand that a dispute be settled in terms of this clause by giving written notice to the other Party. (1)

1.3 This Clause 1 shall not prevent a Party from obtaining relief on an urgent basis from a competent court, pending the decision of the arbitrator. (1)

1.4 That arbitration shall be held:

1.4.1 In Pretoria and at the Brooklyn Advocates' Chambers; (½)

1.4.2 With only the Parties and their representatives, present thereat; (1)

1.4.3 Mutatis mutandis in accordance with the Rules promulgated in terms of the Supreme Court Act, No 59 of 1959 and the uniform Rules of the High Court of South Africa, provided that no time period specified therein shall be longer than 10 court days for the purposes of the arbitration; (½)

1.4.4 Otherwise in terms of the Arbitration Act No 42 of 1965, it being the intention that the arbitration shall be held and concluded as soon as possible. (1)

1.5 The arbitrator shall, if the matter in dispute is principally:

1.5.1 a legal matter, be a practising counsel or a practising attorney of not less than 10 (ten) years standing; (1)

1.5.2 an accounting matter, be a practising chartered accountant of not less than 10 (ten) years standing;

1.5.3 any other matter, be an independent person qualified to hear and adjudicate upon such matter;

and shall be agreed to between the Parties to the dispute.

1.6 Should the Parties to a dispute fail to agree whether the dispute is principally a legal, accounting or other matter within 7 (seven) days after arbitration has been demanded, the matter shall be considered to be a legal dispute. (1)

1.7 Should the Parties fail to agree upon an arbitrator within 14 (fourteen) days after the arbitration has been demanded, then the arbitrator shall be appointed at the request of either of the Parties to the dispute by the President for the time being of the Law Society of ... (1)

1.8 The Parties irrevocably agree and undertake with each other that any award that may be made by the arbitrator: (1)

---LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

4