c. The balance of convenience must favour the applicant;

There must be no alternative remedy.

# QUESTION 4

[4]

The rules provide for:

a. Edictal citation if process is to be served outside the RSA (Rule 5: High Court); or
b. Substituted service if the person is in the RSA but exact whereabouts unknown. Rule 4(2) authorises the Court to give suitable directions as to service.

# QUESTION 5

[8]

5.1 Operation requirements arising from economic; technological; structural or similar needs are recognised as grounds for dismissal. (2)
5.2 The employer must avoid or minimise terminations e.g. stop hiring; stop overtime; offer voluntary retrenchment; or early retirement; reduce working hours. (6)

# QUESTION 6

[7]

Having satisfied him/herself of the identity of the deponent the commissioner of oath must ask the deponent whether he/she knows and understand the contents of the affidavit; must ask the deponent whether he/she has any objection to taking the prescribed oath; must ask the deponent whether he/she regards the oath as binding on his/her conscience. If the deponent has an objection to taking the oath, he/she may make a solemn declaration. The affidavit or solemn declaration is then signed in the presence of the commissioner of oaths, who also signs it. A certificate must be added to the bottom of the document, confirming that the document was signed and attested to before him/her. The affidavit must contain the full names, physical address and authority of the commissioner of oaths.

# QUESTION 7

[4]

7.1 Yes. (1/2)
7.2.1 Yes, it is an Incidental Credit Agreement (i.t.o. s1, NCA). (1/2)
7.2.2 No. (1/2)
7.2.3 No, court accepted without discussing the definition of Lease in the NCA, that section 8 of the NCA excludes rental i.r.o. immovable property. (1/2)
7.3 No. (1)
7.4.1 No, the NCA only applies to a credit guarantee if that guarantee is in respect of a Credit Facility or Credit Transaction. (½)

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

2