# **ADMISSION EXAMINATION / TOELATINGSEKSAMEN**
**COURT PROCEDURES / HOFPROSEDURES**
**PART 1 / DEEL 1**

**21 AUGUST / AUGUSTUS 2019**

**ANSWERS / ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

**QUESTION 1** [20]

1.1

1.1.1 Compensation Commissioner; (1/2)

1.1.2 Road Accident Fund. (1/2)

1.2

1.2.1 From the Compensation Commissioner he can claim all his special damages i.e. R13 500-00; (1)

1.2.2

From the Road Accident Fund R310 000-00 in respect of special damages subject to the Fund being entitled to deduct the amount of the Compensation Commissioner's award. (1)

1.3 No. The employer is not responsible for the negligence of employees in his employ against each other. He is absolved from liability by statute. (Section 35 of the Compensation for Occupational Injuries and Diseases Act – COIDA.)

(1)

1.4

1.4.1 Compensation Commissioner (1/2)

1.4.2 Road Accident Fund (1/2)

1.5 R13 500-00 + R60 000-00 + R150 000-00 = R223 500-00 less 50% apportionment = R111 750 less award by Compensation Commissioner R13 500 = R98 250-00. (2)

1.6 R230 000-00 + R400 000-00 + R500 000-00 + R600 000-00 = R1 730 000-00 less award by Compensation Commissioner R230 000-00 = R1 500 000-00.

(2)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1

1.7 By the 11th September 2019. The vehicle which collided with John is unidentified (Hit and run claim). (2)

1.8 By the 11th September 2020 in respect of the vehicle in which he was a passenger. (2)

1.9

1.9.1 Yes. Any damagers that Sipho receives must now be reduced by the extent to which he is negligent in not wearing a seatbelt; (2)

1.9.2 R230 000-00 + R400 000-00 + R500 000-00 + R600 000-00 = R1 730 000-00
LESS 20% apportionment = R1 384 000-00 less award by Compensation Commissioner R230 000-00 = R1 154 000-00. (2)

1.10 The alternative plea and prayer will read as follows:

"Alternatively, and in the event of it being proved (found) that the driver of the insured vehicle was negligent in any respect or at all (which is denied) (1) then the Defendant pleads that the Plaintiff was also negligent and that such negligence contributed to the collision (1) and accordingly in terms the Apportionment of Damages Act any damages recovered by the Plaintiff must be reduced by the extent in which he was negligent." (1)

Or

"In the alternative, Defendant prays that the Plaintiff's claim be reduced by the extent to which this Honourable finds that the Plaintiff was negligent, (1) and that such negligence contributed to the collision (1) and that this Court make such order as to costs as maybe just and equitable." (1)

## QUESTION 2

[5]

If a person does not succeed in surmounting the 30% WPI threshold he or she may qualify for general damages under the, narrative test. To qualify for non-patrimonial damages under the narrative test, one's injuries need to satisfy one of the following exceptions:

1. Serious long-term impairment or loss of a bodily function;
2. Permanent serious disfigurement;
3. Severe long-term behavioral disturbance or disorder;
4. Loss of a fetus.

## QUESTION 3

[7]

3.1 An appeal is a rehearing on the merits by a higher court (1), and is limited to the evidence or information on which the original decision was given (½). New evidence may only be adduced with the leave of the court. (½)

3.2 A review is a procedure whereby decisions of a lower court or tribunal or administrative body (1) are brought into question in higher courts where grave irregularities are found to be occurring or have occurred in the lower court. (1)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2

3.3 A. An appeal:
3.3.1 Appeals must be noted within a particular period in accordance with the statutory provisions or the provisions of the rules of court \((\frac{1}{2})\). In the High Court leave to appeal needs to be granted \((\frac{1}{2})\)
3.3.2 In the case of an appeal the appellant is bound by the record \((\frac{1}{2})\)
3.3.3 On appeal it is contended that the presiding officer came to a wrong conclusion on the facts or the law. \((\frac{1}{2})\)

# B. A Review

3.3.4 Reviews are brought by application procedure and need not be brought within a fixed period but must be brought within a reasonable time. \((\frac{1}{2})\)
3.3.5 In the case of a review the applicant is not bound by the record. Often an applicant's objection concerns an action or remiss on the side of the decision maker which does not appear from the record. \((\frac{1}{2})\)
3.3.6 The grounds for review relates to absence of the jurisdiction on the part of the court, gross irregularity in the proceedings the admission of inadmissible or incompetent evidence or the rejection of admissible or competent evidence. \((\frac{1}{2})\)

# QUESTION 4

[10]

4.1

4.1.1 If the Plaintiff sues for damages, he/she shall set them out in such a manner as will enable the Defendant reasonably to assess the quantum thereof; (1)
4.1.2 A Plaintiff suing for damages for personal injury shall specify his date of birth, the nature and extent of the injuries, and the nature, effect and duration of the disability alleged to give rise to such damages; (2)
4.1.3 the Plaintiff shall as far as practicably possible state separately what amount, if any, he has claimed for -

a) medical costs and hospital and other similar expenses, and how these costs and expenses are made up; (1)
b) Pain and suffering, stating whether temporary or permanent, and which injuries caused it; (1)
c) Disability in respect of

(i) The earning of income (stating the earnings lost to date, and how the amount is made up, and the estimated future loss and the nature of the work the Plaintiff in future will be able to do; (1)

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3

(ii) The enjoyment of amenities of life (giving particulars) and stating whether the disability concerned is temporary or permanent. (1)

d) Disfigurement, with a full description thereof and stating whether it is temporary or permanent. (1)

4.2 If a party fails to comply with any of the provisions of Rule 18, such pleading shall be deemed to be an irregular step and the opposite party shall be entitled to act in accordance with Rule 30, which deals with Irregular proceedings. (2)

# QUESTION 5

[8]

5.1

Simple Summons (1)
Combined Summons (1)
Provisional Sentence Summons (1)

5.2.1 A simple summons can only be used in the following circumstances: (any 4 examples - ½ mark each)

- Claims for payment of a debt (liquidated demand) and examples are a claim for the payment of (balance) of the purchase price of goods purchased and delivered, money lent and advanced \((\frac{1}{2})\).
A claim for delivery of a specified movable asset or for delivery for an account \((\frac{1}{2})\)
A claim for the registration of transfer of immovable property \((\frac{1}{2})\)
A claim for eviction of a person from a specific property \((\frac{1}{2})\)
- Claims for the cancellation of a contract \((\frac{1}{2})\)

5.2.2 Combined summons

A combined summons may be used in all cases where action procedure is appropriate. One does not have to distinguish between liquidated and liquidated claims. (1). A combined summons is used in inter alia damages claims or divorce proceedings (1)

5.2.3 A provisional sentence summons

A provisional sentence summons is only used where the cause of action is based on a liquid document. (1)

# QUESTION 6

[8]

1. Search with a warrant: Section 21

- The police must apply for a warrant to a Magistrate through a statement under oath
Police must state that reasonable grounds exist for believing that article is in possession or under control or on premises within jurisdiction area
- Search to be conducted in terms of contents of warrant
- Client entitled to a copy of the search warrant

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4

2. Search without a warrant: Section 22

- If police reasonably believe that a search warrant will be issued if an application is made and that a delay in obtaining a search warrant will defeat the purpose of search, they may proceed to conduct it without a warrant
- If the client consents to the search being conducted without the police being in possession of a search warrant

# QUESTION 7

[8]

1. Bring an application for leave to appeal before the Magistrate's Court that convicted and sentenced him
2. In the event leave to appeal is refused by the Magistrate's Court, lodge a petition to the judge president of the High Court
3. Apply for bail pending the finalisation of the appeal.
4. Deliver the Notice of Appeal at the Magistrate's Court
5. File a Special Power of Attorney authorising the appeal
6. Obtain a complete record of the proceedings (transcripts and exhibits included) to be used in the appeal.
7. Draw Heads of Argument and deliver same
8. Attend court when appeal heard.

# QUESTION 8

[4]

8.1 It is the duty of an attorney to ensure that the version of the accused is put to a witness particularly where same differs from the witness's version of events. Each and every difference should be put to the witness. (2)
8.2 Should you fail to do so the magistrate will be entitled to accept the version of the witness as being correct. (1)
8.3 Should the witness not be cross-examined his evidence can be accepted in its entirety. (1)

# QUESTION 9

[2]

If an accused conduct himself in a manner which makes the continuance of the proceedings in his presence impractical, the court may direct that he may be removed and the proceedings continue in his absence.

# QUESTION 10

[3]

Section 236:

1. An affidavit deposed to by bank employee in their service of the institution in question.
2. That the entries on the records have been made in ordinary course of the business of the institution.
3. That such records are kept in the custody or control of such bank.

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

5

QUESTION 11

[10]

# PARTICULARS OF CLAIM

1. The Plaintiff is Peter Jones an Adult male teacher with ID number 721114 0862 3 157 residing at 1 Smith Street, Johannesburg.
2. The Defendant is John Doe, an adult male who is residing at 12 Menlyn Street, Pretoria.
3. At all material times hereto the Plaintiff was the owner of a 2013 Honda Ballade with Registration number ERG 123 GP alternatively the bona fide possessor thereof, the risk thereupon having passed to the Plaintiff.
4. On or about 3 February 2018 and at or near corner of Jan Smuts Avenue and Conrad Avenue, Johannesburg, a collision occurred between the Plaintiff's motor vehicle and a motor vehicle with registration number PTY 234 GP.
5. The honorable court has jurisdiction over the matter as the whole cause of action occurred within the jurisdiction of the honourable court.
6. The sole cause of the collision was as a result of the negligent driving of the Defendant, acting in one or more of all of the following respects:
6.1 He failed to keep a proper lookout;
6.2 He failed to avoid a collision whilst with the exercise of reasonable care the Defendant could and should have done so;
6.3 He failed to apply brakes timeously or at all;
6.4 He failed to keep his vehicle under proper control.
7. As a result of the aforesaid collision, the Plaintiff suffered damages in the sum of R150 000.00 being calculated as follows:
7.1 R150 000 being the fair, reasonable and necessary repair costs in order to restore the Plaintiff's motor vehicle to its pre-collision condition. A copy of a quotation from the repairing garage is annexed hereto marked "A". [Alternatively the candidate may set out the precise damage and calculation]
8. Notwithstanding written demand, the Defendant has failed, alternatively refused, further alternatively neglected to pay the aforesaid amount. A copy of the letter of demand is annexed hereto marked "B".

WHEREFORE the Plaintiff prays for judgment against the Defendant for:

(a) Payment in the sum of R150 000;

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6

(b) Interest thereon at \(10\%\) per annum from date of the expiry of the letter of demand [the prescribed rate of interest might change by the time the exam is written]
(c) Costs of suit;
(d) Further and/or alternative relief.

DATED at

Hyde Park this

20th

May

2018.

Naidoo & Co.

Plaintiff's Attorneys

12 East Street

Johannesburg

Plaintiff's Attorneys

# QUESTION 12

[5]

12.1 No. The District Magistrates' Court does not have jurisdiction in Divorce matters. The Statutory jurisdiction is given to the Regional Magistrate's Court. (1)
12.2 Yes. There is no monetary limitation on the divorces that the Regional Magistrates' Court may have to deal with. (1)
12.3 Yes. There is no monetary limitation on liquidations that the District Magistrates' Court may deal with in respect of a Close Corporation. (1)
12.4 The amount is too high for the jurisdiction of the Regional Magistrates' Court. The Defendant will have to apply to stay the action and proceed in the High Court. (2)

# QUESTION 13

[4]

1. Action based on a liquid document. (1)
2. Action based on payment of a liquidated amount. (1)
3. Ejectment. (1)
4. Delivery of specified movables. (1)

# QUESTION 14

[3]

No allegation of delivery (1)
No allegation of presentation and dishonour by non-payment. (2)

# QUESTION 15

[3]

5.1 Absolution from the instance with the Plaintiff to pay the costs. (2)
5.2 Issue a new Summons for the amount claimed (1)

TOTAL: [100]

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7