# **ADMISSION EXAMINATION / TOELATINGSEKSAMEN**
**COURT PROCEDURES / HOFPROSEDURES**
**PART 1 / DEEL 1**

**21 AUGUST / AUGUSTUS 2019**

**ANSWERS / ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

**QUESTION 1** [20]

1.1

1.1.1 Compensation Commissioner; (1/2)

1.1.2 Road Accident Fund. (1/2)

1.2

1.2.1 From the Compensation Commissioner he can claim all his special damages i.e. R13 500-00; (1)

1.2.2

From the Road Accident Fund R310 000-00 in respect of special damages subject to the Fund being entitled to deduct the amount of the Compensation Commissioner's award. (1)

1.3 No. The employer is not responsible for the negligence of employees in his employ against each other. He is absolved from liability by statute. (Section 35 of the Compensation for Occupational Injuries and Diseases Act – COIDA.)

(1)

1.4

1.4.1 Compensation Commissioner (1/2)

1.4.2 Road Accident Fund (1/2)

1.5 R13 500-00 + R60 000-00 + R150 000-00 = R223 500-00 less 50% apportionment = R111 750 less award by Compensation Commissioner R13 500 = R98 250-00. (2)

1.6 R230 000-00 + R400 000-00 + R500 000-00 + R600 000-00 = R1 730 000-00 less award by Compensation Commissioner R230 000-00 = R1 500 000-00.

(2)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1