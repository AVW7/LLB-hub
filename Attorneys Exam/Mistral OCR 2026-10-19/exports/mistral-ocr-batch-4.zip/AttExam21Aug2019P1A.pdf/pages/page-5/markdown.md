2. Search without a warrant: Section 22

- If police reasonably believe that a search warrant will be issued if an application is made and that a delay in obtaining a search warrant will defeat the purpose of search, they may proceed to conduct it without a warrant
- If the client consents to the search being conducted without the police being in possession of a search warrant

# QUESTION 7

[8]

1. Bring an application for leave to appeal before the Magistrate's Court that convicted and sentenced him
2. In the event leave to appeal is refused by the Magistrate's Court, lodge a petition to the judge president of the High Court
3. Apply for bail pending the finalisation of the appeal.
4. Deliver the Notice of Appeal at the Magistrate's Court
5. File a Special Power of Attorney authorising the appeal
6. Obtain a complete record of the proceedings (transcripts and exhibits included) to be used in the appeal.
7. Draw Heads of Argument and deliver same
8. Attend court when appeal heard.

# QUESTION 8

[4]

8.1 It is the duty of an attorney to ensure that the version of the accused is put to a witness particularly where same differs from the witness's version of events. Each and every difference should be put to the witness. (2)
8.2 Should you fail to do so the magistrate will be entitled to accept the version of the witness as being correct. (1)
8.3 Should the witness not be cross-examined his evidence can be accepted in its entirety. (1)

# QUESTION 9

[2]

If an accused conduct himself in a manner which makes the continuance of the proceedings in his presence impractical, the court may direct that he may be removed and the proceedings continue in his absence.

# QUESTION 10

[3]

Section 236:

1. An affidavit deposed to by bank employee in their service of the institution in question.
2. That the entries on the records have been made in ordinary course of the business of the institution.
3. That such records are kept in the custody or control of such bank.

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

5