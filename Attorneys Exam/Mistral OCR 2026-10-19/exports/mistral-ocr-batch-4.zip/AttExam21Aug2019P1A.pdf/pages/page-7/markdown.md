(b) Interest thereon at \(10\%\) per annum from date of the expiry of the letter of demand [the prescribed rate of interest might change by the time the exam is written]
(c) Costs of suit;
(d) Further and/or alternative relief.

DATED at

Hyde Park this

20th

May

2018.

Naidoo & Co.

Plaintiff's Attorneys

12 East Street

Johannesburg

Plaintiff's Attorneys

# QUESTION 12

[5]

12.1 No. The District Magistrates' Court does not have jurisdiction in Divorce matters. The Statutory jurisdiction is given to the Regional Magistrate's Court. (1)
12.2 Yes. There is no monetary limitation on the divorces that the Regional Magistrates' Court may have to deal with. (1)
12.3 Yes. There is no monetary limitation on liquidations that the District Magistrates' Court may deal with in respect of a Close Corporation. (1)
12.4 The amount is too high for the jurisdiction of the Regional Magistrates' Court. The Defendant will have to apply to stay the action and proceed in the High Court. (2)

# QUESTION 13

[4]

1. Action based on a liquid document. (1)
2. Action based on payment of a liquidated amount. (1)
3. Ejectment. (1)
4. Delivery of specified movables. (1)

# QUESTION 14

[3]

No allegation of delivery (1)
No allegation of presentation and dishonour by non-payment. (2)

# QUESTION 15

[3]

5.1 Absolution from the instance with the Plaintiff to pay the costs. (2)
5.2 Issue a new Summons for the amount claimed (1)

TOTAL: [100]

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7