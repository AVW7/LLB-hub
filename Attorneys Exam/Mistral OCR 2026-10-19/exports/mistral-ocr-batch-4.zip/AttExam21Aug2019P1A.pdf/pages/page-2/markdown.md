1.7 By the 11th September 2019. The vehicle which collided with John is unidentified (Hit and run claim). (2)

1.8 By the 11th September 2020 in respect of the vehicle in which he was a passenger. (2)

1.9

1.9.1 Yes. Any damagers that Sipho receives must now be reduced by the extent to which he is negligent in not wearing a seatbelt; (2)

1.9.2 R230 000-00 + R400 000-00 + R500 000-00 + R600 000-00 = R1 730 000-00
LESS 20% apportionment = R1 384 000-00 less award by Compensation Commissioner R230 000-00 = R1 154 000-00. (2)

1.10 The alternative plea and prayer will read as follows:

"Alternatively, and in the event of it being proved (found) that the driver of the insured vehicle was negligent in any respect or at all (which is denied) (1) then the Defendant pleads that the Plaintiff was also negligent and that such negligence contributed to the collision (1) and accordingly in terms the Apportionment of Damages Act any damages recovered by the Plaintiff must be reduced by the extent in which he was negligent." (1)

Or

"In the alternative, Defendant prays that the Plaintiff's claim be reduced by the extent to which this Honourable finds that the Plaintiff was negligent, (1) and that such negligence contributed to the collision (1) and that this Court make such order as to costs as maybe just and equitable." (1)

## QUESTION 2

[5]

If a person does not succeed in surmounting the 30% WPI threshold he or she may qualify for general damages under the, narrative test. To qualify for non-patrimonial damages under the narrative test, one's injuries need to satisfy one of the following exceptions:

1. Serious long-term impairment or loss of a bodily function;
2. Permanent serious disfigurement;
3. Severe long-term behavioral disturbance or disorder;
4. Loss of a fetus.

## QUESTION 3

[7]

3.1 An appeal is a rehearing on the merits by a higher court (1), and is limited to the evidence or information on which the original decision was given (½). New evidence may only be adduced with the leave of the court. (½)

3.2 A review is a procedure whereby decisions of a lower court or tribunal or administrative body (1) are brought into question in higher courts where grave irregularities are found to be occurring or have occurred in the lower court. (1)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2