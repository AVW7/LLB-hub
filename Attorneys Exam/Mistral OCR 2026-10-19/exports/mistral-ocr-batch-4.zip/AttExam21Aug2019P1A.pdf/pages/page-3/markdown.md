3.3 A. An appeal:
3.3.1 Appeals must be noted within a particular period in accordance with the statutory provisions or the provisions of the rules of court \((\frac{1}{2})\). In the High Court leave to appeal needs to be granted \((\frac{1}{2})\)
3.3.2 In the case of an appeal the appellant is bound by the record \((\frac{1}{2})\)
3.3.3 On appeal it is contended that the presiding officer came to a wrong conclusion on the facts or the law. \((\frac{1}{2})\)

# B. A Review

3.3.4 Reviews are brought by application procedure and need not be brought within a fixed period but must be brought within a reasonable time. \((\frac{1}{2})\)
3.3.5 In the case of a review the applicant is not bound by the record. Often an applicant's objection concerns an action or remiss on the side of the decision maker which does not appear from the record. \((\frac{1}{2})\)
3.3.6 The grounds for review relates to absence of the jurisdiction on the part of the court, gross irregularity in the proceedings the admission of inadmissible or incompetent evidence or the rejection of admissible or competent evidence. \((\frac{1}{2})\)

# QUESTION 4

[10]

4.1

4.1.1 If the Plaintiff sues for damages, he/she shall set them out in such a manner as will enable the Defendant reasonably to assess the quantum thereof; (1)
4.1.2 A Plaintiff suing for damages for personal injury shall specify his date of birth, the nature and extent of the injuries, and the nature, effect and duration of the disability alleged to give rise to such damages; (2)
4.1.3 the Plaintiff shall as far as practicably possible state separately what amount, if any, he has claimed for -

a) medical costs and hospital and other similar expenses, and how these costs and expenses are made up; (1)
b) Pain and suffering, stating whether temporary or permanent, and which injuries caused it; (1)
c) Disability in respect of

(i) The earning of income (stating the earnings lost to date, and how the amount is made up, and the estimated future loss and the nature of the work the Plaintiff in future will be able to do; (1)

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3