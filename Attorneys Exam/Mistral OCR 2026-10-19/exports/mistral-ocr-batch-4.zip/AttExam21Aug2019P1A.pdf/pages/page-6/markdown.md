QUESTION 11

[10]

# PARTICULARS OF CLAIM

1. The Plaintiff is Peter Jones an Adult male teacher with ID number 721114 0862 3 157 residing at 1 Smith Street, Johannesburg.
2. The Defendant is John Doe, an adult male who is residing at 12 Menlyn Street, Pretoria.
3. At all material times hereto the Plaintiff was the owner of a 2013 Honda Ballade with Registration number ERG 123 GP alternatively the bona fide possessor thereof, the risk thereupon having passed to the Plaintiff.
4. On or about 3 February 2018 and at or near corner of Jan Smuts Avenue and Conrad Avenue, Johannesburg, a collision occurred between the Plaintiff's motor vehicle and a motor vehicle with registration number PTY 234 GP.
5. The honorable court has jurisdiction over the matter as the whole cause of action occurred within the jurisdiction of the honourable court.
6. The sole cause of the collision was as a result of the negligent driving of the Defendant, acting in one or more of all of the following respects:
6.1 He failed to keep a proper lookout;
6.2 He failed to avoid a collision whilst with the exercise of reasonable care the Defendant could and should have done so;
6.3 He failed to apply brakes timeously or at all;
6.4 He failed to keep his vehicle under proper control.
7. As a result of the aforesaid collision, the Plaintiff suffered damages in the sum of R150 000.00 being calculated as follows:
7.1 R150 000 being the fair, reasonable and necessary repair costs in order to restore the Plaintiff's motor vehicle to its pre-collision condition. A copy of a quotation from the repairing garage is annexed hereto marked "A". [Alternatively the candidate may set out the precise damage and calculation]
8. Notwithstanding written demand, the Defendant has failed, alternatively refused, further alternatively neglected to pay the aforesaid amount. A copy of the letter of demand is annexed hereto marked "B".

WHEREFORE the Plaintiff prays for judgment against the Defendant for:

(a) Payment in the sum of R150 000;

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6