(ii) The enjoyment of amenities of life (giving particulars) and stating whether the disability concerned is temporary or permanent. (1)

d) Disfigurement, with a full description thereof and stating whether it is temporary or permanent. (1)

4.2 If a party fails to comply with any of the provisions of Rule 18, such pleading shall be deemed to be an irregular step and the opposite party shall be entitled to act in accordance with Rule 30, which deals with Irregular proceedings. (2)

# QUESTION 5

[8]

5.1

Simple Summons (1)
Combined Summons (1)
Provisional Sentence Summons (1)

5.2.1 A simple summons can only be used in the following circumstances: (any 4 examples - ½ mark each)

- Claims for payment of a debt (liquidated demand) and examples are a claim for the payment of (balance) of the purchase price of goods purchased and delivered, money lent and advanced \((\frac{1}{2})\).
A claim for delivery of a specified movable asset or for delivery for an account \((\frac{1}{2})\)
A claim for the registration of transfer of immovable property \((\frac{1}{2})\)
A claim for eviction of a person from a specific property \((\frac{1}{2})\)
- Claims for the cancellation of a contract \((\frac{1}{2})\)

5.2.2 Combined summons

A combined summons may be used in all cases where action procedure is appropriate. One does not have to distinguish between liquidated and liquidated claims. (1). A combined summons is used in inter alia damages claims or divorce proceedings (1)

5.2.3 A provisional sentence summons

A provisional sentence summons is only used where the cause of action is based on a liquid document. (1)

# QUESTION 6

[8]

1. Search with a warrant: Section 21

- The police must apply for a warrant to a Magistrate through a statement under oath
Police must state that reasonable grounds exist for believing that article is in possession or under control or on premises within jurisdiction area
- Search to be conducted in terms of contents of warrant
- Client entitled to a copy of the search warrant

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4