|  Liabilities |  |  |   |
| --- | --- | --- | --- |
|  Administration costs |  |  |   |
|  Advertising for Debtors and Creditors | 10 |  |   |
|  Government Gazette |  | 37.50[1] |   |
|  The Star |  | 312.50 |   |
|  Advertising Account for inspection | 11 |  |   |
|  Government Gazette |  | 37.50 [1] |   |
|  The Star |  | 312.50 |   |
|  Master's fees (Maximum) | 12 | 600 [1] |   |
|  Executor's fees at 3.5% on R2 700 000.00 | 13 | 94 500.00 [1] |   |
|  JP Baritos Valuation costs: farm and movable properties | 14 | 10 000.00 [1] |   |
|  D Daniels Attorneys – Conveyancer's fees | 15 | 17 000.00 [1] |   |
|  Bank charges | 16 | 12 000.00 [1] |   |
|  Provision on Bank charges | 17 | 8 000.00 [1] |   |
|  Postages and Petties | 18 | 260.00 [1] |   |
|  Claims against the estate |  |  |   |
|  RESTING SOUL – funeral expenses | 19 | 34 440.00[1] |   |
|  Loan against Liberty Life Policy | 20 | 25 000.00[1] |   |
|  Stockbroker's fees | 21 | 17 500.00[1] |   |
|  Total Liabilities |  | 220 000.00 |   |
|  Estate Duty |  | 0.00 |   |
|  Balance for distribution |  | 2 480 000.00 |   |
|   |  | 2 700 000.00 |   |
|  Recapitulation Statement |  |  |   |
|  Cash and assets reduced to cash (Items 3 to 9 in the Liquidation Account) |  |  | 1 520 000.00[2]  |
|  Less: |  |  |   |
|  Liabilities |  | 220 000.00[1] |   |
|  Cash Legacies |  | NIL |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3