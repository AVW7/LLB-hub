|  Estate Duty Cash surplus |  | NIL 1 300 000.00[1] 1 520 000.00 | 1 520 000.00  |
| --- | --- | --- | --- |
|  Distribution Account |  |  |   |
|  Balance for distribution |  |  | 2 480 000.00[1]  |
|  Awarded to: |  |  |   |
|  Sarah Tsuma, major surviving mother of the deceased, as sole heir i.t.o. clause 5 of the Will dated 10 June 2015 [1] |  | 2 480 000.00 [1] |   |
|  Award consists of: Immovable property R1 100 000.00 [1] Movable property R 80 000.00 [1] Cash R1 300 000.00 [1] |  | 2 480 000.00 | 2 480 000.00  |
|  Income & Expenditure Account |  |  |   |
|  Income |  |  |   |
|  Interest received on Trust bank account |  |  | 6 000.00 [1]  |
|  Expenditure |  |  |   |
|  Executor's remuneration @ 6% on R6 000.00 |  | 360.00 [1] |   |
|  Balance awarded to Sarah Tsuma as the sole heir [1] |  | 5 640.00 [1] 6 000.00 | 6 000.00  |
|  Fiduciary Assets Account |  |  |   |
|  ASSETS: ERF 243 Ethekwini Registration Division FU, Province of Kwazulu Natal: Measuring: 800 m² Held under Deed of Transfer No 764/69 [1] And Registered on 1 May 1969 Valued at | 22 |  | 600 000.00 [1]  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4