|  600 000.00 X 12% X 8.262 10)* *for the information of the markers |  |  | 594 871.20 [1]  |
| --- | --- | --- | --- |
|  **Sub-total of actual property** |  |  | **2 784 871.20**  |
|  ADD: Property Deemed to be Property Add: Sanlam Life Policy payable to estate Liberty Life Insurance Policy payable to Tinny Tsuma |  | 500 000.00 [1] 150 000.00 [1] | **650 000.00**  |
|  GROSS VALUE OF THE DUTIABLE ESTATE |  |  | 3 434 871.20 [1]  |
|  LESS: Deductions – Sect 4 |  |  |   |
|  Costs of Administration and claims |  |  | 220 000.00[1]  |
|  NETT VALUE OF THE DUTIABLE ESTATE |  |  | 3 214 871.20 [1]  |
|  Less: Primary Rebate – Sect 4A |  |  | 3 500 000 [1]  |
|  DUTIABLE AMOUNT |  |  | 0.00 [1]  |
|  Estate Duty at 20% on R0.00 |  |  | 0.00  |

# EXECUTOR'S CERTIFICATE

I, the undersigned, Zodwa Tsuma, the duly appointed executor in the estate of the late Jafta Tsuma Estate Number 854/2017, declare as follows:

That the attached account is to the best of my knowledge and belief a true and proper reflection of the liquidation and distribution of the estate; [1] and

That this is a final account and to the best of my knowledge and belief all the assets and income collected subsequent to the death of the deceased to the date of the account have been reflected herein. [1]

SIGNED AT

ON THIS

DAY OF

2017

ZODWA TSUMA (EXECUTRIX)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6