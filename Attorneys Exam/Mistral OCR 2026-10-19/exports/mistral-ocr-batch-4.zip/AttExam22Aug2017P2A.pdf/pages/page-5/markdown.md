|  (Awarded and to be transferred to Tinny Tsuma major granddaughter i.t.o. clause 4 of the Will of Nelson Tsuma whose estate was administered at the Pretoria Master's office No 637/2007) [1] |  |  |   |
| --- | --- | --- | --- |
|  LIABILITIES:  |   |   |   |
|  Valuation Costs | 23 | 1 700.00 [1] |   |
|  D DANIELS Attorneys – transfer costs | 24 | 6 300.00 [1] |   |
|  Executor's fees at 3.5% on R600 000.00 | 25 | 21 000.00 [1] |   |
|  Balance for distribution |  | 571 000.00 |   |
|  To be awarded to Tinny Tsuma in terms of clause 4 of the valid Will of her late grandfather, Nelson Tsuma who died on 3 May 2007 (Master's ref no 637/2007) |  | 600 000.00 | 600 000.00  |
|  Distribution Account |  |  |   |
|  Balance for distribution |  |  | 571 000.00 [1]  |
|  Awarded to: Tinny Tsuma, major, as fideicommissary heir in terms of clause 4 of the valid Will of Nelson Tsuma. |  |  |   |
|  Award consist of: Immovable property |  | 600 000.00[1] | 29 000.00 [1]  |
|  Less: Cash shortfall to be paid by the estate of the late Jafta Tsuma |  | 600 000.00 | 600 000.00  |
|  Estate Duty Addendum |  |  |   |
|  Property of the deceased |  |  |   |
|  Assets as per liquidation account |  | 500 000.00 [1] | 2 700 000.00 [1]  |
|  Less: Sanlam Life Policy payable to estate |  |  | 2 200 000.00  |
|  Less: Difference in value of private shares |  | 10 000.00 [1] | 2 190 000.00  |
|  Add Value of Ceasing Fiduciary Right |  |  |   |
|  (Age of Tinny Tsuma which follows on 1/03/2017=33 years |  |  |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5