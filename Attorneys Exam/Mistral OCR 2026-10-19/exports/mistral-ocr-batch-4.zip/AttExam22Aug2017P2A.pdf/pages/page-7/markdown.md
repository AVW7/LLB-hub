QUESTION 2

[11]

Raymond's Estate will devolve as follows:

2.1 his mother Maggie inherits half of the estate in terms of Section 1(1)(d) (ii) of the Intestate Succession Act in the amount of R400 000.00 [1]

David inherits R100 000.00 in terms of Section 1(1)(d) (ii) of the Intestate Succession Act because he is the descendant of Raymond's adoptive father [1]

George inherits R100 000.00 in terms of Section 1(1)(d) (ii) of the Intestate Succession Act because he is the descendant of Raymond's adoptive father [1]

Simon, the child of the pre-deceased daughter Maria from Dickson's 1st marriage to Dorcas inherits R50 000.00 in terms of Section 1(4)(a) of the Intestate Succession Act because he represents the descendant of Raymond's adoptive father [1]

Hilda, the child of the pre-deceased daughter Maria from Dickson's 1st marriage to Dorcas inherits R50 000.00 in terms of Section 1(4)(a) of the Intestate Succession Act because she represents the descendant of Raymond's adoptive father [1]

Sarah, who is the child of Dickson and Maggie inherits R100 000.00 in terms of Section 1(1)(d) (ii) of the Intestate Succession Act because she is the descendant of Raymond's adoptive father [1]

2.2 His divorced wife Julia cannot inherit because she was not Raymond's wife at the time of his death [1]

Jane and Dorcas, the previous spouses of Raymond's adoptive father Dickson, will not inherit because they are not the blood relations of Raymond [1]

His biological father Freddy will not inherit anything because Raymond is not deemed to be his descendant in terms of Section 1(4)(e) (ii) of the Intestate Succession Act as he was adopted by Dickson [2]

Dickson's father Paul will not inherit anything because he is a more remote relation of the deceased [1]

QUESTION 3

[7]

The Testatrix attempted to amend her Will, and in terms of Section 2(1)(b) of the Wills Act [1], she and two competent witnesses should sign at the amendment [1]. Because no witnesses signed, the amendment is invalid [1] and Surprise will inherit [1].

Steve can approach the High Court [1] and if he can prove to the Court that it was the intention of the Testatrix to effect the amendment [1], the Court can order the amendment to be accepted even if it was not formally correct (Section 2(3)) [1].

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7