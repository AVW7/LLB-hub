|  Liquidation account |  |  |   |
| --- | --- | --- | --- |
|  Assets |  |  |   |
|  Immovable property |  |  |   |
|  Farm 188 Marikos Registration Division JR, Province of Gauteng Measuring 1600ha. Held by Deed of Transfer No. T1346/1998 [1] |  |  |   |
|  Valued at (to be awarded to Sarah Tsuma, as sole heir i.t.o. the deceased's Will dated 10 June 2015) [1] | 1 |  | 1 100 000.00 [1]  |
|  Movable property |  |  |   |
|  Furniture and household effects Valued at (to be awarded to Sarah Tsuma, as sole heir i.t.o. the deceased's Will dated 10 June 2015)[1] | 2 |  | 80 000.00 [1]  |
|  A BMW Registration FXJ 515 GP Sold for | 3 |  | 130 000.00 [1]  |
|  Sanlam Life Insurance Policy No. 137345x8 Proceeds of Policy | 4 |  | 500 000.00 [1]  |
|  Old Mutual Life Insurance Policy No. OM345Y At surrender value | 5 |  | 145 000.00 [1]  |
|  Shares in PPC (Pty) Ltd Sold at | 6 |  | 270 000.00 [1]  |
|  JSE quoted shares Sold at | 7 |  | 350 000.00 [1]  |
|  Investment at Trust bank |  |  |   |
|  Capital amount | 8 |  | 100 000.00 [1]  |
|  Interest as @ date of death | 9 |  | 25 000.00 [1]  |
|  Total Assets |  |  | 2 700 000.00 [1]  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2