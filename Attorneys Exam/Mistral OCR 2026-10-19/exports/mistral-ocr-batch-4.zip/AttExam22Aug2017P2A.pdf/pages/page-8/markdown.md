QUESTION 4

[18]

4.1

a) Notice to debtors and creditors [1] and that the Liquidation and Distribution account lies open for inspection [1]

(Also : Sect 29 –advertisement and Sect 35 – advertisement).

b) Sect 29 – as soon as possible after receipt of the Letters of Executorship [1]

Sect 35 – after the estate account has been approved by the Master [1]

c) Government Gazette and a Local newspaper circulating in the area where the deceased was ordinarily resident and if resided in any other area for a period of 12 months immediately preceding his date of death also in a newspaper circulating in that area. [2]

d) Sect 29 = 30 days and not more than 3 months [1]

Sect 35 = 21 days [1]

e) Sect 29 = to request creditors to submit their claims against the estate [1]

Sect 35 = to give interested parties the opportunity to lodge an objection against the estate account [1]

4.2 Where the deceased did not appoint an executor in his will [1] or the executor appointed is not prepared or is unable to act or ceases to act or where there is no will [1]

4.3 Where the value of the estate does not exceed R250 000.00 [1]

4.4 If the executor is not exempted from furnishing security by the will [1], and he is not a parent [1], child or surviving spouse [1] of the deceased or the court directs otherwise [1]

4.5 As soon as there is money in excess of R1 000,00 in the estate unless the master otherwise directs. [1]

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

8