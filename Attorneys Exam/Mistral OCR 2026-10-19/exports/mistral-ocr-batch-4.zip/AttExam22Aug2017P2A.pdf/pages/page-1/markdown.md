# ADMISSION EXAMINATION / TOELATING SEKSAMEN
ESTATES / BOEDELS
PART 2 / DEEL 2

22 AUGUST / 22 AUGUSTUS 2017

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY
NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE
MOMENT OF READING.

NOTE TO EXAMINER: This guideline records the views of the drafters. There
may be justifiable variations in practice which are brought
out in the answers. When this happens the examiner
should apply his discretion in marking the answer.

QUESTION 1

[64]

The first and final liquidation and distribution account in the Estate of the late Jafta Tsuma
ID 490425 5499 088,[1] who died on 1 March 2017 [1]and who was married according to
customary law, out of community of property without the accrual system. [1]

Master's Reference No. 854/2017

[1]

(Please note the answer to question 1 continues on next page, kindly turn page.)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1