### QUESTION 3

[6]

|  Damage client: (½) | R500 000 | 80% | = | R400 000 (1)  |
| --- | --- | --- | --- | --- |
|  Damage defendant: (½) | R600 000 | 20% | = | R120 000 (1)  |
|  Netto award to client |  |  | = | R280 000 (1)  |
|  25% of award (1) |  |  | = | R70 000 (1)  |

### QUESTION 4

[11]

4.1 Yes (1), B can accept the mandate, if he is comfortable with the matter (1), and if he has enough experience and/or expertise within the firm to render the service (1). B must however, still charge fees, as the favour is to assist, not to do it *pro bono* (1).

4.2 This question is an ethical question. Each person has a constitutional right to plead not guilty (1) (no duty to assist the State to prove their guilt) and a right to legal representation and a fair trial. Thus, despite a Legal Practitioner having a duty not to mislead the Court (1) he/she may still represent an accused client knowing due to the admission, that the client is in fact guilty of the offence and yet wants to plead not guilty (1).

However, to remain ethical, the Legal Practitioner must conduct the trial in a very specific manner (½). The accused may offer no plea explanation (½) (thus exercising his Constitutional right to silence). During cross-examination of the State witness(es), the Legal Practitioner may not put any false statement to the witness(es). The Legal Practitioner may effectively test the credibility of the State witness(es) and in doing so be conducting the trial in a way to ensure that his/her client has a fair trial (1).

At the close of the State's case, the Legal Practitioner may, if appropriate, apply for a Section 174 discharge (½). If discharge was refused, or it was not appropriate to apply for, the accused's case must be closed without leading any evidence either by the accused or any witnesses and argument follows on the evidence lead by the State alone (1). The Legal Practitioner would have to try to argue that the state has failed to prove the accused's guilt beyond reasonable doubt (½.)

### QUESTION 5

[9]

5.1 The Fund was established to reimburse members of the public (½) who suffer financial loss due (½) to the theft by an attorney, his employee or candidate (½) of money or property entrusted to that attorney (½).

5.2.1 The trust creditor cannot claim against the bank (1) as it is not the Bank's customers; (1)

5.2.2 There can also be no claim against the Fund, (1) this loss is not covered by the LPFF;(1)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

2