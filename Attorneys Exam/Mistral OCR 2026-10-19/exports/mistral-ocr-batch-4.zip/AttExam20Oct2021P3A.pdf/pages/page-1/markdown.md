# **ADMISSION EXAMINATION  
ATTORNEYS' PRACTICE  
PART 3**

**20 OCTOBER 2021**

**MEMORANDUM**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY  
NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE  
MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

# **SECTION A**

# **QUESTION 1** **[9]**

**Note: too many examples indicate lack of understanding or of drafting ability**

1.1 A person who displays the characteristics of honesty, integrity and reliability; (2)
1.2 Anything which is likely to affect your judgment adversely in advising or representing your client; (2)
1.3 It is a rule of evidence that an attorney may not disclose to the Court without the consent of the client information given to him for purpose of legal advice or representation. (2)
1.4 Lack of expertise/qualification/experience (1) danger of a conflict of interest (1); mandate to do or assist in the doing of something illegal or improper (1).

# **QUESTION 2** **[6]**

A contingency fee agreement. (1)
It is governed by the Contingency Fee Act 66 of 1997. (1)
An attorney is entitled to charge double his normal fee, (1)
up to a maximum of 25%, (1)
of the total amount awarded, whichever is the lesser. (2)

*LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

1