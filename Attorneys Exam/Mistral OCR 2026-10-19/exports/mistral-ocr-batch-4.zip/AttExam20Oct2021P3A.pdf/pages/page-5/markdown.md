2.1.1 he has first offered to sell it to the grantee as set out in this Agreement; (1)
2.1.2 the grantee has either refused the offer or failed to accept it timeously or in the manner prescribed in as set out in this Agreement, and (2)
2.1.3 the price payable to the grantor by any other buyer is not less than the market value as set out in 2.2; (2)

## 2.2 OFFER BY GRANTOR

The offer referred to within this Agreement must:

2.2.1 be open for acceptance by the grantee for a period of 30 (thirty) days following the date of receipt of the offer by the grantee; (1)
2.2.2 stipulate the price, which must be the reasonable market value of the property. "Reasonable market value" for these purposes means the average of written valuations of two estate agents (selected by the grantor) carrying on business in the magisterial district of Happyland). Copies of the valuations must be attached to the offer or the price which grantor is prepared to accept from a third party; (5)

## 2.3 ACCEPTANCE BY GRANTEE

Acceptance of the offer by the grantee must be:

2.3.1 in writing; (1)
2.3.2 unconditional, save that the grantee may stipulate that payment of the price will be subject to first obtaining a loan against the security of a first mortgage bond over the property. (1)

## QUESTION 3 [6]

3.1 It is not possible to sign for a trust still to be established (1). After the trust is created the trustee must first receive letters of authority / appointment to act (1).
3.2 If, within three months from the date of incorporation of the company (1), the buyer has not been incorporated (1), or having been incorporated has failed for any reason to adopt this agreement (1) then A will personally be deemed to be the buyer in terms of the agreement (1).

## QUESTION 4 [8]

4.1 Those assets vest in the Master (1) and then in the trustee (1). Spouse may obtain release (1) by proving his ownership usually by affidavit (1) and if necessary by High Court application (1). Section 24 of Insolvency Act (5)
4.2 Spouses of a marriage in community of property remain bound and liable for debts incurred during the subsistence of the marriage, (1) after the dissolution of the marriage, subject to the proviso that the debts were incurred with the requisite lawful consent of both parties. (1) See generally **BP South Africa (Pty) Ltd v Viljoen en 'n ander 2000 (5) SA 630 (O)**. (1) (3)

**TOTAL: [100]**

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

5