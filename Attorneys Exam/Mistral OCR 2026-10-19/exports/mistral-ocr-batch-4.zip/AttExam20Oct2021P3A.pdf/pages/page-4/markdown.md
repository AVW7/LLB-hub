commission. He must be sure that the purchaser who approaches him directly has not in fact been introduced by an agent. In addition, it is likely that if the seller sells directly, he will have discussed a reduction in the purchase price because he will be relieved of paying commission. These factors must be taken into consideration. The answer should be along the lines:

1.2.1.1 The purchaser confirms that this contract was entered into without the purchaser having been introduced to the seller directly or indirectly (½) by any estate agent and that no agent was the effective cause for the conclusion of this contract of sale (½).

1.2.2.2 As a result of the sale by the seller to the purchaser on these grounds (½) the purchase price has been reduced by an amount equal to the expected agent's commission (½).

1.2.2.3 The purchaser consequently indemnifies the seller (½) against any legitimate claim which may be brought against the seller for agent's commission arising from this sale (1). The seller shall call upon the purchaser to assist the seller in any actual or threatened litigation arising from any claim for commission and shall put the seller in funds to do so (½). The seller shall however be free to decide on the best manner of settlement of any such action (½). Any costs or charges including legal fees on all scales and any capital sum payable shall be recoverable from the purchaser as liquidated damages (½).

1.3.1 Yes (1). In terms of Section 29A of the Alienation of Land Act (the cooling-off clause) he may cancel the agreement within 5 days (1).

### 1.3.2 PURCHASER'S RIGHT TO CANCEL

Subject to the provisions of Section 29A of the Alienation of Land Act No. 68 of 1981, the purchaser is entitled to cancel this agreement; (1)

a. by way of a written notice, (1)

b. delivered to the seller or its agent, (1)

c. within 5 (five) days of signature of this agreement by the purchaser. (1) Provided that the notice; (1)

a. is signed by the purchaser or its agent authorised in writing, (1)

b. clearly identifies this agreement; (1)

c. and is unconditional. (1)

## QUESTION 2 [14]

[14]

### PROHIBITION ON ALIENATION

2.1 The grantor may not alienate the property for a period of thirty (30) days after informing the grantee of an offer which the grantor is prepared to accept unless (1)

---*LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

4