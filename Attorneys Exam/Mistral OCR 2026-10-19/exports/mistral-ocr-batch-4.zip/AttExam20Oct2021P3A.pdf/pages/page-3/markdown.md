5.2.3 The attorney is liable to make good any trust shortfall (1). If the bank goes insolvent, he would be liable to repay all monies due to the trust creditor (1).

5.3 No. The attorney can institute a claim as a concurrent creditor in the insolvent estate of the bank (1).

## **QUESTION 6**

**[6]**

An attorney who has allowed a claim to prescribe in his hands should:

6.1 Inform the client of the fact at once; (1)

6.2 Advise the client to consult another attorney regarding his rights in respect of both the prescribed claim and subsequent action; (1)

6.3 Not admit liability in order not to vitiate insurance cover with the LPIIF and his own insurers; (1)

6.4 Report the full facts to the LPIIF and private insurer; (1)

6.5 Consider whether it may be wise to settle the matter himself if the amount is not too high and if there may be contributory negligence; (1)

6.6 Co-operate with the attorneys for the insurers; (1)

6.7 There is no need to report the claim to the LPC but if there is a complaint, then he must respond. (1)

***Any of the above to a maximum of 6 marks.***

## **SECTION B**

### **QUESTION 1**

**[25]**

#### **1.1.1 SUSPENSIVE CONDITION (1)**

This agreement is conditional upon the purchaser obtaining a bond for 80% of the purchase price from a financial institution (1), within 30 days from date hereof (1). If the bond is not obtained this agreement shall be null and void (1) and neither party shall have any claim against the other arising here from (1).

#### **1.1.2 RESOLUTIVE CONDITION (1)**

Should the purchaser be advised in writing (1) that his application for a bond for 80% of the purchase price has been unsuccessful or should the purchaser not be successful in obtaining the said bond within 21 days from date of signature hereof (1) this agreement shall terminate (1) and each party shall, insofar as any terms of this agreement have been implemented, be obliged to restore the other into the same position as he would have been had the agreement never been concluded (1).

1.2.1 The issue involved in this question is the indemnity of the seller by the purchaser. If the seller has employed agents and is likely to be responsible towards them for

*LAW SOCIETY OF SOUTH AFRICA*
*LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

3