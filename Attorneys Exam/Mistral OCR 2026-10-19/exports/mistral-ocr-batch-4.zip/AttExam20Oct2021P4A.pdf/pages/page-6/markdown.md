|  Cash – Smith |  | 9 000  |
| --- | --- | --- |
|  EFT TO Smith | 820 |   |
|   | 9 000 | 9 000  |

1 mark each for correct dr and cr entry = 11 marks

# **QUESTION 4**

**[10]**

# **SUPPLEMENTARY CASH BOOK FOR DECEMBER 2020 ½**

|  Balance | 1/2 | 100 000 |  |  |   |
| --- | --- | --- | --- | --- | --- |
|  Interest | 1 | 3 000 | Mtn 1 |  | 54  |
|  Deposit | 1 | 60 000 | Balance B/D | 1/2 | 226 930  |
|  Deposit | 1 | 63 984 |  |  |   |
|   |  | 226 984 |  |  | 226 984  |
|  Balance C/F | 1/2 | 226 930 |  |  |   |
|  Total marks 6 |  |  |  |  |   |

# **BANK RECONCILIATION STATEMENT AT 31 DECEMBER 2020 (1/2)**

|  Bank statement balance | 1 |  | 41 301  |
| --- | --- | --- | --- |
|  Less : Bank error | 1 | 24 673 |   |
|  OUTSTANDING DEPOSIT | 1 |  | 210 302  |
|  Balance as per cash book |  | 226 930 (1/2) |   |

Total marks (4)

**TOTAL: [100]**

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6