# **ADMISSION EXAMINATION  
LEGAL PRACTITIONERS' BOOKKEEPING  
PART 4**

**20 OCTOBER 2021**

**MEMORANDUM**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

**QUESTION 1**

**[40]**

# **TRUST CASH BOOK**

|  Dr |  |  | Cr  |
| --- | --- | --- | --- |
|  S (T) | 300 000.00 | S(T) | 27 750.00  |
|  S (T) | 64 750.00 | V(T) | 5 000.00  |
|  V (T) | 5 000.00 | V(T) Agent | 100 000.00  |
|  S (T) | 1 650 000.00 | V(T) Agent | 20 000.00  |
|   |  | BCB | 37 000.00  |
|   |  | V(T) | 1 830 000.00  |

|  DT | BUSINESS CASHBOOK | CT  |
| --- | --- | --- |
|  TCB | 37 000.00 |   |

# **THE TRUST LEDGER ACCOUNTS**

|  DT | VIKI (T) |  | CT  |
| --- | --- | --- | --- |
|  TCB | 5000.00 | TCB | 5000.00  |
|  TCB | 100 000.00 | S (T) | 300 000.00  |
|  TCB | 20 000.00 | S (T) | 1 650 000.00  |
|  TCB | 1 830 000.00 |  |   |
|   | 1 955 000.00 |  | 1 955 000.00  |

LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1