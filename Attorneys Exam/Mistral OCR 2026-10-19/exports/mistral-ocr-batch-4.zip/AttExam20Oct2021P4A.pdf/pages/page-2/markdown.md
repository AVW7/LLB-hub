|  DT | SILA (T) |  | CT  |
| --- | --- | --- | --- |
|  V (T) | 300 000.00 | TCB | 300 000.00  |
|  V (T) | 1 650 000.00 | TCB | 64 750.00  |
|  TCB – SARS | 27 750.00 | TCB | 1 650 000.00  |
|  S (B) | 37 000.00 |  |   |
|   | 2 014 750.00 |  | 2 014 750.00  |

### **THE BUSINESS LEDGER ACCOUNTS**

|  DT | SILA (B) |  | CT  |
| --- | --- | --- | --- |
|  Fees | 28 000.00 | S (T) | 37 000.00  |
|  Fees | 9 000.00 |  |   |
|   | 37 000.00 |  | 37 000.00  |

|  DT | FEES (B) |  | CT  |
| --- | --- | --- | --- |
|   |  | S (B) | 28 000.00  |
|   |  | S (B) | 9 000.00  |

**1 mark each entry (30)**

### **THE JOURNALS**

|   | Fee Journal | DT | CT  |
| --- | --- | --- | --- |
|   | SILA (B) | 28 000.00 |   |
|   | Fees |  | 28 000.00  |
|   | Fees Earned |  |   |
|   | SILA (B) | 9 000.00 |   |
|   | FEES |  | 9 000.00  |
|   | FEES EARNED |  |   |

|   | Transfer Journal | DT | CT  |
| --- | --- | --- | --- |
|   | SILA (T) | 37 000.00 |   |
|   | SILA (B) |  | 37 000.00  |
|   | TRANSFER FEES |  |   |
|   | TRUST JOURNAL |  |   |
|   | SILA (T) | 300 000.00 |   |
|   | VIKI (T) |  | 300 000.00  |
|   | SILA (T) | 1 650 000.00 |   |
|   | VIKI (T) |  | 1 650 000.00  |
|   | TRANSFER OF SALE PROCEEDS |  |   |

**2 marks for each journal entry (10)**

**TOTAL: 40 MARKS**

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2