# **QUESTION 3**

**[40]**

|  DR | TRUST CASH BOOK | CR  |
| --- | --- | --- |
|  Correspondent(T) | 3 120 Transfer to business | 2300  |
|   | EFT to Sam | 820  |

|  DR | BUSINESS CASH BOOK | CR  |
| --- | --- | --- |
|  Transfer from trust | 2300 |   |

|  DR | SAM TRUST ACCOUNT | CR  |
| --- | --- | --- |
|  Correspondent - Fees vat and disbursement | 8180 Correspondent (T) | 9 000  |
|  Bank self | 820 |   |

|  DR | CORRESPONDENT – TRUST LEDGER | CR  |
| --- | --- | --- |
|  Sam transfer | 9 000 TCB | 3 120  |
|  Transfer to business | 2300 Sam – Fees vat and disbursement | 8 180  |

|  DR | FEE ACCOUNT | CR  |
| --- | --- | --- |
|   | Correspondent(B) | 2000  |

|  DR | CORRESPONDENT BUSINESS LEDGER | CR  |
| --- | --- | --- |
|  1/3 allowance fee | 2300 Transfer from trust | 2300  |

|  DR | VAT | CR  |
| --- | --- | --- |
|   | Correspondent(B) | 300  |

**1 mark for each correct cash book and ledger entry = 15 marks**

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4