|   | Dr | Cr  |
| --- | --- | --- |
|  **TRUST JOURNAL** |  |   |
|  Correspondent(T) | 9 000 |   |
|  Client Sam(T) |  | 9 000  |
|  Being cash collected |  |   |
|  **TRUST JOURNAL** |  |   |
|  Client Sam(T) | 8 180 |   |
|  Correspondent (T) |  | 8180  |
|  Being fees vat and disbursement |  |   |
|  **FEE JOURNAL** |  |   |
|  Correspondent (B) | 2 300 |   |
|  Fees |  | 2 000  |
|  VAT |  | 300  |
|  Being allowance |  |   |
|  **TRANSFER JOURNAL** |  |   |
|  Correspondent(T) | 2 300 |   |
|  Correspondent (B) |  | 2300  |
|  Being transfer from trust ledger to business ledger |  |   |

**1 mark for each correct dr and cr journal entry and narration = 13marks**

**1/2 mark each identifying correct journal = 2 marks**

#### **ACCOUNTING STATEMENT TO CLIENT SAM**

|  Self v Smith – Fees | 1500  |
| --- | --- |
|  Disbursement | 200  |
|  VAT | 225  |
|  Sam – divorce - Fees | 1500  |
|  Disbursement | 480  |
|  VAT | 225  |
|  Self v Smith – Fees | 3000  |
|  Disbursement | 600  |
|  VAT | 450  |

LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5