QUESTION 2

[10]

|  Trust Cash Book  |   |   |   |
| --- | --- | --- | --- |
|  Mr Speedster | 30000.00 | Transfer | 20000.00  |
|  |   |   |   |
|  Business Cash Book  |   |   |   |
|  Transfer | 20000.00 | Mr Speedster (Business Ledger) | 20000.00  |
|  Mr Speedster (T/L)  |   |   |   |
|  Transfer | 20000.00 | Trust Cash Book | 30000.00  |
|  Mr Speedster (B/L)  |   |   |   |
|  Business Cash Book | 20000.00 | Transfer | 20000.00  |
|  **Transfer Journal** |   |  |   |
|  Mr Speedster (T/L) |   | 20000.00 |   |
|  Mr Speedster(B/L) |   |  | 20000.00  |
|  Being Transfer from trust to business |   |  |   |
|  |   |   |   |
|  **Cash may be withdrawn from Bank over the counter or by ATM Note to marker: (1) mark for each cash book & ledger entry =(8) marks** |   |   |   |
|  **(1) mark each for journal entries = 2 marks** |   |   |   |
|  **Total = 10 marks** |   |   |   |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3