## DISTRIBUTION ACCOUNT

Balance available for distribution

2 841 882,70[1]

Awarded to B Surviving spouse:

one half by virtue of her marriage in

community of property

1 420 941,35[1]

and the other half in terms of

Clause 1.1 of the Will [1]

read together with section 2C(1) of

the Wills Act 7 of 1953, as amended [1]

1 420 941,35[1]

The above award is made up of:

Immovable Property – 1 700 000,00 [1]

Movable Property – 420 000,00 [1]

Cash surplus - 721 882,70[1]

2 841 882,70

2 841 882,70

## INCOME AND EXPENDITURE ACCOUNT

Interest on Fixed Deposit with Capitec Bank

6 000,00 [1]

Interest on Bond in favour of Absa Bank

4 000,00 [1]

Executors fees 6%

360,00 [1]

Balance awarded to B as sole heir [1]

1 640,00 [1]

6 000,00

6 000,00

## FIDUCIARY ASSETS ACCOUNT

None

NIL [1]

## ESTATE DUTY ADDENDUM

Assets of the deceased as per

the Liquidation Account

3 662 780,00 [1]

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3