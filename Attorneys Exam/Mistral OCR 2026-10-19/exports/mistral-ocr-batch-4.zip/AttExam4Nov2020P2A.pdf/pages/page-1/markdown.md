# **ADMISSION EXAMINATION  
ESTATES  
PART 2**

**4 NOVEMBER 2020**

**MEMORANDUM**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE  
A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF  
READING.**

**NOTE TO EXAMINER:** *THIS GUIDELINE RECORDS THE VIEWS OF THE DRAFTERS. THERE MAY BE JUSTIFIABLE VARIATIONS IN PRACTICE WHICH ARE BROUGHT OUT IN THE ANSWERS. WHEN THIS HAPPENS THE EXAMINER SHOULD APPLY HIS DISCRETION IN MARKING THE ANSWER.*

# **QUESTION 1**

**[59]**

First and Final Liquidation and Distribution Account in the Estate of the Late A (Identity No. 601214 5185 08 7) [1] married in Community of Property to B (Identity No. 650419 0123 08 5) [1] who died on 13 March 2019 [1].

Master's Reference No. 6714/2019 [1]

# **LIQUIDATION ACCOUNT**

# **ASSETS**

# **IMMOVABLE PROPERTY**

Erf 2124 Ethekweni, Registration

Division ET Province of Kwazulu

Natal in extent 1000 (One Thousand)

Square metres

Held under Deed of Transfer No. T 1217/84 [1]

At valuation (1) 1 700 000,00 [1]

Awarded as per the Distribution Account [1]

# **MOVABLE PROPERTY**

Honda Ballade – ND 662-144

At valuation (2) 260 000,00 [1]

House hold contents at valuation (3) 160 000,00 [1]

Awarded as per the Distribution Account [1]

Capitec fixed deposit Account No.

0014217X (4) 500 000,00 [1]

**LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™**

1