1.

I bequeath my entire estate to my 3 children per stipes [2].

2.

I nominate and appoint JACK MABASO, a practising Attorney of the firm MABASO & ASSOCIATES to be the Executor of my estate [1], and if he does not survive me then I appoint any remaining partner of the firm MABASO & ASSOCIATES to be the Executor of the estate [1]. I grant my Executor the power of assumption [1]. I direct that my said Executor shall not be required to give security [1].

3.

I direct that a receipt signed by the guardian in respect of any loose assets bequeathed to a minor beneficiary shall be sufficient to discharge my Executor and the Master of the High Court [1]. I direct that the guardian shall be exempted from the provision of security.

4.

I nominate and appoint STEWART and JULIA SOSIBA, presently of NO 28 FULLAM STREET, CONSTANTIA, PORT ELIZABETH, or the survivor of them to be the guardians on any of my minor children should they survive me [1]. If the said STEWART and JULIA SONJI do not survive me I hereby appoint BONGI SOSIBA to be the guardian of my minor children [1]. I direct that the said guardians shall not be required to furnish security in that capacity to the Master of the High Court [1].

5.

All bequest in terms of this Will and / or any codicil thereto shall be excluded from Community of Property [1]. A receipt signed by a married beneficiary without the assistance of his / her spouse shall be sufficient discharge to my Executor [1].

SIGNED AT PORT ELIZABETH on the 12th June 2020 in the presence of the undersigned witnesses who were present and signing at the same time and in the presence of each other [2].

# AS WITNESSES

TESTATRIX [1].

1. [1].
2. [1].

# QUESTION 4

[3]

(1) Masters representative does not have to open a Bank Account – Section 28 [1].
(2) does not have to place statutory notices. Section 29 and 35(5) [1].
(3) need not to lodge a liquidation and distribution account Section 35 [1].

TOTAL: [100]

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6