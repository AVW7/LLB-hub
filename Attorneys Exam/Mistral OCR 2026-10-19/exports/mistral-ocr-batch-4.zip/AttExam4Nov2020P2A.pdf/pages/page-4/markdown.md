LESS Adjustment on valuation of shares

|  in XYZ | 4 000,00 [1] |   |
| --- | --- | --- |
|  Proceed of Standard Bank Policy | 66 000,00 [1] |   |
|  Proceeds of Old Mutual Policy | 850 000,00 [1] | 920 000,00  |
|   |  | 2 742 780,00  |
|  LESS surviving spouses ½ share |  | 1 371 390,00 [1]  |
|   |  | 1 371 390,00  |
|  ADD deemed property  |   |   |
|  Standard Bank Policy | 66 000,00 [1] |   |
|  Old Mutual Policy | 850 000,00 [1] |   |
|  Sanlam Policy | 2 000 000,00 [1] |   |
|  Momentum Policy | 961 840,00 [2] | 3 877 840,00  |
|  Gross value of Estate |  | 5 249 230,00  |
|  LESS ½ liabilities | 820 897,30 | 410 448,65 [1]  |
|  Section 4(q) : |  |   |
|  Sanlam Policy | 2 000 000,00 [1] |   |
|  Inheritance | 1 420 941,35 [1] | 3 831 390,00  |
|  Net value of Estate |  | 1 417 840,00  |
|  LESS rebate in terms of Section 4A |  | 3 500 000,00 [1]  |
|  Dutiable Amount |  | NIL [1]  |
|  Therefore no Estate Duty payable.  |   |   |

### EXECUTOR'S CERTIFICATE

I, the undersigned declare that this final account is to the best of my knowledge and belief a true and proper account of the liquidation and distribution of the estate[1] and all assets and income collected subsequent to the date of death to the date of this account have been disclosed thereon. [1]

EXECUTOR

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4