|  Interest accrued up to date of death |  | 11 000,00 [1]  |
| --- | --- | --- |
|  Style Bank : Account No. 334982/Y | (5) | 16 780,00 [1]  |
|  Proceeds of Standard Bank Insurance |  |   |
|  Policy No. 1146922 | (6) | 66 000,00 [1]  |
|  Proceeds of Old Mutual Insurance |  |   |
|  Policy No. OM62174 | (7) | 850 000,00 [1]  |
|  Proceeds of Sale of shares in |  |   |
|  XYZ (Pty) Ltd |  | 90 000,00 [1]  |
|  Proceeds of sale of shares in PQR |  |   |
|  Limited | (8) | 9 000,00 [1]  |
|  Total Assets |  | 3 662 780,00  |

### **LIABILITIES**

|  Administration Expenses | (9) | 30 000,00 [1]  |
| --- | --- | --- |
|  Master's fees (maximum) | (10) | 7 000,00 [1]  |
|  Executor's fees (3.5% of 3 662 780,00) | (11) | 128 197,30 [1]  |
|  Absa bond | (12) | 570 000,00 [1]  |
|  Standard Bank Credit Card | (13) | 66 000,00 [1]  |
|  SARS final assessment | (14) | 19 700,00 [1]  |
|  Total liabilities |  | 820 897,30 [1]  |
|  Balance available for distribution |  | 2 841 882,70  |
|   |  | 3 662 780,00  |

### **RECAPITULATION STATEMENT**

|  Cash and assets reduced to cash |  |   |
| --- | --- | --- |
|  (Items 4,5,6,7, 8 and 9) |  | 1 542 780,00[2]  |
|  Liabilities | 820 897,30[1] |   |
|  Surplus | 721 882,70[1] |   |
|   | 1 542 780,00 | 1 542 780,00  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2