QUESTION 2

[20]

Zanele, the wife is entitled to half share of the joint estate by virtue of the marriage in community of property in the amount of R1 488 000.00 [1]

The deceased's half share of R1 488 000.00 devolves as follows:

If the unborn child is born alive, Zanele, Andy, Daniel, Caroline, Rose and the unborn child (nasciturus rule) are the intestate heirs. [1]

Zanele inherits a child's share or R250 000.00 whichever amount is the greater. [1]

A child's share amounts to R1 488 000.00 ÷ 6 = R248 000.00 [1]

Zanele will therefore inherit the greater amount of R250 000.00 [1]

The descendants inherit the remainder thereof of R1 238 000.00 [1] in terms of Section 1(1)(c)(ii) of the Intestate Succession Act as follows:

Since Andy murdered Paul, Andy does not inherit (die bloedige hand erf niet) [1]

In terms of section 1(7) of the Intestate Succession Act, Ben will inherit Andy's share in the amount of R247 600.00 [1]

As Caroline has renounced her inheritance, the surviving spouse Zanele receives her (Caroline's) portion in terms of section 1(6) of the Intestate Succession Act in the amount of R247 600.00 [1] and will therefore inherit a total amount of R497 600.00 [1]

Rose will inherit the amount of R247 600.00 [1]

Daniel will inherit the amount of R247 600.00 [1]

The unborn child will also inherit the amount of R247 600.00 [1]

If the unborn child is not born alive, then

A child's share will amount to R1 488 000.00 ÷ 5 = R297 600.00 [1]

Zanele will therefore inherit the child's share in the amount of R297 600.00 [1]

As Caroline has renounced her inheritance, the surviving spouse Zanele receives her (Caroline's) portion in terms of section 1(6) of the Intestate Succession Act in the amount of R297 600.00 and will therefore inherit a total amount of R595 200.00 [1]

Ben, Daniel and Rose will each inherit R297 600.00 [1]

Eric and Judy will not inherit anything because descendants inherit before ascendants [1]

Letta Ntuli will not inherit anything because she was not formally adopted by Paul [1]

Dennis and George will not inherit by way of representation as their parents are still alive [1]

QUESTION 3

[18]

# LAST WILL AND TESTAMENT

I, PAMELA MALI (born SOSIBA) a divorcee, hereby revoke, cancel and annual all and any testamentary acts and / or disposition heretofore made by me, either jointly or singly and declare this to be my last will and Testament. [1]

LAW SOCIETY OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5