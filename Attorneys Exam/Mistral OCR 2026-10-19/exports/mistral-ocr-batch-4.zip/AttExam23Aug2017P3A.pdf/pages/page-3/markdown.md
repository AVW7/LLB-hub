She must further provide:

a) the name of the bank where the trust will operate its account;
b) the name and address of the person who will keep and maintain the records of the trust;
c) occupation of trustees;
d) previous experience of trusteeship;

The master also has a number of further requirements should he be requested to waive his right to insist on security by the trustees.

# QUESTION 4

[20]

If a trader transfers of a business (or part thereof) belonging to him and

4.1 * he does not publish notice of the intended disposition;

* in the Government Gazette; and
* two issues of local newspapers (one in English and one in Afrikaans) in the district where the business is conducted;
* circulating in the district where the business is conducted;
* not less than 30 days; and
* not more than 60 days before the date of transfer;

4.2 the transfer shall be void as against his creditors;

* for a period of six months after such transfer; and
* and shall be void as against the trustee of his estate if his estate is sequestrated within the six month period.

The section is intended to prevent traders in financial difficulties disposing of their business whereafter the trader can spend the purchase price and the purchaser can liquidate the assets to the detriment of creditors. (10)

4.3 Accordingly the intending purchaser is concerned that if the sale is not advertised –

* the sale may be void and he may not become the owner;
* and should you be sequestrated he will have paid (or must pay) the price and receive nothing.

As soon as any of the notices appear all your liquidated liabilities in connection with the business become due forthwith. Creditors are entitled to demand immediate payment subject only to deduction of interest on amounts not yet otherwise due. (10)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3