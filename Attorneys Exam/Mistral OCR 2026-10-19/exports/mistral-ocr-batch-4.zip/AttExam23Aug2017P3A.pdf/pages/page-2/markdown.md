4. Marriage out of community of property with the inclusion of the accrual system:

If the parties choose this system they are married out of community of property but they share accruals at the end of the marriage. The nett value of the parties estates are calculated and agreed before the date of marriage. The parties may agree that certain assets and any increase or growth thereon be excluded from the accrual. During the marriage the spouses have separate estates with which they can deal without the consent of the other. At the end of the marriage by way of death or divorce the accruals of each spouse's estate is calculated and equalisation takes place so that the spouses have equal accruals. (7)

# QUESTION 2 [13]

1. In order to exercise your option effectively the attached document exercising the option, should be signed and dated in the presence of two witnesses. If the option may be exercised through the post it will be regarded as having been exercised on the date of posting depending on how the wording of the option is interpreted e.g. implying that the exercising must reach the grantor before the expiry date.

In all the circumstances you should rather ensure that the attached exercising of the option actually reaches the grantor before expiry date. You should therefore telefax the document to the grantor (if possible) AND then send it by courier to the agreed address to ensure that it is timeously received.

# EXERCISE OF OPTION

I, the undersigned, your client, Id, full names and marital status do hereby exercise the option granted to me by Mrs Seller on _______________ (date) to purchase stand _______________ (full description of property) together with all improvements subject to the terms and conditions set forth in the option.

Signed at Cape Town on this _______________ day of _______________ 2009.

As Witnesses:

1.
2.

Grantee/option holder/purchaser

# QUESTION 3 [8]

The trust will be registered with the Master of the High Court in the area where Mrs B resides. She must lodge:

a) Two copies of the deed of trust;
b) Letter of undertaking from an auditor/accountant to act; (J405)
c) Acceptance of trusteeship by the trustees. (J417)
d) Certified copies of the id's of the trustees.
e) Proof of payment of prescribed fee (R100 currently).
f) Prescribed Master's Trust Registration and amendment form. (J401)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2