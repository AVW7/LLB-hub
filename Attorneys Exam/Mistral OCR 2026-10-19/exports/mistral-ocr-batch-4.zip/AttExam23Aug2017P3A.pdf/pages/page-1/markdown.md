# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
ATTORNEYS' PRACTICE / PROKUREURSPRAKTYK
PART 3 / DEEL 3

23 AUGUST / 23 AUGUSTUS 2017

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A
CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable
variations in practice which are brought out in the answers. When this
happens the examiner should apply his discretion in marking the answer.

# QUESTION 1

[25]

1. The letter should state that:
1.1 The couple can choose the matrimonial property law regime that will apply to their marriage. (1)
1.2 There are 3 (three) regimes from which they can choose namely, a marriage in community of property, a marriage out of community of property with the application of the accrual system in terms of the Matrimonial Property Act 88/1984; and a marriage out of community of property with the exclusion of the accrual system. (3)
1.3 All marriages are in community of property, unless community is excluded by an Antenuptial Contract executed before a Notary Public before the date of marriage. (1)
2. In community of property:

In a marriage, in community of property, all property brought into the marriage and all
property acquired after the marriage falls into the joint estate unless specifically
excluded e.g. gifts and inheritances. All debts incurred before and after the marriage
can be recovered from the joint estate. The husband and wife are co-owners of the
joint estate. (7)

3. Marriage out of community of property with the exclusion of the accrual system:

The parties may exclude community of property by way of an Antenuptial Contract.
When this is done each spouse retains his or her assets and is liable for his or her
debts. At the end of the marriage by death or divorce each party will retain his or her
assets. It should be pointed out that unless the accrual system is expressly excluded in
the Antenuptial Contract it will apply. (6)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]℠

1