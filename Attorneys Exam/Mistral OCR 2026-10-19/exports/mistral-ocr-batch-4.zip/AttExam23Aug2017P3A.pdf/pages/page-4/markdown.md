QUESTION 5

[15]

5.1 The difference between a suspensive condition and a resolutive condition is that a suspensive condition suspends the operation of the obligations flowing from the contract until the occurrence of a future uncertain event, whereas a resolutive condition terminates the obligations flowing from the contract upon the happening of a future uncertain event. (5)
5.2.1 This agreement is conditional upon the purchaser obtaining a bond for \(80\%\) of the purchase price from a financial institution, within 30 days from date hereof. If the bond is not obtained this agreement shall be null and void and neither party shall have any claim against the other arising herefrom. (5)
5.2.2 Should the purchaser be advised in wiring that his application for a bond for \(80\%\) of the purchase price has been unsuccessful or should the purchaser not be successful in obtaining the said bond within 30 days from date of signature hereof this agreement shall terminate and each party shall, insofar as any terms of this agreement have been implemented, be obliged to restore the other into the same position as he would have been had the agreement never been concluded. (5)

# QUESTION 6

[10]

6.1 Once your client is under cross examination you may not consult with him at all. The reason for this is obvious namely that you may advise him how to answer questions or how to rectify evidence already given. (3)
6.2 The secretary may interview the client to take formal instructions. In all other cases this should not happen because the client is entitled to professional advice and service. (4)
6.3 Yes in very limited circumstances, e.g. to the client's executor after his death and to his curator if the client is placed under curatorship. Of course if the client waives his confidentiality the information may be disclosed. (3)

# QUESTION 7

[9]

An attorney may act on a contingency basis, namely that if his client succeeds he will be entitled to a success fee which will not exceed twice his attorney and client fee and shall not be more than 25% of the amount recovered by way of a Court Order or settlement, if the client is not successful the attorney will receive no fees. Before an attorney may act on a contingency basis he must comply with the requirements of the Contingency Fees Act and in particular must enter into a written agreement with the client which must comply with all the requirements of the Act.

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4