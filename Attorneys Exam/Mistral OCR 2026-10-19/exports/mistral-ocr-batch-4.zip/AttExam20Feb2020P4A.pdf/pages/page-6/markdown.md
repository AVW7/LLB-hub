# ACCOUNT TO BALOYI

EFT You 1 000 000

EFT You 500 000

Inv ABSA 1 000 000

ABSA 1 100 000

Capitec Bank 7 000 000

Paid SARS 300 000

Paid Fidelity Fund 5 000

Paid You 95 000

Paid Fees 200 000

By Lender 2 000 000

Paid Mabuza 10 000 000

11 600 000 11 600 000 (6)

# QUESTION 5

[10]

5.1 No. (1)

5.2 Draw cash from your Business Account, pay the Bail, thereafter transfer the amount paid for bail from your Trust Account. (3)

5.3.1 monthly

5.3.2 quarterly

5.3.3 yearly (3)

5.4 When the business monies are part of "MIXED" monies (Trust & Business). Thereafter the monies are transferred from Trust to Business. (3)

TOTAL: [100]

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

6