**Business Journal**

The Business Journal is used to record the entries to be made to record the **money value of any non-cash**

**Business transactions (1)**

The narration would describe the nature of the transaction (1) **(2)**

**QUESTION 2**

**[20]**

**1 Fees Journal (1)**

|  Client Business account | 5 750 (1)  |
| --- | --- |
|  Fees account | 5 000 (1)  |
|  Output Vat | 750 (1)  |
|  Fees in respect of professional Services (1) | **(5)**  |

**2 Trust Journal (1)**

|  Sipho Trust account | 8 000 (1)  |
| --- | --- |
|  Madaline Trust account | 8 000 (1)  |
|  Transfer of incorrect entry (1) | **(4)**  |

**3 Transfer Journal (1)**

|  Anthony Trust account | 22 000 (1)  |
| --- | --- |
|  Anthony Business account | 22 000 (1)  |
|  Transfer of fees and disbursements (1) |   |

The balances after the transfer are

- Trust account credit Rnil (1)
- Business account debit R11 000 (1) **(6)**

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2