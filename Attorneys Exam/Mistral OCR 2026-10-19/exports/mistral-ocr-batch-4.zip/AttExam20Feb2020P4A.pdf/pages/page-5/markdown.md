# ABSA BANK (S86 (4))

# BALOYI

|  16/7 Cash | 1 000 000 | 2/8 Cash | 1 100 000  |
| --- | --- | --- | --- |
|  2/8 Cash | 5 000 |  |   |
|  2/8 Cash | 95 000 |  |   |

# TRUST LEDGER

# LENDER

|  2/8 Baloyi | 2 000 000 | 1/7 Bal | 3 000 000  |
| --- | --- | --- | --- |
|  FEES  |   |   |   |
|   |  | 2/8 Baloyi | 200 000  |

(1 mark each entry)

# **Business Journal**

Baloyi Dr 200 000

Fees Cr 200 000

Fees on Transfer of property Mabuza

(3)

# **Trust Journal**

Lender Dr 2 000 000

Baloyi Cr 2 000 000

(3)

Being loan on Second Bond

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

5