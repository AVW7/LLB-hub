QUESTION 4

[40]

# TRUST CASH BOOK

|   | Balance | 3 000 000 | 16/7 | ABSA | 1 000 000  |
| --- | --- | --- | --- | --- | --- |
|  16/7 | Baloyi | 1 000 000 | 17/7 | SARS | 300 000  |
|   | Baloyi | 500 000 | 2/8 | Mabuza | 10 000 000  |
|  2/8 | Capitec | 7 000 000 | 2/8 | Fidelity Fund | 5 000  |
|  2/8 | ABSA | 1 100 000 | 2/8 | Baloyi | 95 000  |
|   |  |  | 2/8 | Transfer | 200 000  |
|   |  |  |  | Balance | 1 000 000  |
|   |  | 12 600 000 |  |  | 12 600 000  |

# BUSINESS CASH BOOK

|  2/8 | Transfer | 200 000  |
| --- | --- | --- |

# TRUST LEDGER

|   |  | BALOYI |  |  |   |
| --- | --- | --- | --- | --- | --- |
|  17/7 | Cash | 300 000 | 16/7 | Cash | 1 000 000  |
|  2/8 | Cash | 10 000 000 |  | Cash | 500 000  |
|  2/8 |  | 200 000 | 2/8 | Lender | 2 000 000  |
|   |  |  |  | Cash | 7 000 000  |

# BUSINESS LEDGER

|   |  | BALOYI |  |  |   |
| --- | --- | --- | --- | --- | --- |
|  2/8 | Fees | 200 000 | 2/8 | Cash | 200 000  |

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

4