# **4 Business. / Private Journal (1)**

Motor Vehicle

230 000 (2)

Fincor

230 000 (1)

Purchase of Toyota as per financing agreement (1) **(5)**

# **QUESTION 3**

**[15]**

|  Supplementary Cash Book for June 2019 ½ |   |   | 15  |
| --- | --- | --- | --- |
|  Balance | 40 000✓ | Debit Order | 28 236✓  |
|  Interest | 3 900✓ | Bank Charges | 2 000✓  |
|  Correct deposit | 25 360✓ | Error deposit | 25 630✓  |
|  EFT | 45 000✓ | Balance | 58 394✓  |
|   | 114 260 |  | 114 260  |

# **Bank reconciliation statement as at 30 June 2019 ½**

Balance as per bank statement 5 000✓

Less: Outstanding eft 14 000✓

Subtotal 19 000

Plus:Outstanding deposit 11 000✓

Subtotal 30 000

Add: Outstanding deposit 41 000✓

Subtotal 71 000

Less: Bank error trust deposit 12 606✓

Balance as per cash book 58 394✓

LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3