# **ADMISSION EXAMINATION / TOELATING SEKSAMEN  
LEGAL PRACTITIONERS' BOOKKEEPING /  
REGSPRAKTISYNSBOEKHOU  
PART 4 / DEEL 4**

**20 FEBRUARY / FEBRUARIE 2020**

**ANSWERS / ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

*NOTE TO EXAMINER: This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

# **QUESTION 1**

**[15]**

A journal is a book of prime entry which is used to record the money value of non-cash transactions. (1)

# **Fees Journal**

The fees Journal is used to record the money value of the professional services rendered to a client. (1). The client's **Business ledger account** will be debited (1) with the fee to be charged and the **Fees account** (1) will be credited. The **Output Vat account** will be credited (if applicable) (1) A narration would describe the nature of the transaction. (1) (5)

# **Transfer Journal**

The Transfer Journal is used to transfer the **money value** (1) (not cash) from the **client's Trust ledger account** (1) to the **same client's Business ledger account** (1). The narration would describe the reason for the entry (1) (4)

# **Trust Journal**

The Trust Journal is used to transfer value from **one client's Trust ledger account** (1) to **another client's Trust ledger account** (1). The narration would describe the reason for the transfer (1). (3)

---*LAW SOCIETY OF SOUTH AFRICA  
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

1