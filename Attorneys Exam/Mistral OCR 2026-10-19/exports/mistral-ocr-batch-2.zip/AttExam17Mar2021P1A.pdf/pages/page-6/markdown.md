**8.3.1** Section 300 of CPA:

A court may award compensation where an offence has caused damage to or loss of property (1).

The injured person or prosecutor acting on instructions of the injured party (1) has to apply to the court to award the injured party compensation for such damage or loss (1).

The complainant may claim hospital and medical expenses, loss of wages and general damages (1).

*(Any three will be marked correct)*

[3]

**8.3.2** In determining the amount of compensation, the court may refer to evidence and the proceedings at the trial (1) or hear further evidence either upon affidavit or orally (1).

[2]

**8.3.3** The effect of the award is that of a civil judgment of that court (1) and the injured person as all the civil remedies at his / her disposal in order to recover the award (1).

[2]

**QUESTION 9**

[5]

WITHDRAWALS:

A charge may be withdrawn only before an accused pleads to a charge (1). After the withdrawal, the accused shall not be entitled to a verdict of acquittal in respect of that charge. (1)

STOPPING PROSECUTIONS:

It can be done any time after an accused has pleaded but before conviction (1). The court must then acquit the accused in respect of that charge (1).

DIFFERENCE BETWEEN THE TWO:

After a matter had been withdrawn, one can be prosecuted of the same charge again. That is not the position when prosecution had been stopped (1).

**QUESTION 10**

[4]

10.1 The Plaintiff should lead evidence by an expert as to the cost of repairs to the motor vehicle. (2)

10.2 The points to be dealt with are: the nature of his experience, that he has examined the motor vehicle, and what he estimates the cost of repairing the motor vehicle. (1)

10.3 The Plaintiffs' attorney must give 15 days' notice of his intention to lead the evidence of an expert and 10 days' notice to give a summary of his opinions. (1)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6