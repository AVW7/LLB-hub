(iv) Removal of property with intent to prejudice or prefer
(If he/she gives notice in writing to any one of his/her creditors that he/she is unable to pay of his/her debts). (1)

(v) Offer of arrangement
(If he/she makes, or offers to make, an arrangement with any of his/her creditors for releasing him/her wholly or in part from his debts). (1)

(vi) Failure to apply for surrender
(If, after having published a notice of his/her estate which has not lapsed or been withdrawn, he/she fails to lodge at the Master's office a statement in duplicate of the debtor's affairs of fails to apply for the acceptance of the surrender of his/her estate on the date mentioned in the notice of surrender as the date on which the Application is to be made). (1)

(vii) Notice of inability to pay
(If he/she gives notice in writing to any one of his/her creditors that he/she is unable to pay any of his/her debts). (1)

(viii) Inability to pay debts after notice of transfer of business
(If, being a trader, he/she gives notice in the Gazette of his/her intention to transfer business and is thereafter unable to pay all his/her debts). (1)

# **QUESTION 7**

[6]

7.1 Ex Parte application (1) seeking an Anton Pillar order (1) to preserve the evidence and/or material and/or documentation.

7.2 - The order would provide for service of the order by sheriff (1)
- who should be accompanied by an independent (not connected to applicant's attorneys) supervising attorney (1)
- both the independent supervising attorney and sheriff should make an inventory of all items removed by the sheriff in terms of the order to prevent any future disputes relating to removed items (1)
- sheriff may also be required to file a report describing the manner in which the order was complied with (1)

# **QUESTION 8**

[20]

# **8.1**

# **IN THE MAGISTRATES COURT FOR THE DISTRICT OF NOZUKO HELD AT NOZUKO**

**In the matter between:**

**THE STATE**

**and**

*LAW SOCIETY OF SOUTH AFRICA*
*LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

4