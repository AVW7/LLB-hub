4. On the 15th of August 2020 (½) and at Pretoria (½) Plaintiff duly represented by Sipho Madlingozi (½) and First and Second Defendant's entered into a written agreement (½) in terms of which Plaintiff purchased from First and Second Defendant's Erf 148, Pretoria Gardens Registration Division JR Gauteng (½) for a purchase price of One million four hundred thousand Rand (R1 400 000.00) (½).
5. Copy of the said agreement is attached hereto marked annexure "A" (1).
6. Plaintiff has duly provided guarantee for payment of the full purchase price as required in terms of the agreement and has fulfilled all other obligations imposed in terms of the agreement (1).
7. Despite demand, First and Second Defendant refuse to pass transfer to Plaintiff by neglecting or refusing to sign the transfer documents (1).
8. The above honourable court has jurisdiction to hear the matter... (1).

Wherefore Plaintiff claims:

a) An order directing First and Second Defendants to take all the necessary steps/sign all transfer documents necessary to pass transfer of Erf 148 Pretoria Gardens Registration Division J R Gauteng to Plaintiff (1).
b) An order, that should Defendants fail to within 14 days of this court order take the necessary steps, the sheriff Pretoria is authorised to take such steps on the Defendant's behalf (1).
c) Costs of suit (1).
d) Further or alternative relief.

# **QUESTION 6**

[6]

**Any six of the following, 1 mark per correct answer maximum total of 6 marks.**

(i) Absence from the Republic or dwelling
(If he leaves the Republic, or being out of the Republic, remains absent from the Republic, or departs from his dwelling or otherwise absents himself, with intent by doing so evade or delay payment of his debts). (1)
(ii) Failure to satisfy judgment
(If a court has given judgment against him/her and he/she fails, upon the demand of the officer whose duty it is to execute the judgment, to satisfy it or to indicate to the officer disposable property sufficient to satisfy it, or it appears from the return made by the officer that he has not found sufficient disposable property to satisfy the judgment). (1)
(iii) Disposition prejudicing creditors or preferring one creditor
(If he/she makes, or attempts to make, any disposition of any of his/her property which has, or would have, the effect of prejudicing his/her creditors or of preferring one creditor above another). (1)

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3