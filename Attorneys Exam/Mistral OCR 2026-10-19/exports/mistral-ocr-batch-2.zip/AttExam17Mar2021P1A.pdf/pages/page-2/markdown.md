2.3 All road users within South Africa are covered by the provisions of the RAF Act. (1)
2.4 Yes. (1)
2.5 Income is derived from a levy that is based on fuel sales known as the RAF Fuel Levy. The RAF Fuel Levy income is a charge levied on fuel throughout the country. The value of the RAF Fuel Levy per litre is determined by the National Treasury annually. (1)

### **QUESTION 3**

**[6]**

3.1 General damages –

also referred to as non-pecuniary loss (½)
is not an out of pocket expense (½)
awarded for pain, suffering, shock, disability, disfigurement, loss of amenities of life,
loss of life expectancy (1)

Special damages - represents actual financial / out of pocket loss (1)

3.2 Past Loss of support (½)
Future Loss of Support (½)
Past hospital and medical expenses (½)
Future hospital and medical expenses (½)
Past Loss of Earning Capacity (½)
Future Loss of Earning Capacity (½)
Funeral Expenses (½)

**Any 6 of the above responses are correct.**

### **QUESTION 4**

**[3]**

In terms of Regulation 3(3) the RAF may:

- Accept the RAF Form 4; (1)
- Reject the RAF Form 4 and provide reasons; (1) or
- Reject the RAF Form 4 and refer the injured for a further assessment in terms of the Regulations (1).

### **QUESTION 5**

**[13]**

#### **Plaintiff's Particulars of Claim**

1. Plaintiff is Madlingozi Enterprises (Pty) Ltd, a company with limited liability, duly registered in terms of the Companies Act/statutes of the Republic of South Africa with principal place of business/registered address at... (1)
2. First Defendant is John White N.O. , an adult male businessman, residing at ... in his capacity as trustee of the White Family Trust (1).
3. Second Defendant is Mary White, an adult female housewife, residing at in her capacity as trustee of the White Family Trust (1).

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2