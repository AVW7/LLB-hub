## QUESTION 11

[5]

11.1 Defendant may apply to Court for an order requiring Plaintiff to discover; (1) Defendant may object to the Plaintiff using such document in the action; (1) Defendant may apply for an adjournment of the trial. (1)

11.2 Defendant may give the Plaintiff notice that he requires the document to be made available for inspection (1) or that the Plaintiff declares that the document is not in his possession and state the whereabouts if known to him. (1)

## QUESTION 12

[6]

12.1 Defendant is liable to pay 60% of R60 000.00, which amounts to R 36 000.00 (1), and is entitled to recover 40% of R50 000.00, amounting to R 20 000.00 (1), i.e. Defendant is to pay R16 000.00 (1) to the Plaintiff. (1)

12.2 When the magistrate is giving judgment or within five (5) days thereafter the Defendant can draw the attention of the court to his tender (1) and can expect that the order for costs will be amended to provide for the Plaintiff to pay the Defendant's costs from the time of the tender. (1)

## QUESTION 13

[5]

Answer should contain an indication of the following:

13.1 Court heading indicating the seat (region or place) of the Court; (½)
13.2 Court heading should indicate that the Notice is done in a specific Court; (½)
13.3 That an order will be sought that costs be costs in the liquidation; (½)
13.4 That the affidavit of Mr C will be used in support of the application; (½)
13.5 A request that the matter be placed on the role accordingly; (½)
13.6 It should be dated and signed on behalf of the Applicant; (½)
13.7 It should be addressed to the Respondent; (½)
13.8 It should also be addressed to the Clerk of the Registrar of the relevant Regional Court; (½)
13.9 An address where the notice will be served on the employees and/or trade union of employees of the respondent CC; (½) and
13.10 An indication that the notice will be served on the South African Revenue Services. (½)

(Do not deduct marks if reference is made to service on creditors or the appointment of provisional or other liquidators).

## QUESTION 14

[5]

14.1 A rent claim in which you wish to seize Defendant's furniture. (1)
14.2 Liquid document. (1)
14.3 Plaintiff has an asset but does not know who is the rightful owner. (1)
14.4 Plaintiff has a liquidated claim against Defendant. (1)
14.5 Plaintiff has an unliquidated claim or is suing for a divorce. (1)

TOTAL: [100]

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7