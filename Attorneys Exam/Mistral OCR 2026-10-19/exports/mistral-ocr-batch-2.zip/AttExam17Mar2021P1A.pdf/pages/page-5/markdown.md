BANDI FUNDIEN (1)

# STATEMENT IN TERMS OF SECTION 115

I, BANDI FUNDIEN, do hereby declare as follows:

1. I am the Accused herein (1).
2. I hereby plead not guilty to the charge against me (1).
3. I admit that on the 10/07/2018 I was in the Council Chamber in Cape Town attending a meeting (1).
4. The atmosphere in the Chamber during the debate became extremely heated and councilors began assaulting each other (1).
5. During the altercation, the complainant grabbed me and hit me several times in my face with his fists (1).
6. In order to defend myself I picked up a jug of water which was standing on a table and struck him once on the head (1).
7. I accordingly plead not guilty and aver that I acted in self-defense (1).

DATED AT NOZUKO THIS 10TH OF SEPTEMBER 2020.

BANDI FUNDIEN (1)

(Any seven will be marked correct)

[7]

8.2

# STATEMENT IN TERMS OF SECTION 112

I, BANDI FUNDIEN, do hereby declare that: (1)

1. I am the accused in this matter (1).
2. I understand the nature of the charge against me and make this statement freely and voluntarily (1).
3. I admit that on the 10/07/2013 I was a councilor of the Municipality of NOZUKO and attending a council meeting together with other councilors. An argument resulted which became heated (1).
4. During the course of the argument, I became angry and picked up a jug of water and struck councilor Mxolisi Xoba on the head with same (1).
5. The blow caused the bodily injuries described in the medico-legal report of Dr Malan, dated 11/07/2018 the contents whereof I admit (1).
6. I furthermore admit that when I struck Mr Xoba I had the intention of inflicting grievous bodily harm (1).
7. I accordingly plead guilty to the charge (1).

(Any six of the above will be marked correct)

[6]

LAW SOCIETY OF SOUTH AFRICA
LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5