# **ADMISSION EXAMINATION**
**COURT PROCEDURES**
**PART 1**

**17 MARCH 2021**

**MEMORANDUM**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

# **QUESTION 1**

**[10]**

1.1

1. Date, time, place where the collision had occurred. (1)
2. Which police station has the collision been reported to and what is the accident report number? (1)
3. Whether she has a copy of the Police Collision Report. (1)
4. The registration details of the driver of the truck. (1)
5. Photographs of the place of collision and of the material damages to the respective motor vehicles. (1)
6. Insurance details and particulars of the vehicle driven by her spouse. (1)
7. Independent witness statements, if any. (1)
8. Whether a post mortem was undertaken or/inquest undertaken. (1)

**Choose any 5 answers above, for 5 marks.**

1.2

1. Request information on the business of the deceased spouse - financial statements, bank statements, vat returns, if VAT vendor. (1)
2. Enquire if Mrs Dlamini was employed, if so details to be obtained. (1)
3. Funeral expenses – who paid for them and a detailed itemised statement of account is needed. (1)
4. Request information on their marital regime. If married in community of property then the Final Liquidation & Distribution Account is needed for the actuarial calculation for loss of support. Her half share is deducted from her claim for loss of support. (1)
5. Request the details of the ages of her minor children. (1)

# **QUESTION 2**

**[6]**

2.1 To compensate (1) persons for bodily injuries (½) or death (½) caused by or arising from the negligent driving of a motor vehicle.

2.2 Wrongdoers / Negligent Drivers / Owners of motor vehicles. (1)

*LAW SOCIETY OF SOUTH AFRICA*
*LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™*

1