# 2.7 Bus Journal

Mr Debtor

Dr

R2200

Interest

Cr

R2200

Being interest on overdue account

(3)

# 2.8 Bus Journal

Mr X

Dr

R57 500

Fees

Cr

R5 000

Vat

Cr

R7500

Being fees

(3)

# QUESTION 3

[30]

Trust Ledger : Mr Purchaser

|  July 26 | Cash seller | 1500000 | July 06 | Deposit | 500000  |
| --- | --- | --- | --- | --- | --- |
|   | Transfer to Business | 105000 |  | Costs | 125000  |
|   |  |  |  | Proceeds of guarantee | 1000000  |
|   | Bank - Self Mr Purchaser | 25000 |  | Interest | 5000  |
|   |  | 1630000 |  |  | 1630000  |

Trust Ledger : Purchaser Trust Investment 78(2A)

|  July 11 | Bank | 500000 | July 26 | Cash | 500000  |
| --- | --- | --- | --- | --- | --- |

Business Ledger : Fees

July 26 Purchaser

15000

Business Ledger : Purchaser

|  July 08 | Transfer duty | 90000 |  |  |   |
| --- | --- | --- | --- | --- | --- |
|  26 | Fees | 15000 | July 26 | Transfer from Trust | 105000  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3