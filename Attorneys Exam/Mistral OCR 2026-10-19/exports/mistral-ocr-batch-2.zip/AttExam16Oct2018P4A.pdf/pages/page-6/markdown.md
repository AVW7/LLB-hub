# FEE JOURNAL

|  Buthelezi | Dr | 2300 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 2000  |
|  Vat | Cr |  | 300  |

Being Fees

|  Buthelezi | Dr | 2 300 |   |
| --- | --- | --- | --- |
|  Fees | Cr |  | 2000  |
|  Vat | Cr |  | 300  |

Being Collection Commission

TOTAL: [100]

# LAW SOCIETY

# OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6