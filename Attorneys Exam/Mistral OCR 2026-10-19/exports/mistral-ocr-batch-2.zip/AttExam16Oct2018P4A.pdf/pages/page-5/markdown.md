# TRUST LEDGER

Buthelezi

|  Cash | 9 600 | Cash | 50 000  |
| --- | --- | --- | --- |
|  Cash | 40 400 |  |   |

# BUSINESS LEDGER

Buthelezi

|  Fees | 2 300 | Cash | 9600  |
| --- | --- | --- | --- |
|  Cash | 5000 |  |   |
|  Fees | 2 300 |  |   |
|   |  | FEES |   |
|   |  | Buthelezi | 2000  |
|   |  | Buthelezi | 2000  |

# VAT

|   | Buthelezi | 300  |
| --- | --- | --- |
|   | Buthelezi | 300  |

# STATEMENT OF ACCOUNT - BUTHELEZI

To fee instructions 2300

To paid Tracing Agent 5000

By Cash Debtor 50 000

To Collection Commission 2300

EFT herewith 40 400

50 000 50 000

(5 marks)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5