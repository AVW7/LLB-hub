QUESTION 2

[25]

# 2.1 Business Journal

ABC (Pty) Ltd Dr R2500

Disbursements Cr R2500

Being Disbursements for Registration of Company (3)

# 2.2 Transfer Journal

Phumla Trust Dr R9000

Phumla Bus Cr R9000

Being Transfer of Fees (3)

# 2.3 Business Journal

Correspondent Dr R4600

Fees Cr R4000

Vat Cr R 600

Being 20% allowance on fees (4)

# 2.4 Trust Journal

Carnation Dr R35000

Petunia Cr R35000

Being correction of error (3)

# 2.5 Bus Journal

Fees Dr R1000

Vat Dr R150

Peter Cr R1150

Being reduction of fees (3)

# 2.6 Bus Journal

Mrs Divorce Dr R26 000

Counsel Cr R26 000

Being fees charged by Counsel (3)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2