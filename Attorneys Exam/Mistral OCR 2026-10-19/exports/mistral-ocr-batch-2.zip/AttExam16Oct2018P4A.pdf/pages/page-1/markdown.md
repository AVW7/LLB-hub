# **ADMISSION EXAMINATION / TOELATING SEKSAMEN  
BOOKKEEPING / BOEKHOU  
PART 4 / DEEL 4**

**16 OCTOBER / OKTOBER 2018**

**ANSWERS/ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.**

**NOTE TO EXAMINER:** This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

# **QUESTION 1**

**[15]**

|  Supplementary Cash Book for September 2018✓  |   |   |
| --- | --- | --- |
|  Balance | 250 000✓ | Incorrect deposit 102 000✓  |
|  Interest | 33 900✓ |   |
|  Correct Deposit | 120 000✓ |   |
|   | 300 |   |
|  EFT | 000✓ |   |
|   |  | Balance 601 900✓  |
|   | 703 900 | 703 900✓  |

**Bank reconciliation statement as at 30 September 2018 ✓**

|  Balance as per bank statement Less: | 565 900 ✓  |
| --- | --- |
|  Outstanding eft | 24 000✓  |
|  Subtotal | 541 900  |
|  Plus: Outstanding deposit | 100 000✓  |
|  Subtotal | 641 900  |
|  Add: Outstanding deposit | 50 000✓  |
|  Subtotal | 691 900  |
|  Less: Bank error trust deposit | 90 000✓  |
|  Balance as per cash book | 601 900✓  |

**LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™**

1