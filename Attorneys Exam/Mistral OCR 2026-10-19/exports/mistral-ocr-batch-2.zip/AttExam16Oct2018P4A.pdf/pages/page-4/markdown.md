Trust Cash Book

|  July 06 | Purchaser – Deposit | 500000 | July 11 | Trust Investment | 500000  |
| --- | --- | --- | --- | --- | --- |
|   | Purchaser – Costs | 125000 | July 26 | Seller | 1500000  |
|   | Trust Investment | 505000 |  | Transfer to business | 105000  |
|   | Bank guarantee | 1000000 |  | Mr Purchaser | 25000  |
|   |  | 2130000 |  |  | 2130000  |

Business Cash Book

|  July 26 | Transfer from Trust | 105 000 | July 08 | Transfer duty | 90 000  |
| --- | --- | --- | --- | --- | --- |

Fees Journal

|  July 26 | Mr Purchaser (B) Fees Transfer and other fees | 15 000 | 15 000  |
| --- | --- | --- | --- |

Transfer Journal

|  July 26 | Mr Purchaser (T) Mr Purchaser (B) Being transfer fees/disbursements | 105 000 | 105 000  |
| --- | --- | --- | --- |

# QUESTION 4

[30]

TRUST CASH BOOK

|  Mohamed | 50 000 | Buthelezi Transfer | 40 400 9 600  |
| --- | --- | --- | --- |

BUSINESS CASH BOOK

|  Cash | 9 600 | Tracing Agent | 5000  |
| --- | --- | --- | --- |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4