# BANK RECONCILIATION STATEMENT AT 30 SEPTEMBER 2014

|  Balance as per bank statement | 1,668,946  |
| --- | --- |
|  Outstanding cheques | 49,227  |
|   | 1,619,719  |
|  Outstanding deposit | 34,128  |
|   | 1,653,847  |
|  Bank Error | 16,111  |
|  Balance as per cash book | 1,669,958  |

1 Mark for each entry

1 Mark for each heading

QUESTION 2 [30]

|  TRUST CASH BOOK  |   |   |   |
| --- | --- | --- | --- |
|  Correspondent | 17,520 | Jan | 14,930  |
|   |  | Lucas | 2,408  |
|   |  | Business | 182  |
|   | 17,520 |  | 17,520  |

CORRESPONDENT (T)

|  Clients – collections | 23,000 | Bank | 17,520  |
| --- | --- | --- | --- |
|  Transfer to business | 182 | Clients – fees and disbursements | 5,662  |
|   | 23,182 |  | 23,182  |

JAN (T)

|  Correspondent fees and disbursement | 5,070 | Correspondent -BEN | 20,000  |
| --- | --- | --- | --- |
|  Bank self | 14,930 |  |   |
|   | 20,000 |  | 20,000  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2