|  RENT  |   |   |   |
| --- | --- | --- | --- |
|  Landlord | 10,000 |  |   |
|  INPUT VAT  |   |   |   |
|  Landlord | 1,400 |  | 2,000  |
|  LEASECO  |   |   |   |
|  Bank | 5,999 | Motor vehicle | 342,000  |
|  MOTOR VEHICLE  |   |   |   |
|  Laeseco | 342,000 |  |   |
|  FEES  |   |   |   |
|   |  | Thabio | 5,000  |
|  TRUST CASH BOOK  |   |   |   |
|  Thabiso | 25,000 | Thabiso | 19,300  |
|   |  | Transfer to business | 5,700  |
|   | 25,000 |  | 25,000  |
|  THABISO (T)  |   |   |   |
|  Bank – self | 19,300 | Bank deposit | 25,000  |
|  Transfer to Business | 5,700 |  | 25,000  |
|   | 25,000 |  |   |
|  THABISO (B)  |   |   |   |
|  Registration fees and VAT | 5,700 | Transfer ex Trust | 5,700  |
|  OUTPUT VAT  |   |   |   |
|   |  | Thabiso | 700  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6