|  STAFF SALARIES  |   |   |   |
| --- | --- | --- | --- |
|  Bank | 28,500 |  |   |
|  FEES JOURNAL  |   |   |   |
|  Thabiso (B) fees | 5,700 | Fees | 5,000  |
|   |  | VAT | 700  |
|  Fees re registration of Company |  |  |   |
|  TRANSFER JOURNAL  |   |   |   |
|  Thabiso (T) | 5,700 | Thabiso (B) | 5,700  |
|  Transfer fees |  |  |   |
|  ACCOUNTING STATEMENT  |   |   |   |
|  THABISO REGISTRATION OF COMPANY  |   |   |   |
|  Deposit received |  |  | 25,000  |
|  Our fees |  | 5,000 |   |
|  Vat @ 14% |  | 700 |   |
|  Cheque Herewith |  | 19,300 |   |
|   |  | 25,000 | 25,000  |

1 mark for each entry

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7