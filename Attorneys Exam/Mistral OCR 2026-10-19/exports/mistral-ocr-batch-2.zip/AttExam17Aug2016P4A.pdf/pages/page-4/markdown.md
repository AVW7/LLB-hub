# TRANSFER JOURNAL

|  Correspondent (T) | 182 |   |
| --- | --- | --- |
|  Correspondent (B) |  | 182  |
|  Transfer allowances |  |   |

# FEES

|   | Correspondent allowances | 160  |
| --- | --- | --- |
|  OUTPUT VAT  |   |   |
|   | Correspondent | 22  |

# BUSINESS CASH BOOK

Transfer ex Trust

182

1 Mark for each entry

# QUESTION 3

[20]

# TRUST CASH BOOK

|  2015 1 March Balance | 1,272,308 | 2015 |   |
| --- | --- | --- | --- |
|  31 ABC Bank | 854,000 | 1/3 Balance | 850,000  |
|  31 XYZ Bank | 201,000 | XYZ Bank | 200,000  |
|   |  | 31/3 Maria | 4,000  |
|   |  | Law Society | 1,000  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4