# LUCAS (T)

|  Correspondent fees and disbursement | 592 | Correspondent SAM | 3,000  |
| --- | --- | --- | --- |
|  Bank self | 2,408 |  |   |
|   | 3,000 |  | 3,000  |

# CORRESPONDENT (B)

|  Allowances | 182 | Transfer ex Trust | 182  |
| --- | --- | --- | --- |
|   | 23,182 |  | 23,182  |

# TRUST JOURNAL

|  Correspondent (T) | 23,000 |   |
| --- | --- | --- |
|  Jan (T) |  | 20,000  |
|  Lucas |  | 3,000  |
|  Transfer cash collected from debtors |  |   |
|  Jan (T) | 5070 |   |
|  Lucas (T) | 592 | 5,662  |
|  Transfer correspondents gross fees and disbursements |  |   |

# FEES JOURNAL

|  Correspondent (B) | 182 |   |
| --- | --- | --- |
|  Fees |  | 160  |
|  Output VAT |  | 22  |
|  Correspondent allowances |  |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3