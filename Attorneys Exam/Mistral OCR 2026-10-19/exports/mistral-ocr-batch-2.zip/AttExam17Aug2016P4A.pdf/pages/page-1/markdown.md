# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
BOOKKEEPING / BOEKHOU
PART 4 / DEEL 4

17 AUGUST / 17 AUGUSTUS 2016

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE
A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF
READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be
justifiable variations in practice which are brought out in the answers.
When this happens the examiner should apply his discretion in
marking the answer.

QUESTION 1

[15]

# SUPPLEMENTARY TRUST CASH BOOK – SEPTEMBER 2014

Balance

1,643,298

Interest

6,881

Cheque written back

2,488

EFT Transfer

125,000

Unpaid cheque

52,841

Cheque adjustment

45,000

Deposit adjustment

7,380

Cheque reissued

2,488

Balance

1,669,958

1,777,667

1,777,667

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1