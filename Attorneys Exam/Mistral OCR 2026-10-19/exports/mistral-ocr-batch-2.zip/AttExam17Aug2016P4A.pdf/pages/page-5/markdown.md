MARIA (T)

|  2015 31/3 Self – Interest | 4,000 | 2015 1/3 balance 31/3 Interest | 850,000 4,000  |
| --- | --- | --- | --- |
|  MARIA TRUST INVESTMENT – SEC 78 (2A)  |   |   |   |
|  2015 1/3 ABC Bank | 850,000 | 2015 31/3 ABC Bank | 850,000  |
|  TRUST INVESTMENT – SEC 78 (2)(a)  |   |   |   |
|  2015 1/3 XYZ Bank | 200,000 | 2015 31/3 XYZ Bank | 200,000  |
|  FIDELITY FUND (T)  |   |   |   |
|  2015 31/3 Bank – Law Society | 1,000 | 2015 31/3 XYZ Bank | 1,000  |

1 Mark for each entry
2 Marks for each of investment headings.

QUESTION 4

[35]

BUSINESS CASH BOOK

|  Capital Deposit | 200,000 | Rent | 11,400  |
| --- | --- | --- | --- |
|  Transfer ex Trust | 5,700 | Leaseco | 5,999  |
|   |  | Staff Salaries | 28,500  |

CAPITAL

|   | Bank | 200,000  |
| --- | --- | --- |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5