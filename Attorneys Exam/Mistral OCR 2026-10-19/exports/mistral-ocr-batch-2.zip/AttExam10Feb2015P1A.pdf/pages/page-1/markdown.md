# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
COURT PROCEDURES /HOFPROSEDURES
PART 1 / DEEL 1

10 FEBRUARY / FEBRUARIE 2015

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A
CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

# NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable
variations in practice which are brought out in the answers. When this
happens the examiner should apply his discretion in marking the answer.

# QUESTION 1

[16]

1.1. Yes. Both Mr and Mrs Williams are entitled to compensation from the RAF for their personal injuries as these were caused by / arose out of the negligent driving of a motor vehicle and, in Mr William's case, the other driver was solely to blame for the relevant collision. (3)
1.2. Yes, there is a claim for compensation in respect of the son's injuries.

- A foetus in utero is regarded as a "person" for the purposes of S17(1)(a) and (b) of the Road Accident Fund Act. Our courts have held that insofar as the Act offered protection to the mother of the unborn child, such protection would extend to the child itself. [RAF v M obo M {2005} 3 A11 SA 340 (SCA); Mtati v RAF 2005(6) SA 215 (SCA)].
Either Mr or Mrs Williams may claim, in their representative capacity as parent and natural guardian, on behalf of their son, for his ante-natal injuries. (3)

1.3. Mr Williams

(½)

- Past Hospital and Medical expenses (1/2)
- Past Loss of earnings (1/2)

Mrs Williams (½)

- Past Hospital and Medical expenses (1/2)
- Future Hospital and Medical expenses (1/2)

Mr or Mrs Williams obo son (½)

- Past Hospital and Medical Expenses (1/2)
- Future Hospital and Medical expenses (1/2)
- Future Loss of earnings (1/2)

(5)

1.4. The RAF will only compensate for non-pecuniary loss (general damages) if the injury is a
"serious injury" and the following criteria have been met, either:

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1