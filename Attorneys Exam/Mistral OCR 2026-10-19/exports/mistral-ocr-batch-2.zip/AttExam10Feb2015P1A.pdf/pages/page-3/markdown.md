Mr John Hart

Defendant

# DECLARATION (1 mark)

1.

The plaintiff is Comfy Homes CC, a Close Corporation duly registered in accordance with the laws of the Republic of South Africa, with registered address at 1 High Street, Grahamstown (½ mark).

2.

The defendant is Mr John Hart, an adult male of full legal capacity, whose full and further particulars are to the plaintiff unknown and residing at 100 Settlers Road, Grahamstown (½ mark).

3.

On or about 1 July 2014, the plaintiff, as represented by Mr Joe Soap in his capacity as sole member of the plaintiff and the defendant acting personally concluded a written contract of which a copy is attached hereto as "Annexure A" hereto. (½ mark).

4.

The material terms of the said contract were the following:

4.1 The plaintiff would build a house of 150 square metres for the defendant at 100 Settlers Road, Grahamstown. (½ mark).
4.2 The cost of construction and material would be charged by plaintiff to defendant at rate of R8 000 per square metres. (½ mark).
4.3 The total price for the house would be R1.2 m. (½ mark).
4.4 The defendant would pay the price as follows:
4.4.1 Three instalments of R400 000 each, the first to be paid when the construction reached roof height; (½ mark).
4.4.2 The second instalment on completion of the house (½ mark); and
4.4.3 The final payment of R400 000 within ten (10) days of the handover of the house to the defendant. (½ mark).

5.

The plaintiff performed in terms of the contract and completed the construction of the house on the 30th November 2014 when handover occurred. (½ mark).

6.

The defendant paid to plaintiff a total amount of R800 000 but failed to make the final payment of R400 000 in terms of the contract which amount is now due and payable to plaintiff. (½ mark).

7.

Despite demand, defendant has failed to comply with its obligation to pay the said amount to plaintiff. (½ mark).

WHEREFORE plaintiff claims judgment against defendant for:

a) Payment for the sum R400 000 (½ mark)
b) Interest thereon at the prescribed rate of 15,5% per annum, calculated from due date for payment thereof (10 December 2014) to date of payment (½ mark)

LEGAL EUDCATION AND DEVELOPMENT [L.E.A.D]FM

3