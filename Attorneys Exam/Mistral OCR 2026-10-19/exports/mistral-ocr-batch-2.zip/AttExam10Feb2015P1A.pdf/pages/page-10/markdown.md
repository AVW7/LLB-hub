QUESTION 23

[5]

23.1 Mervyn Naidoo, a bookkeeper, the father and natural guardian of Vinesh Naidoo, a student who resides at 10 Smith Street Durban ("Plaintiff"). (2)
23.2 Only the Professor (1)
23.3 No. The claim is not for a liquidated amount. (2)

TOTAL: [100]

![img-0.jpeg](img-0.jpeg)

# LAW SOCIETY

# OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

10