At the time of the collision the second defendant was acting in the course and scope of his employment with the first defendant.

6.

The whole cause of action arose within the jurisdiction of the above honourable court.

7.

The sole cause of the collision was due to the negligent driving of the second defendant in that:

a) he failed to keep a proper lookout
b) he failed to stop at robot controlled intersection and collided with the rear end of the plaintiff's vehicle.
c) he drove at an excessive speed.

8.

As a result of the collision the plaintiff's vehicle was damaged and the reasonable and necessary costs of repairing the vehicle is R 35 000,00. A copy of the quotation in support thereof is annexed here marked "A".

9.

Despite demand the defendants have failed to pay the said amount. Copies of the demands are annexed hereto marked "A" and "C".

WHEREFORE the plaintiff prays for Judgment against the first and second defendants jointly and severally, the one paying the other to be absolved for:

1. payment for the sum of R 35 000,00;
2. interest thereon at the rate of \(15.5\%\) p.a. from the date of the expiry of the letter of demand to date of payment;
3. costs of suit.

DATED at DURBAN this

day of

2014

Plaintiff's Attorneys

AB Attorneys

42 East Street

Durban

QUESTION 17

[4]

# APPLICATION FOR RESCISSION OF A DEFAULT JUDGMENT

TO : THE CLERK OF THE COURT
DURBAN

AND TO: AB ATTORNEYS
PLAINTIFF'S/RESPONDENTS'S ATTORNEYS
20 WEST STREET
DURBAN

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

8