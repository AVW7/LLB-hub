SIRS,

BE PLEASED to take notice that Application be made to the above Honourable Court on the day of 2015 at 08h30 or so soon thereafter as the matter may be heard for an Order in the following terms:

1. That the Applicant/Defendant be granted condonation for the late filing of the Application;
2. That the Default Judgment entered on the \(14^{\text{th}}\) of October 2014 be and is hereby rescinded;
3. That the Applicant/Defendant is granted leave to defend the action;
4. That the Plaintiff/Respondent pay the costs of the Application in the event of it being opposed.

DATED at DURBAN this

day of

2015.

Defendant's / Respondent's Attorneys

CD Attorneys

40 West Street

Durban

QUESTION 18

[2]

Notice of Judgment (section 65A(2) letter)

Notice to appear in court and show cause at the financial enquiry (section 65A(1) notice)

QUESTION 19

[1]

Garnishee Order

QUESTION 20

[1]

Emolument Attachment Order

QUESTION 21

[2]

Offer to settle on the basis that the claim is withdrawn and each party pays own costs
Or

Deliver a notice to abandon the judgment (rule 51 (11) (a)

QUESTION 22

[2]

22.1 The Registrar

(1)

22.2 The decision of the Registrar is final

(1)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

9