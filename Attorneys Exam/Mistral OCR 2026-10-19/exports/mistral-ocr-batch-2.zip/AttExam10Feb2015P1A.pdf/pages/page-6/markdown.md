# QUESTION 14

[5]

a. The name of the crime; (1)
b. The time when the offence was committed; (1)
c. The place where it was committed; (1)
d. The person against whom it was committed; (1)
e. The property, if any, in respect of which the offence was committed, as may be reasonably sufficient to inform the accused of the nature of the charge. (1)

# QUESTION 15

[10]

15.1 The minimum sentences prescribed for offences in terms of the Criminal Law Amendment Act 105 of 1997. In this instance a sentence of 15 years must be imposed. (2)
15.2 Substantial and compelling circumstances will have to be brought to the attention of the court to persuade the court to impose a lesser sentence. (1)
15.3 In Regional Court for the Regional Division of Mthathe Held at Mthathe

Case No: 132/2014

In the matter between:

The Accused

Applicant

And

# NOTICE OF APPLICATION FOR LEAVE TO APPEAL

BE PLEASED TO TAKE NOTICE that the Applicant hereby gives notice of his intention to apply for leave to appeal to the Mthathe Division of the High Court of South Africa against the sentence imposed upon him by the Regional Magistrate, Mr Zwanele, sitting at the Regional Court number 4 on the 15th of June 2014.

The grounds of appeal are as follows:

1. The sentence imposed on the Applicant induces a sense of shock;
2. The learned Magistrate failed to take into consideration the personal circumstances of the Applicant and in particular that he is a young man and a first offender;
3. The Magistrate erred in not considering the circumstances under which the offence was committed and in particular the probability that the Applicant was under the influence of liquor;
4. The Magistrate erred in not taking into consideration that the Applicant could have been under the influence of an older person;
5. The Magistrate erred in not considering that minimum force was used in the commission of the offence and an imitation firearm utilized;

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6