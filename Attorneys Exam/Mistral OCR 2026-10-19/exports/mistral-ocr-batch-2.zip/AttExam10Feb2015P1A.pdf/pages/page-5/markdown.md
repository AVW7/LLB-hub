a copy of the summons \((\frac{1}{2}\) mark);
a copy of sheriff's return of service (½ mark);
- copy of notice of set down(½ mark);
a copy of the defendant's opposing affidavit (if any) \((\frac{1}{2}\) mark)
a copy of the plaintiff's replying affidavit (if any) \((\frac{1}{2}\) mark)
- memorandum of instructions to counsel(½ mark)

Note to examiner: Please allow ½ mark for each of the above documents mentioned by the candidate subject to a maximum of 3 marks.

# QUESTION 10

[1]

If an accused conducts himself in a manner which makes the continuance of the proceedings in his presence impractical, the court may direct that he may be removed and the proceedings continue in his absence.

# QUESTION 11

[3]

Articles which may be seized are those which:

a. If reasonable grounds exist to believe that the article are to be concerned in the commission or suspected commission of an offence; (1)
b. Which may provide evidence of the commission of an offence; (1)
c. Which are intended to be used or are on reasonable grounds believed to be intended to be used in the commission of an offence.

(Section 20)

(1)

# QUESTION 12

[3]

a. If the arrestor, on reasonable grounds, believe that the force is immediately necessary for the purpose of protecting the arrestor.
b. If the arrestor, on reasonable grounds, believe that the force is immediately necessary for the purpose of protecting any person lawfully assisting the arrestor.
c. If the arrestor, on reasonable grounds, believe that the force is immediately necessary for the purpose of protecting any other person from imminent or future death or grievous bodily harm;
d. That there is a substantial risk that the suspect will cause imminent or future death or grievous bodily harm if the arrest is delayed; or
e. That the offence for which the arrest is sought is in progress and is of a forcible and serious nature and involves the use of life threatening violence or strong likelihood that it will cause grievous bodily harm. (Section 49)

(To the examiner: any three will suffice)

# QUESTION 13

[3]

At the appearance the practitioner will present the medical certificate to the presiding officer and request the court to postpone the matter, issue a warrant of arrest but that same stand over until the following date. The court may however order that the warrant be issued and executed immediately.

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5