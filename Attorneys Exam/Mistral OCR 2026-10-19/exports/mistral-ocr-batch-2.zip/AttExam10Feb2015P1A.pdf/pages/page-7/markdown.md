6. The Learned Magistrate erred in not taking into consideration the fact that the motor vehicle was recovered.
7. The Magistrate erred in not taking into consideration the fact that the Applicant pleaded guilty;
8. The Magistrate over-emphasized the seriousness of the offence and the interests of the community;
9. The Magistrate erred in not finding that there were substantial and compelling circumstances making it possible not to impose a minimum sentence.
10. ETC, ETC

DATED AT MTHATHE ON THIS DAY OF 2014.

APPLICANTS ATTORNEYS

TO: The Clerk of the Court
MTHATHE

AND TO: THE PROSECUTOR
REGIONAL COURT
MTATHE

QUESTION 16

(7)

[8]

1.

The Plaintiff is Palm Repairs (Pty) Limited, a company duly incorporated with limited liability in terms of the Company Laws of the Republic of South African and whose principal place of business is situated at 20 West Street, Durban.

2.

The first defendant is James Construction (Pty) Limited, a company duly incorporated with limited in terms of the Company Laws of the Republic of South Africa and whose principal place of business is situated at 20 Church Street, Pietermaritzburg.

3.

The second defendant is Alan Ndlovu, an adult male, whose full and further particulars are to the plaintiff unknown and who is employed by the first defendant and whose place of employment is situated at 20 Church Street, Pietermaritzburg.

4.

On the 18th of September 2013 at Umgeni Road, Durban a collision occurred between motor vehicle NJ 208, a 2014 BMW which is owned by the plaintiff and at the time of the collision was being driven by Billy Naidoo and a Toyota truck NPN 47 which at the time of the collision was driven by the second defendant.

5.

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7