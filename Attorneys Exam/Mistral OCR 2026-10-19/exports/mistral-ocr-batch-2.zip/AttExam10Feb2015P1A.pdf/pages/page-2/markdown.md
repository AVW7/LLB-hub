A 30% or more whole person impairment in terms of the AMA (American Medical Association) Guidelines, or (½)

a) a serious long-term impairment or loss of body function; (½)
b) permanent serious disfigurement; (½)
c) severe long-term mental or severe long-term behavioural disturbance or disorder; or (½)
d) Loss of a foetus (½) (2½)

1.5.1 The relevant claims may be lodged with any of the branch offices of the Road Accident Fund. (½)
1.5.2 It is the court within whose geographical area of jurisdiction the cause of action arose (i.e. where the collision occurred) that would have the requisite jurisdiction in a particular matter. (In casu, The High Court of South Africa, KwaZulu-Natal Division, Pietermaritzburg). Alternatively, the court within whose geographical area of jurisdiction the Road Accident Fund has its principal place of business. (The RAF has designated its head office in Menlyn, Pretoria, as its principal place of business for this purpose). (2)

# QUESTION 2 [4]

2.1 You can have the claimant examined by a medical practitioner (1) who has fully satisfied himself regarding the nature and treatment of the bodily injuries, in respect of which the claim is made and to then prepare a medical report (1). (2)
2.2 By registered post; or Delivered by hand (2)

# QUESTION 3 [5]

3.1.1 12 March 2016 in respect of Identified Motor Vehicles (3 years from date of collision).
3.1.2 12 March 2015 in respect of Unidentified Motor Vehicles or "hit and run" claims (2 years from date of Collision). [Either answer should be marked correct]. (2)
3.2. You would have the claimant examined by a medical practitioner with regard to the injuries suffered (1) who will complete an R.A.F form. 4 (2)
3.3. Within a period of 5 years from the date of collision (or 12 March 2018) [Either answer is correct]. (1)

# QUESTION 4 [10]

IN THE HIGH COURT OF SOUTH AFRICA
EASTERN CAPE DIVISION, GRAHAMSTOWN (1 mark)

Case number

Comfy Homes CC

Plaintiff

And

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2