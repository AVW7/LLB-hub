c) Costs of suit \((\frac{1}{2}\) mark
d) Further and/or alternative relief (1/2 mark)

# QUESTION 5

[2]

Deliver a notice of bar in terms of Rule 26 dealing with Failure to deliver Pleadings read with Rule 20 dealing with Declaration. (1 Mark)

Motivation: in terms of Rule 20 the plaintiff must deliver a declaration within 15 days of delivery of defendant's notice of intention to defend. In terms of Rule 26 if any party fails to deliver any pleading (other than a replication or subsequent pleading) within the time stated in the rules for such pleading, the other party may serve a notice to file such pleading within 5 days. (1 mark)

Note to examiner: the candidate should not be penalised for not stating the number of the rule referred to.

# QUESTION 6

[2]

One month as provided for in section 24 of the Superior Courts Act as the defendant is not resident within the area of jurisdiction of the court and the period prescribed in Rule 19(1) therefor does not apply.

# QUESTION 7

[2]

No.

(1)

It is an interlocutory application and the order is not appealable.

(1)

# QUESTION 8

[6]

Note to examiner: Rule 37(6) provides for about 10 matters to be dealt with at the conference. Allow 1 mark, subject to a maximum of 6 marks for each correct answer:

- If a party feels that he is prejudiced because another party has not complied with the rules of court, the nature of such non-compliance and prejudice must be stated (1 mark);
- that every party claiming relief has requested his opponent to make a settlement proposal and that such opponent has acted thereto (1 mark);
- Whether any issue has been referred by the parties for mediation, arbitration or decision by a third party and on what basis it has been so referred (1 mark);
- Whether the case should be transferred to another court (1 mark);
- Which issues should be decided separately in terms of rule 33(4) (1 mark);
The admissions made by each party (1 mark);
- Any dispute regarding the duty to begin or the onus of proof(1 mark);
- Any agreement regarding the production of proof by way of an affidavit in terms of rule 38(2) (1 mark;
- Which party will be responsible for the copying and other preparation of documents(1 mark);
- Which documents or copies of document will, without further proof, serve as evidence of what they purport to be, which extracts may be proved without proving the whole document or any other agreement regarding the proof of documents(1 mark).

# QUESTION 9

[3]

- The original document (usually a liquid document) on which the claim is founded (½ mark) ;

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4