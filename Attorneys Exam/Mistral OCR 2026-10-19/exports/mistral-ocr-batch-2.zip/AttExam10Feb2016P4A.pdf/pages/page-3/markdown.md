# TRUST JOURNAL

Correspondent (T) 23 546

Correspondent (B) 23 546

Being transfer of fees & Disbursements

1 mark each for ledger and cash book entries
2 marks each for journal entries
2 discretionary marks for neatness and layout

Note: collection commission 1/3 allowance of R330 should not be changed to R333.

# QUESTION 2

[10]

Trust liabilities

As per schedule

643 712.93 (1)

Trust Funds available

As per trust cash book (1) 422 803.52

Trust investment in terms of section 78(2)(a) (1) 200 000.00

Trust investment in terms of section 78(2A) (1) 100 000.00 722 803.52 (1)

Trust surplus (1)

(available for transfer)

79 090.59 (2)

2 discretionary marks for neatness and layout

# QUESTION 3

[20]

TRUST CASH BOOK

|  Deposit client (T) | 10 000 | Paid Counsel Client (T) | 3 000  |
| --- | --- | --- | --- |
|  Transfer from business | 3 000 | Unpaid Cheque | 10 000  |
|  Client | 7000 |  |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 3