# Irregularities

- Modau Trust debit 1 500 (2)
- B Mashilo Business Credit 3 000 (2)

Excess payment from Trust (2)

Incorrect deposit to Business (2)

Excess transfer from Trust (2)

TOTAL: [100]

![img-0.jpeg](img-0.jpeg)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 5