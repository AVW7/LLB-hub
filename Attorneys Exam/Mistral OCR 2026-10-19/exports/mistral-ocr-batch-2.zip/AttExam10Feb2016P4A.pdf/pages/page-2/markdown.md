BUSINESS LEDGER - FEES

|  To correspondent | 1 980 | By Correspondent | 5 950  |
| --- | --- | --- | --- |
|  To correspondent | 4000 | By Correspondent | 12 000  |

BUSINESS LEDGER – CORRESPONDENT

|  To paid Sheriff | 900 | By Fee allowance | 2 257  |
| --- | --- | --- | --- |
|  To Fees & Vat | 6 783 | By Fee allowance | 4 560  |
|  To Fees & Vat | 13 680 | By trust transfer | 23 546  |
|  To paid Counsel | 7 500 |  |   |
|  To paid Sheriff | 1 500 |  |   |
|   | 30 363 |  | 30 363  |

BUSINESS LEDGER VAT (OUTPUT)

|  Correspondent |  | 277 | Correspondent | 833  |
| --- | --- | --- | --- | --- |
|  Correspondent |  | 560 | Correspondent | 1680  |
|  Business Journal  |   |   |   |   |
|  Correspondent | Dr | 6 783 |  |   |
|  Fees | Cr |  | 5 950 |   |
|  Vat | Cr |  | 833 |   |
|  Fee & Disbursements + VAT  |   |   |   |   |
|  Fees | Dr | 1980 |  |   |
|  Vat | Dr | 277 |  |   |
|  Correspondent | Cr |  | 2 257 |   |
|  Being ½ allowance  |   |   |   |   |
|  Correspondent | Dr | 13 680 |  |   |
|  Fees | Cr |  | 12 000 |   |
|  Vat | Cr |  | 1 680 |   |
|  Being Fees in Divorce matter  |   |   |   |   |
|  Fees | Dr | 4 000 |  |   |
|  Vat | Dr | 560 |  |   |
|  Correspondent | Cr |  | 4 560 |   |
|  Being ½ allowance  |   |   |   |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 2