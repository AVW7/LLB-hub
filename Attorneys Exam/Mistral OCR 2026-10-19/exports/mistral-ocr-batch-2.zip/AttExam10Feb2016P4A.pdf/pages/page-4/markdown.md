# CLIENT TRUST ACCOUNT

|  Counsel | 3000 | Deposit | 10 000  |
| --- | --- | --- | --- |
|  Unpaid Cheque | 10 000 | Transfer from Bus | 3000  |
|   |  | Bank | 7000  |

# CLIENT BUSINESS ACOUNT

|  Transfer to trust | 3000 | Bank | 3000  |
| --- | --- | --- | --- |

# BUSINESS CASH BOOK

|  Client | 3000 | Transfer to trust | 3000  |
| --- | --- | --- | --- |

# Transfer Journal

Client business account

Client trust account

Reverse transfer

3000

3000

1 mark for all cash book entries
3 marks for the transfer journal
3 discretionary marks for neatness and layout

# QUESTION 4

[30]

Transferable amount

|   | Dr | Cr |  | Dr | CR  |
| --- | --- | --- | --- | --- | --- |
|  AB Products CC | 1 106 | 4 327 | 1 106 (1) | nil | 3 221 (1)  |
|  CV Salmon | 6 523 | 1 621 | 1 621 (1) | 4 902 (1) | nil  |
|  Ismail Shoes (Pty) Ltd | 31 329 | 62 000 | 31 329 (1) | nil | 30 671 (1)  |
|  S Modau | 4 379 | (1 500) | (1 500) (2) | 5 879 (2) | nil  |
|  J vd Walt | 62 988 | 42 000 | 42 000 (1) | 20 988 (1) | nil  |
|  B Mashilo | (3 000) | 5 638 | (3 000) (2) | nil | 8 638 (2)  |
|  M Ntuli | 1 000 | 4 000 | 1 000 (1) | nil | 3 000 (1)  |
|   | 104 325 | 118 086 | 72 556 (1) | 31 769 (½) | 45 530 ½  |

Transfer amount R72 556

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 4