# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
BOOKKEEPING / BOEKHOU
PART 4 / DEEL 4

10 FEBRUARY / FEBRUARIE 2016

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A
CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER: This guideline records the views of the drafters. There may be
justifiable variations in practice which are brought out in the answers.
When this happens the examiner should apply his discretion in marking
the answer.

QUESTION 1

[40]

TRUST CASH BOOK

|  To Minnie (Correspondent) | 30 000 | By agent (Correspondent) | 6 454  |
| --- | --- | --- | --- |
|   |  | By transfer to Business | 23 546  |

BUSINESS CASH BOOK

|  To transfer ex Trust | 23 546 | By Sheriff (Mickey) | 900  |
| --- | --- | --- | --- |
|   |  | By Counsel | 7 500  |
|   |  | By Sheriff | 1 500  |

TRUST LEDGER – CORRESPONDENT

|  To cash | 6 454 | By cash debtor | 30 000  |
| --- | --- | --- | --- |
|  To Business transfer | 23 546 |  |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

Page 1