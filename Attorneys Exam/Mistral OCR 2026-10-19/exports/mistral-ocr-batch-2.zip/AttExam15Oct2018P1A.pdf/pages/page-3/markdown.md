- TAKE NOTE FURTHER THAT the defendant is entitled to request security for costs on the basis that, inter alia that plaintiff is a peregrinus (1) who owns no unmortgaged or indeed any immovable property in South Africa (1).

# QUESTION 6

[10]

6.1

6.1.1 If the Plaintiff sues for damages, he/she shall set them out in such a manner as will enable the Defendant reasonably to assess the quantum thereof; (1)

6.1.2 A Plaintiff suing for damages for **personal injury** shall specify his date of birth, the nature and extent of the injuries, and the nature, effect and duration of the disability alleged to give rise to such damages; (2)

6.1.3 the Plaintiff shall as far as practicably possible state separately what amount, if any, he has claimed for –

a) medical costs and hospital and other similar expenses, and how these costs and expenses are made up; (1)

b) Pain and suffering, stating whether temporary or permanent, and which injuries caused it; (1)

c) Disability in respect of –

(i) The earning of income (stating the earnings lost to date, and how the amount is made up, and the estimated future loss and the nature of the work the Plaintiff in future will be able to do); (1)

(ii) The enjoyment of amenities of life (giving particulars) and stating whether the disability concerned is temporary or permanent. (1)

d) Disfigurement, with a full description thereof and stating whether it is temporary or permanent. (1)

6.2 If a party fails to comply with any of the provisions of Rule 18, such pleading shall be deemed to be an **irregular step** and the opposite party shall be entitled to act in accordance with Rule 30, which deals with Irregular proceedings. (2)

# QUESTION 7

[10]

7.1 The accused is **not** obliged to answer questions. Suspects and accused have a fundamental **right to remain silent** (Section 35(1)(a) and Section 35(3)(h) of the Constitution). (2)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D.]™

3