7.2 The only information which he is obliged to give to the investigating officer is his name and address - Section 41 of the CPA. (2)
7.3 He cannot refuse to be questioned but can refuse to answer the questions. (2)
7.4 His refusal to answer questions cannot be held against him at a later trial as his right to remain silent is enshrined in the Constitution and the accused need not assist the State in any manner whatsoever to prove his guilt. (2)
7.5 Under certain circumstances it is indeed advisable to make a statement, particularly when your client intents pleading not guilty and has a feasible defence. It could be in his interest to place same on record as soon as possible to exclude the subsequent argument of the Prosecutor of same being a recent fabrication. Having a statement on record could also dissuade the prosecutor from proceeding with the prosecution when he is obliged to weigh up the probabilities of a conviction. (2)

# QUESTION 8

[5]

In terms of Section 217 and 219 A the statement:

8.1 Must be shown to have been made freely and voluntarily.
8.2 The accused must have been at the time in his sober senses.
8.3 There must have been no undue influence exercised on him to induce him to make such a statement.
8.4 The accused must have been informed of his constitutional right to remain silent.
8.5 The accused must have been informed of his constitutional right to require that his legal representative be present when the statement is taken.
8.6 The statement must have been made before a magistrate.
8.7 The accused must have been informed that the statement will be used in evidence against him.

# QUESTION 9

[3]

9.1 The accused can apply for acquittal in terms of Section 174. (1) (Note to examiners: Should the candidate discuss bringing an application in terms of Section 174 and motivates the answer give another mark)
9.2 The accused can close his case and lead no evidence. (1)
9.3 The accused can testify and lead evidence. (1)

# QUESTION 10

[7]

In Regional Court for the Regional Division of Western Cape
Held at BELLVILLE

Case No: 132/2014

In the matter between:

James Activist

Applicant

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4