And

The State

(1)

# NOTICE OF APPLICATION FOR LEAVE TO APPEAL

BE PLEASED TO TAKE NOTICE that the Applicant hereby gives notice of his intention to apply for leave to appeal to the CAPE TOWN High Court of South Africa against the sentence imposed upon him by the Regional Magistrate, Mr Goliath, sitting at the Regional Court number 4 on the 15th of June 2018. (2)

The grounds of appeal are as follows:

1. The sentence imposed on the Applicant induces a sense of shock;
2. The learned Magistrate failed to take into consideration the personal circumstances of the Applicant and in particular that he is a student and young man and a first offender;
3. The Magistrate erred in not considering the circumstances under which the offence was committed;
4. The Magistrate erred in not taking into consideration that the aims of the Fees Must Fall movement is noble;
5. The Magistrate erred in not considering that circumstances under which the offence was committed;
6. The Learned Magistrate erred in not taking into consideration the fact that the Applicant did not commit the offence for selfish reasons but for the greater good of all the students;
7. The Magistrate over-emphasized the seriousness of the offence and did not take into consideration the interests of the students in this matter;
8. The Magistrate erred in not finding that there were substantial and compelling circumstances making it possible not to impose a custodial sentence.
9. ETC, ETC (To the examiner: allow the students to use their imagination / discretion) (3)

DATED AT Bellville ON THIS DAY OF 2018.

APPLICANTS ATTORNEYS

TO: The Clerk of the Court

Bellville

(½)

AND TO: THE PROSECUTOR

REGIONAL COURT

Bellville

(½)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5