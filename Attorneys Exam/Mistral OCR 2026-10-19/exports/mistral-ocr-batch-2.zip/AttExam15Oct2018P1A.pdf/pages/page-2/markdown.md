respect of his contact lenses, his cell phone and his vehicle may not be recovered from the Road Accident Fund and will have to be recovered from the driver of the vehicle (1) in which the client was a passenger at the time of the accident, personally, since these damages are not for bodily injuries. (1)

# QUESTION 3

[5]

3.1 John's claim will be reduced by \(50\%\). (1)
3.2 John's claim will be rejected / repudiated. (1)
3.3 None. (1) For John's claim to succeed in full \((100\%)\), \(1\%\) negligence (1) must be proven on the part of either driver. (1).

# QUESTION 4

[9]

4.1 A notice shall be served notifying all other parties of his intention to amend \((\frac{1}{2})\) and shall furnish particulars of the amendment. \((\frac{1}{2})\).
4.2 A written objection to the proposed amendment must be delivered within ten (10) \((\frac{1}{2})\) days of delivery of the notice to amend and shall clearly and concisely state the grounds upon which the objection is founded. \((\frac{1}{2})\)
4.3 The amending party may, within ten (10) days of the expiration of the period available for the objection effect the amendment by filing the amended pages. (1)
4.4 The party affected by the amendment may within fifteen (15) days (1), or within such other period as the Court may determine (1) make any consequential adjustment to the pleadings filed by him (1) and may also except to the pleading (Rule 23) or may take steps to have any irregular proceeding set aside (Rule 30) (1).
4.5 A party giving notice of amendment shall, unless the Court otherwise directs \((\frac{1}{2})\) be liable for the costs thereby occasioned to any other party \((\frac{1}{2})\).
4.6 An amendment may be effected at any stage before judgment (1).

# QUESTION 5

[6]

NOTE TO EXAMINER: A notice addressed to the registrar and the plaintiff and not an application is applicable. (1)

- KINDLY TAKE NOTICE that the defendant hereby demands security for costs from the plaintiff in the amount of R250 000,00 (Two Hundred and Fifty Thousand Rand) (1)
- TAKE NOTE FURTHER THAT the amount of R250 000,00 (Two Hundred and Fifty Thousand Rand) is a reasonable estimate of the costs which the defendant would incur (1) and for which the plaintiff would be liable should the above Honourable Court rule in favour of the defendant and award costs in favour of the defendant. (1)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2