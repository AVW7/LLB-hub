QUESTION 11

[10]

Please note maximum of 10 marks

1. The Johannesburg Magistrates Court does not have jurisdiction.
2. Peter Jones cannot institute action as he is an unassisted minor.
3. Either the registered office or the principal place of business of the First Defendant needs to be dealt with in this citation.
4. There needs to be an allegation that the Plaintiff is the owner of the motor vehicle.
5. There needs to be an allegation that at the time of the collision the Second Defendant was driving in the course and scope of his employment with the First Defendant.
6. Details of the Second Defendant's negligence are required.
7. A copy of the document in support of the claim for damages needs to be annexed or the detail and calculations of the damages should be alleged.
8. The prayer needs to reflect that judgment is to be joint and severable, the one paying the other to be absolved.
9. The District Magistrates Court does not have jurisdiction for an amount of R220 000.00.
10. Interest will not be \(15\%\) but at the current prescribed rate.
11. Interest is claimed either from the date of the expiry of the letter of demand or from the date of service of the summons.
12. Allegations in support of costs on the scale as between attorney and client are required.

QUESTION 12

[7]

12.1 Financial enquiry into the affairs of the Close Corporation in terms of Section 65. (1)
12.2 Application for a Garnishee Order. (1)
12.3 Application for the liquidation of the Close Corporation. (1)
12.4 Application to place the Close Corporation under business rescue. (1)
12.5 Interpleader Summons. (1)
12.6 Application for Summary Judgment. (1)
12.7 Application for the Appointment of a Curator ad Litem. (1)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

6