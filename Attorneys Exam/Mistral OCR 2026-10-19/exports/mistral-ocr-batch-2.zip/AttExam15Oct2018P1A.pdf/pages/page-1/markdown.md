# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
COURT PROCEDURES /HOFPROSEDURES
PART 1 / DEEL 1

15 OCTOBER / OKTOBER 2018

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE
A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF
READING.

NOTE TO EXAMINER: This guideline records the views of the drafters. There may be
justifiable variations in practice which are brought out in the
answers. When this happens the examiner should apply his
discretion in marking the answer.

# QUESTION 1 [15]

1.1 Yes. (1) As the 120 day period (subsequent to the lodgement of the claim) has elapsed, summons may be served irrespective of whether there is an offer or repudiation. (1)
1.2 No. (1) A grandparent does not have locus standi and a curator-ad-litem will have to be appointed to act on Wilfred's behalf. (1)
1.3. No (1) Wilfred is 6 years old (1) and accordingly dolus and culpa incapax / legally incapable of negligence (1).
1.4. A power of attorney (1), signed by the duly appointed curator-ad-litem must be forwarded to the RAF. (1).
1.5 As it is a "hit and run" / unidentified claim (1), within 5 years of the date of the collision / on or before 14th of February 2023. (Either answer is acceptable.) (1)
1.6 Mrs Kunene should be advised that the deduction is not permissible, (1) as the child support grant is a collateral benefit. (1)
1.7 The funds due to a minor cannot be paid to her (1) and will have to be paid to the duly appointed curator bonis (1).

# QUESTION 2 [5]

His damages due to the bodily injuries (1) which he sustained in the accident, namely:
general damages, past medical and hospital expenses, future medical expenses and future
loss of earnings can be recovered from the Road Accident Fund (1) due to the fact that it
arose out of the negligent driving of a motor vehicle. (1) The damages which he suffered in

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1