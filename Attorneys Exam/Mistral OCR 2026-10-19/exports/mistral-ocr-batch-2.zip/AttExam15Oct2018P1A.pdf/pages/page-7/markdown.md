# QUESTION 13

[4]

13.1 Send a Section 129 notice in terms of the National Credit Act. (1)
13.2 BBB (Pty) Ltd as the right, title in interest to the loan was ceded to them by ASF Bank. (1)
13.3 CCC Limited and Mr. X will both be cited as defendants as Mr. X is the debtor and CCC Limited signed as surety for the debt. (2)

# QUESTION 14

[4]

Original Summons

Original Return of Service

Original and one copy of a Request for Default Judgment

Damages Affidavit

TOTAL: [100]

# LAW SOCIETY

# OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

7