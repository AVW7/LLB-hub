# **ADMISSION EXAMINATION / TOELATINGSEKSAMEN  
BOOKKEEPING / BOEKHOU  
PART 4 / DEEL 4**

**15 FEBRUARY / 15 FEBRUARIE 2017**

**ANSWERS / ANTWOORDE**

**PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY  
NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE  
MOMENT OF READING.**

**NOTE TO EXAMINER:** *This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.*

**QUESTION 1**

**[15]**

# **1.1 TRANSFER JOURNAL**

Client (T) Dr 4 500  
Client (B) Cr 4 500  
Being transfer from Trust to Business

# **1.2 BUSINESS JOURNAL**

Rich Dr 7 500  
Poor Cr 7 500  
Being incorrect (erroneous) debit being corrected

# **1.3 BUSINESS JOURNAL (FEE JOURNAL)**

Fees Dr 7 000  
Client Cr 7 000  
Being correction of overcharge

**LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™**

1