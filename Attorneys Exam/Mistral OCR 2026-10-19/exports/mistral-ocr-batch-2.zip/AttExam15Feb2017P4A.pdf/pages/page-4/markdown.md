FEES

|   | Correspondent | 10 000  |
| --- | --- | --- |

VAT

|   | Correspondent | 1 400  |
| --- | --- | --- |

(1 mark each =16)

JOURNAL ENTRIES (BUSINESS)

|  Purchaser | Dr | 45 600  |
| --- | --- | --- |
|  Correspondent | Cr | 45 600  |

Being fees due to Correspondent

|  Correspondent | Dr | 11 400  |
| --- | --- | --- |
|  Fees | Cr | 10 000  |
|  Vat | Cr | 1 400  |

Being allowance on Fees

(5 marks)

**NOTES:**

1. Transaction dates should be shown in the ledger accounts.
2. Correspondent could be paid from the Trust banking account so that the first journal entry would not be necessary.

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4