## 1.4 BUSINESS JOURNAL

|  Mrs Cross | Dr | 5 000  |
| --- | --- | --- |
|  Counsel | Cr | 5 000  |
|  Being fees due in divorce action  |   |   |

## 1.5 BUSINESS JOURNAL

|  Bad debts | Dr | 2 500  |
| --- | --- | --- |
|  Client | Cr | 2 500  |
|  Being amount written off  |   |   |

(3 marks each Journal entry)

## QUESTION 2 [15]

### 2.1 SUPPLEMENTARY CASH BOOK FOR JUNE 2016

|  Balance (1) | 943 210 | Cheque (error) (1) | 104 930  |
| --- | --- | --- | --- |
|  Interest (1) | 17 730 | RD Cheque (1) | 21 780  |
|  Error (1) | 109 340 | Error (Deposit) (1) | 188 820  |
|  Deposit (1) | 128 820 | Balance (1) | 883 570  |
|   | **1 199 100** |  | **1 199 100**  |

### 2.2 BANK RECONCILIATION STATEMENT AT 30 JUNE 2016

|  Overdraft as per Bank statement | 319 580 | (1)  |
| --- | --- | --- |
|  Add: unpresented cheques | 179 980 | (1)  |
|  O/D | 499 560 |   |
|  Less: deposit | 81 190 | (1)  |
|  O/D | 418 370 |   |
|  Less: error cheque (business) | 1 342 300 | (1)  |
|  Balance | 923 930 |   |
|  Less: error deposit (business) | 40 360 | (1)  |
|  Cash book balance | **883 570** |   |

### 2.3 Ask the Bank to reverse the payment or pay the amount from Business to Trust (2)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2