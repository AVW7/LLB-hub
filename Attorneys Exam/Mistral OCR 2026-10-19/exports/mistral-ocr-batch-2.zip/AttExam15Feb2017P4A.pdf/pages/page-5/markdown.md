# **TRANSFER OF PROPERTY**

|  Proceeds from Bank |  | 2 000 000  |
| --- | --- | --- |
|  Cheque you |  | 1 000 000  |
|  Transfer & bonds costs received |  | 200 000  |
|  Paid Transfer Duty | 150 000 |   |
|  Fees on transfer | 40 000 |   |
|  Vat thereon | 5 600 |   |
|  Paid Seller | 3 000 000 |   |
|  Interest received on Investments |  | 5 800  |
|  Cheque to you interest | 5 800 |   |
|  Cheque to you refund | 4 400 |   |

3 205 800 3 205 800

(5 marks)

# **QUESTION 4** [20]

4.1 a) quarterly (2)

b) names of each creditor and the amount due to the creditor total of the list total to be compared with total of trust money available on investments and in the bank. (2)
c) trial balance or ledger account (2)
d) 5 years (2)

(12 marks)

4.2 either obtain written instructions from client or invest the monies in a Section 78 (2)(a) investment for the benefit of the Fidelity Fund

(8 marks)

TOTAL: [100]

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5