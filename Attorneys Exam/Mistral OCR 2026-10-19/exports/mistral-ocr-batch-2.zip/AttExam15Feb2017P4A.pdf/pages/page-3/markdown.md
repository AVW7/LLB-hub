QUESTION 3

[50]

TRUST CASH BOOK

|  4 Feb Purchaser | 1 000 000 | 5 Feb Phoenix Bank | 1 000 000  |
| --- | --- | --- | --- |
|  Purchaser | 200 000 | Corres (T/Duty) | 150 000  |
|  26 Feb Phoenix Bank | 1 005 800 | 26 Feb Corres | 1 000 000  |
|   |  | T/F | 45 600  |
|   |  | Purchaser | 5 800  |
|   |  | Purchaser | 4 400  |
|   | 2 205 800 |  | 2 205 800  |

BUSINESS CASH BOOK

|  T/F | 45 600 | Corres | 34 200  |
| --- | --- | --- | --- |
|   |  |  | (2 marks each =24)  |

TRUST LEDGER - PURCHASER

|  Cash – Correspondent | 150 000 | Cash - Deposit | 1 000 000  |
| --- | --- | --- | --- |
|  Cash – Correspondent | 1 000 000 | Cash - Costs | 200 000  |
|  Cash – Correspondent | 45 600 |  |   |
|  Cash – Correspondent | 4 400 |  |   |
|   | 1 200 000 |  | 1 200 000  |

BUSINESS LEDGER - PURCHASER

|  Fee | 45 600 | T/F | 45 600  |
| --- | --- | --- | --- |

S78 (2) (A) – PHOENIX BANK (ITF PURCHASER)

|  Cash | 1 000 000 | Cash | 1 005 800  |
| --- | --- | --- | --- |
|  Cash - Interest | 5 800 |  |   |

BUSINESS LEDGER - CORRESPONDENT

|  Fees | 11 400 | Fees | 45 600  |
| --- | --- | --- | --- |
|  Cash | 34 200 |  |   |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3