# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
BOOKKEEPING / BOEKHOU
PART 4 / DEEL 4

11 FEBRUARY / 11 FEBRUARIE 2015

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

QUESTION 1

[20]

(a) Transfer the amount from Business to Trust

Credit Business Cash Book

Debit Bank Charges

Debit Trust Cash Book

Credit Bank charges

(4)

(b) Transfer amount from Business account to Trust account

Credit Trust Cash Book debit client

Credit Business Cash Book

Debit client Business

Debit Trust Cash Book

Credit client Trust

(5)

(c) Debit Trust Cash Book R20 000

Credit Trust Ledger R20 000

Credit Trust Cash Book R200 000

Debit Trust ledger R200 000

ALTERNATIVELY

Debit Trust Ledger R180 000

Credit Trust Cash Book R180 000

(4)

(d) Debit Black Trust Ledger for R500 000

Credit White Trust Ledger for R500 000

(2)

(e) Wait for cheque to clear then transfer amount from Trust to Business

Credit Trust Cash Book

Debit Business Cash Book

(2)

(f) Transfer R30 000 from Business to Trust

Credit Business Cash Book - debit Business Ledger

Debit Trust Cash Book – credit Trust Ledger

Debit Business Cash Book – credit Business Ledger

(3)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1