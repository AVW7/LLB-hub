QUESTION 2

[20]

# 2.1 Discussion:-

The account in the Trust Ledger has business entries, eg - fees and disbursement to Counsel when there was insufficient funds in trust and fees are debited in the business account.

You will be required to transfer R50 000 from the Business account to Trust account. (8)

2.2 Transfer R50 000 from Business to Trust (counsel paid from Trust when there was insufficient funds) (2)
2.3 Fees cannot be debited in Trust - must be debited in Business account. Cancel entry in Trust account (2)
2.4. You can transfer the debit balance of R75 000 in Business account from Trust account. (2)

GREEN - (TRUST)

|  Balance | 76 900 | Balance | 1 900  |
| --- | --- | --- | --- |
|   |  | Cash | 50 000  |
|   |  | Error | 25 000  |
|   | 76 900 |  | 76 900  |
|   |  | Balance | 76 900  |

GREEN (BUSINESS)

|  Cash | 50 000  |
| --- | --- |
|  Fees | 25 000  |

QUESTION 3

[40]

TRUST CASH BOOK

|  Jan 2 | Green - Cash | 1 500 000 | Jan 3 | ABSA Bank | 1 500 000  |
| --- | --- | --- | --- | --- | --- |
|   | Green - Cheque | 250 000 | 7 | R/D Cheque | 250 000  |
|   | Green - Cheque | 150 000 | 30 | Seller - Zama | 8 000 000  |
|  8 | Green - Cash | 250 000 |  | Green | 50 000  |
|  30 | Nedbank | 6 500 000 |  | Transfer to business | 400 000  |
|   | Nedbank | 1 550 000 |  |  |   |
|   |  | 10 200 000 |  |  | 10 200 000  |

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2