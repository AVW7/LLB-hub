# BUSINESS CASH BOOK

|  Jan 31 Transfer Trust | 400 000 | Jan 4 Transfer Duty | 150 000  |
| --- | --- | --- | --- |

# TRUST LEDGER – (GREEN)

|  Jan 7 Cheque - RD | 250 000 | Jan 2 Cash - Deposit | 1 500 000  |
| --- | --- | --- | --- |
|  30 Cheque - Zama | 8 000 000 | Cheque - Transfer | 250 000  |
|  Transfer to business | 400 000 | Cheque - Bond | 150 000  |
|  Cash | 50 000 | 8 Cash | 250 000  |
|   |  | 30 Guarantee | 6 500 000  |
|   |  | Interest | 50 000  |
|   | 8 700 000 |  | 8 700 000  |

# TRUST INVESTMENT S78 (2A) – ABSA (GREEN)

|  Jan 3 Cash | 1 500 000 | Jan 30 Cash | 1 500 000  |
| --- | --- | --- | --- |

# BUSINESS LEDGER - GREEN

|  Jan 4 Cash - Transfer duty | 150 000 | Jan 30 Transfer Trust | 400 000  |
| --- | --- | --- | --- |
|  30 Fees - Transfer | 100 000 |  |   |
|  Fees - Bond | 150 000 |  |   |
|   | 400 000 |  | 400 000  |

# FEES

|   | Jan 30 Green - Transfer | 100 000  |
| --- | --- | --- |
|   | Green - Bond | 150 000  |

# Journal (Fee)

|  Jan 30 Green (B) | Dr | 100 000  |
| --- | --- | --- |
|  Fees | Cr | 100 000  |

# Being transfer Fees

|  Jan 30 Green (B) | Dr | 150 000  |
| --- | --- | --- |
|  Fees | Cr | 150 000  |

# Being Bond fees

# Transfer Journal

|  Jan 30 Green (T) | Dr | 400 000  |
| --- | --- | --- |
|  Green (B) | Cr | 400 000  |

Transfer fees + Disbursements

(1 mark each entry in the cash & ledger books – (31)

and 3 marks each for journal entry (9)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3