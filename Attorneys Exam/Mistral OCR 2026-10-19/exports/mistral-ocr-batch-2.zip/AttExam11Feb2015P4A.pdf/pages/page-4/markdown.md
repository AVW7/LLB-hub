QUESTION 4

[20]

TRUST LEDGER – (RICH)

|  Cash (Unit Trust) | 500 000 | Balance | 2 000 000  |
| --- | --- | --- | --- |
|  Cheque - RD | 500 000 | Cheque - Business | 500 000  |
|  Cheque - Interest | 150 000 | Cash (Unit Trust) | 550 000  |
|   |  | Interest | 150 000  |

TRUST INVESTMENT S78 (2A) – RICH

|  Cash | 1 000 000 | Cash | 1 000 000  |
| --- | --- | --- | --- |

TRUST CASH BOOK - RICH

|  Balance | 2 000 000 | Investment | 1 000 000  |
| --- | --- | --- | --- |
|  Rich | 500 000 | Rich | 500 000  |
|  Investment | 1 150 000 | R/D | 500 000  |
|  Unit Trust | 550 000 | Rich | 150 000  |

1. You are required to obtain a written mandate from Mrs Rich;
1.1 to invest the monies in a section 78 2(A) account and;
1.2 to purchase Unit Trust on her behalf
2. Credit the trust cash book and debit Mrs Rich's Trust Ledger Account

(1 mark for each entry in cash and ledger book (17) and 3 marks for explanations

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4