- Ease of future management and administration
Less outside administration in future
Less expense in future administration
- Easy to make contributions in kind and value (6)

# 6.2 Benefits of company

The following are essential elements:

Separate personality which means

- Possible non personal liability and
- Continued existence after death of member
- Something about insolvency/liquidation
- More flexible tax position
- Act provides guidance on administration (6)

# QUESTION 7

[12]

Legal professional privilege and confidentiality apply to communications between you and your client:

7.1 where the communication relates to your professional or intended professional relationship;
7.2 made for the dominant purpose of seeking or giving legal advice or for use in existing or anticipated legal proceedings;
7.3 whether written or oral and even;
7.4 where the client confesses to you the commission of a prior crime or fraud.

Bear in mind that it is information that is protected by privilege. If such information is contained in a document, the document is privileged. If, however, the document is contained in a file containing a number of documents, the entire file does not become protected by privilege.

Professional privilege does not apply to:

documents which are not otherwise privileged. They do not become privileged merely because your client hands them to you;
- communications made for the purpose of facilitating a crime or fraud. Harksen v Attorney-General Cape and Others 1999(1) SA 718(C), Waste Products Utilisation (Pty) Ltd v Wilkes and Another 2003(2) SA 515 (W).
the name of your client - you can be compelled to disclose it;
- facts learned by you with your own senses and;
where a statute expressly or by implication provides that the privilege is inapplicable.

# QUESTION 8

[25]

8.1.1 This agreement is conditional upon the purchaser obtaining a bond on standard terms for R750 000 within 30 days from date hereof. If the bond is not obtained this agreement shall be null and void and neither party shall have any claim against the other arising herefrom. (5)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

3