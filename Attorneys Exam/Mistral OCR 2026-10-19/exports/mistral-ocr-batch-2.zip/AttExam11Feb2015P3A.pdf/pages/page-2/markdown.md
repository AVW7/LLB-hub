3.1 It is acceptable to reduce fees in the case of large volumes of work. The fee must still be reasonable. (3)
3.2 Attorneys may not share fees with non-professionals. Paying for mandates is an extreme form of touting. (3)
3.3 Supporting a client is in order if it is done in good taste. Neither the publicity, nor the prizes may be excessive or extravagant. (3)
3.4 Accepting secret commissions is against common law rules and could also constitute touting and sharing of fees. Declare commission. (3)

# QUESTION 4 [8]

The practitioner should feel free to accept the mandate. It is a fairly routine matter and will assist in gaining experience. It is not wrong to seek help from an experienced colleague and to ask for precedents but own research is essential. Inform the client that you wish to study the legal position and procedure.

Firstly study a text book on the topic and available authority (e.g. previous judgements) which clarify the rules. If you experience problems, use further assistance in a good library such as a noter-up. As guide to the drafting of the relevant documents consult practice guides (Forms and Precedents, etc.). The most important requirement is that the documents are thoroughly and carefully drafted and that the attorney properly prepares and qualifies himself. Be careful of negligence.

# QUESTION 5 [8]

The introduction of FICA impinges upon the traditional role and independence of the attorneys' profession and upon the confidentiality of all communications between attorneys and their clients. Apart from having the duty to establish and verify the identity of clients and of their authority, they are obliged to keep detailed records of clients, business relationships and of transactions for a specified period; they are also under an obligation:

5.1 to make such records available to the Financial Intelligence Centre on the strength of a warrant;
5.2 to inform the centre on request of the existence of a current or past mandate;
5.3 to report cash transactions above a prescribed amount to the Centre; and;
5.4 to report to the Centre the conveyancer in terms of a transaction with a client of cash above a prescribed amount to or through a specified account or institution.

# QUESTION 6 [15]

There will be a number of ways of answering this question. The appended list is not necessarily comprehensive. There may also be others that are raised and may be accepted. The additional 3 marks go for style, clarity, comprehension and presentation.

6.1 Benefits of partnership (six of)

Cost of procedure
- Simplicity to arrange
- Quicker to establish

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

2