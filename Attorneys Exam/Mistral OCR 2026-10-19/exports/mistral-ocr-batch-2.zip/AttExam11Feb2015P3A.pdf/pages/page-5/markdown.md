The seller has instructed us to give you notice in terms of the breach clause (clause 15), as we hereby do, to remedy the breach and make payment to us within 7 days from date hereof failing which the seller will be ascertaining his rights in terms of the aforesaid agreement.

We accordingly await to here from you.

TOTAL: [100]

![img-0.jpeg](img-0.jpeg)

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

5