8.1.2 Should the purchaser be advised in writing that his application for a bond for R750 000 in respect of the purchase price has been unsuccessful or should the purchaser not be successful in obtaining the said bond within 21 days from date of signature hereof, this agreement shall terminate and each party shall, insofar as any terms of this agreement have been implemented, be obliged to restore the other to the same position as he would have been had the agreement never been concluded. (5)

8.2 The issue involved in this question is the indemnity of the seller by the purchaser. If the seller had employed agents and is likely to be responsible towards them for commission he must be sure that the purchaser who approaches him directly has not in fact been introduced by an agent. In addition it is likely that if the seller sells directly he will have discussed a reduction in the purchase price because he will be relieved of paying commission. These factors must be taken into consideration. An answer along these lines is suggested:

8.2.1 The purchaser confirms that this contract was entered into without the purchaser having been introduced to the seller directly or indirectly by any estate agent or that any agent was the effective cause for the conclusion of this contract of sale.

8.2.2 As a result of the sale by the seller to the purchaser on these grounds the purchase price has been reduced by an amount equal to the expected agent's commission.

8.2.3 The purchaser consequently indemnifies the seller against any legitimate claim which may be brought against the seller for agent's commission arising from this sale. The seller shall call upon the purchaser to assist the seller in any actual or threatened litigation arising from any claim for commission and to put the seller in funds to do so. The seller shall however be free to decide on the best manner of settlement of any such action. Any costs or charges including legal fees on all scales and any capital sum payable shall be recoverable form the purchaser as liquidated damages. (10)

8.3

Mr John Drake

378 Long Market Street

Pietermaritzburg

PER REGISTERED POST

Dear Sir,

Re: Purchase of Property Erf 102 Pietermaritzburg

We refer to the agreement of purchase and sale concluded between you and the Trustees of the Peter Smith Family Trust dated the 20th of February 2014.

In terms of clause 3 of the agreement the deposit was payable within 15 days.

You have failed to make the aforesaid payment, despite several requests.

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

4