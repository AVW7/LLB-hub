# ADMISSION EXAMINATION / TOELATINGSEKSAMEN

# ATTORNEYS' PRACTICE / PROKUREURSPRAKTYK

# PART 3 / DEEL 3

# 11 FEBRUARY / FEBRUARIE 2015

# ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be justifiable variations in practice which are brought out in the answers. When this happens the examiner should apply his discretion in marking the answer.

# QUESTION 1

[14]

1.1 The appointment of such a person is normal practice. However the practitioner must supervise the work and remains ultimately responsible for whatever is done. (3)
1.2 Clients may be seen and new matters accepted only in the field of expertise of the non-professional. (2)
1.3 These activities fall within the normal duties of a collection assistant but the practitioner must supervise the results and give guidance on what should be done. (2)
1.4 Legal advice is a professional activity and may not be given by support staff. (2)
1.5 High Court matters are always specialised and professional work and must be attended to by professionals. (3)
1.6 No. This entails abandoning control of trust funds. At most he/she can be a co-signatory. (2)

# QUESTION 2

[6]

It is normal that the attorney will not be familiar with accounting systems or computer programmes. This does not mean that trust books must be written up by hand if that is what the attorney knows. Attorneys must find out enough to ensure that the computer systems entail compliance with the Act and Rules and must be able to check that the system is being adhered to.

# QUESTION 3

[12]

Candidates must show insight into the applicable Law Society's rules on marketing as opposed to touting.

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1