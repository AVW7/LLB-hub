QUESTION 4

[10]

# CODICIL [1]

I, the undersigned,

PHILLIP NEL,

of Bloemfontein, make the following codicil to my last will and testament dated 5 October 2014. [1]

1.

I revoke paragraph 3.5 of my said will and substitute for it the following: [2]

I bequeath R700 000. 00 (seven hundred thousand rand) in cash to my girlfriend Goodness. [1]

2.

My said will remains unaltered in all other respects. [2]

Thus done and signed at Bloemfontein on 17 May 2015 by the testator and the undersigned witnesses, all being present at the same time. [1]

AS WINESSES:

1. [1/4]
2. [1/4]

TESTATOR [1]

QUESTION 5

[4]

5.1 In terms of Section 2 B of the Wills Act No. 7 of 1953, because A died within three months of his divorce without executing another valid Will, his ex-wife will not inherit unless the contrary appears from his Will. (3)
5.2 If A did not execute another valid Will and more than 3 months have elapsed since his divorce, his ex-wife will inherit unless the contrary appears from his Will. (1)

TOTAL: [100]