|  Income & Expenditure Account |  |   |
| --- | --- | --- |
|  Interest paid on investment account |  | 15 000.00[1]  |
|  Dividend paid on LEBS Ltd shares |  | 54 000.00[1]  |
|  Executor's remuneration @ 6% on R 69 000.00 | 4 140.00[1] |   |
|  VAT @ 14% on R4 140.00 | 579.60[1] |   |
|  Balance awarded to Simon as sole heir | 64 280.40 [1] |   |
|   | 69 000.00 | 69 000.00  |
|  Fiduciary Assets Account |  |   |
|  None |  | Nil [1]  |
|  Estate Duty Addendum |  |   |
|  Property of the deceased |  |   |
|  Assets as per liquidation account |  | 4 505000.00[1]  |
|  Less: Life Insurance Policy C | 225 000.00[1] |   |
|  Less: Difference in value of private shares | 20 000.00[1] | 4 280 000.00  |
|  Less: 30% on Farming property | 690 000.00[1] | 4 260 000.00  |
|   |  | 3 570 000.00  |
|  Property Deemed to be Property |  |   |
|  Add: Proceeds of Life Insurance Policy C |  | 225 000.00[1]  |
|  Proceeds of Life Insurance Policy B payable to Simon |  | 295 000.00[1]  |
|  Gross value of the estate |  | 4090 000.00[1]  |