# ADMISSION EXAMINATION / TOELATINGSEKSAMEN
ESTATES / BOEDELS
PART 2 / DEEL 2

16 AUGUST / 16 AUGUSTUS 2016

ANSWERS / ANTWOORDE

PLEASE NOTE THAT THE GUIDELINE ANSWERS TO PREVIOUS PAPERS MAY NOT BE
A CORRECT REFLECTION OF THE LAW AND/OR PRACTICE AT THE MOMENT OF
READING.

NOTE TO EXAMINER:

This guideline records the views of the drafters. There may be
justifiable variations in practice which are brought out in the
answers. When this happens the examiner should apply his
discretion in marking the answer.

QUESTION 1

[66]

The First and Final Liquidation and Distribution Account in the estate of the late Jack
Lee (Identity Number 640315 5638 08 3) [1] who died on 1 July 2015 [1] and who was
unmarried at the time of his death [1].
Master's reference number : 1369/2015 [1]

LAW SOCIETY
OF SOUTH AFRICA

LEGAL EDUCATION AND DEVELOPMENT [L.E.A.D]™

1