|  Liabilities: |  |   |
| --- | --- | --- |
|  Administration Costs |  |   |
|  1. Advertising for Debtors and Creditor |  |   |
|  Government Gazette | 40.60 [½] |   |
|  Pretoria News | 359.40[1] |   |
|  2. Advertising Account for inspection |  |   |
|  Government Gazette | 40.60 [½] |   |
|  Pretoria News | 359.40[1] |   |
|  3. Master's fees (maximum) | 600.00[1] |   |
|  4. Executor's fees at 3.5% on R4 505 000.00 | 157675.00[1] |   |
|  5. 14% VAT ON R157 675.00 | 22 074.50[1] |   |
|  6. Bank charges | 1 000.50[1] |   |
|  7. Postage and petties | 150.00[1] |   |
|  8. Brokers fees for valuation of JSE shares | 17 000.00[1] |   |
|  9. Valuation costs | 12 000.00[1] |   |
|  10. Transfer costs | 48 700.00[1] |   |
|  11. Sleep – funeral expenses | 40 000.00[1] |   |
|  Claims against the estate |  |   |
|  12. Final income tax assessment | 100 000.00[1] |   |
|  Total Liabilities | 400 000.00[1] |   |
|  Estate Duty | 34 962.06[1] |   |
|  Balance for distribution | 4 070 037.94 |   |