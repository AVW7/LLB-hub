QUESTION 2

[13]

The estate will be distributed as follows:

Dudu will firstly get her half share of the joint estate in the amount of R450 000.00 because of their marriage in community of property; [1] and the other half share of Zwane's estate will devolve as follows:

If Dudu's unborn child is born alive [1] then Dudu, Joshua, and the unborn child (nasciturus fiction) are the intestate heirs. [1]

Dudu inherits either a child's share or R250 000.00, whichever is the greater (Section 1(1)(c) ) of the Intestate Succession Act, as amended. [1]

A child's share is R450 000.00 ÷ 3 = R150 000.00 [1]

Dudu therefore inherits R250 000.00 [1]

Joshua and the unborn child inherit the remainder thereof in the amount of R100 000.00 each [2] because they are descendants in terms of Section 1(1)(c) of the Intestate Succession Act.

Joshua cannot renounce his rights to inherit as he is a minor, (Section 1(6) ) [1]

However, if the unborn child is not born alive [1], then Dudu will inherit R250 000.00 and Joshua will inherit the remainder thereof in the amount of R200 000.00 [1]

Solly and Rose will inherit nothing. [1]

QUESTION 3 [7]

3.1 The letter that Robert left behind is not a valid Will as it was not signed by witnesses [1].
3.2 In terms of Section 2(3) the Court is empowered to order the Master to accept a document as a valid Will [1] if the Court is satisfied that it was drafted or executed [1] by a person, who has since died [1], and who intended that document to be his or her Will [1], although it does not comply with all the formalities for the execution of Wills [1]. Therefore Steve and Doris will inherit if the court is satisfied that Robert intended the letter to be his Will [1].