|  Deductions – Sect 4 |  |   |
| --- | --- | --- |
|  Costs of Administration and claims | 400 000.00 | 400 000.00[1]  |
|  Net value of the estate |  | 3690 000.00[1]  |
|  Less: Primary Rebate – Sect 4A |  | 3500 000.00[1]  |
|  Dutiable Amount |  | 190 000.00[1]  |
|  Estate Duty at 20% on R190 000.00 |  | 38 000.00[1]  |
|  Apportionment of estate duty payable |  |   |
|  Simon for Insurance Policy B |  |   |
|  R295 000.00/ R3 690 000.00 X R38 000.00 | R3 037.94 [1] |   |
|  Estate duty payable by the estate |  | R 34 962.06[1]  |

# Certificate

I the undersigned, Angela Ma, executrix in the estate of the late Jack Lee No.1369/2015, hereby declare that the estate account is to the best of my knowledge and believe a true and proper account of the liquidation and distribution account of the estate [1], and that to the best of my knowledge and belief all the assets and income collected to date of this account has been disclosed herein. [1].

Signed at Pretoria on this 10th day of December 2015 [1].

Angela Ma

Executrix