|  Recapitulation Statement |  |   |
| --- | --- | --- |
|  Cash and assets reduced to cash |  | 1419 000.00[1]  |
|  Less: |  |   |
|  Liabilities | 400 000.00[1] |   |
|  Cash Legacies | NIL |   |
|  Estate Duty | 34 962.06[1] |   |
|  Cash surplus to be paid to Simon as sole heir | 984 037.94[1] |   |
|   | 1 419 000.00 | 1 419 000.00  |
|  Distribution Account |  |   |
|  Balance for distribution |  | 4070 037.94[1]  |
|  Awarded to: |  |   |
|  Simon Lee, major father of the deceased i.t.o. clause 4 of the Will of the deceased [1] | 4 070 037.94 |   |
|  Award Consists of : |  |   |
|  Immovable Property R2 750 000.00 [1] |  |   |
|  Movable Property R 336 000.00 [1] |  |   |
|  Cash R 984 037.94 |  |   |
|  R4 070 037.94 | 4 070 037.94 | 4 070 037.94  |